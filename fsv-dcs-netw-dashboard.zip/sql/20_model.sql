-- Pilot model: rebuild gold from persisted bronze history. For larger estates,
-- replace CTAS with an atomic, bounded partition replacement after validating it.
SET TIME ZONE 'UTC';
-- COMMAND ----------
CREATE OR REPLACE VIEW __CATALOG__.__SCHEMA__.silver_nodes AS
WITH normalized AS (
  SELECT * EXCEPT(start_time, end_time),
    convert_timezone(current_timezone(), 'UTC', CAST(start_time AS TIMESTAMP_NTZ)) start_time,
    convert_timezone(current_timezone(), 'UTC', CAST(end_time AS TIMESTAMP_NTZ)) end_time
  FROM __CATALOG__.__SCHEMA__.bronze_node_timeline
)
SELECT workspace_id, cluster_id, instance_id, driver, start_time, end_time,
  greatest(start_time, CAST(DATE '__HISTORY_START_DATE__' AS TIMESTAMP_NTZ)) interval_start,
  least(end_time, CAST(DATE '__END_DATE__' AS TIMESTAMP_NTZ)) interval_end,
  CAST(network_received_bytes AS DOUBLE) received_bytes,
  CAST(network_sent_bytes AS DOUBLE) sent_bytes,
  timestampdiff(MICROSECOND, start_time, end_time) / 1000000.0 interval_seconds
FROM normalized
WHERE workspace_id IN (__WORKSPACE_IDS__)
  AND end_time > CAST(DATE '__HISTORY_START_DATE__' AS TIMESTAMP_NTZ)
  AND start_time < CAST(DATE '__END_DATE__' AS TIMESTAMP_NTZ)
  AND end_time > start_time
  AND network_received_bytes >= 0 AND network_sent_bytes >= 0;
-- COMMAND ----------
CREATE OR REPLACE VIEW __CATALOG__.__SCHEMA__.silver_workload_intervals AS
WITH task_clusters AS (
  SELECT t.* EXCEPT(period_start_time, period_end_time),
    convert_timezone(current_timezone(), 'UTC', CAST(t.period_start_time AS TIMESTAMP_NTZ)) period_start_time,
    convert_timezone(current_timezone(), 'UTC', CAST(t.period_end_time AS TIMESTAMP_NTZ)) period_end_time,
    explode(t.compute_ids) cluster_id
  FROM __CATALOG__.__SCHEMA__.bronze_job_task_run_timeline t
  WHERE t.workspace_id IN (__WORKSPACE_IDS__)
    AND t.period_end_time > to_timestamp('__HISTORY_START_DATE__T00:00:00Z')
    AND t.period_start_time < to_timestamp('__END_DATE__T00:00:00Z')
    AND t.period_end_time > t.period_start_time
), known_classic_clusters AS (
  SELECT DISTINCT workspace_id, cluster_id FROM __CATALOG__.__SCHEMA__.bronze_clusters
  UNION
  SELECT DISTINCT workspace_id, cluster_id FROM __CATALOG__.__SCHEMA__.bronze_node_timeline
), tasks AS (
  SELECT t.workspace_id, t.cluster_id, 'JOB' workload_type, t.job_id workload_id,
    t.job_run_id run_id,
    concat('JOB:', t.job_id, ':', t.job_run_id) workload_key,
    t.job_id, t.job_run_id, CAST(NULL AS STRING) pipeline_id,
    CAST(NULL AS STRING) update_id,
    greatest(t.period_start_time, CAST(DATE '__HISTORY_START_DATE__' AS TIMESTAMP_NTZ)) interval_start,
    least(t.period_end_time, CAST(DATE '__END_DATE__' AS TIMESTAMP_NTZ)) interval_end
  FROM task_clusters t
  JOIN known_classic_clusters c ON t.workspace_id = c.workspace_id AND t.cluster_id = c.cluster_id
  -- A pipeline task mapped to its update is represented by the pipeline consumer.
  WHERE NOT EXISTS (
    SELECT 1 FROM __CATALOG__.__SCHEMA__.bronze_pipeline_intervals p
    WHERE p.workspace_id = t.workspace_id AND p.job_task_run_id = t.task_run_id
      AND p.parent_job_id = t.job_id AND p.cluster_id = t.cluster_id
  )
)
SELECT DISTINCT * FROM tasks
UNION ALL
SELECT DISTINCT workspace_id, cluster_id, 'PIPELINE' workload_type, pipeline_id workload_id,
  update_id run_id, concat('PIPELINE:', pipeline_id, ':', update_id) workload_key,
  CAST(NULL AS STRING) job_id, CAST(NULL AS STRING) job_run_id, pipeline_id, update_id,
  greatest(period_start_time, CAST(DATE '__HISTORY_START_DATE__' AS TIMESTAMP_NTZ)) interval_start,
  least(period_end_time, CAST(DATE '__END_DATE__' AS TIMESTAMP_NTZ)) interval_end
FROM (
  SELECT * EXCEPT(period_start_time, period_end_time),
    convert_timezone(current_timezone(), 'UTC', CAST(period_start_time AS TIMESTAMP_NTZ)) period_start_time,
    convert_timezone(current_timezone(), 'UTC', CAST(period_end_time AS TIMESTAMP_NTZ)) period_end_time
  FROM __CATALOG__.__SCHEMA__.bronze_pipeline_intervals
)
WHERE workspace_id IN (__WORKSPACE_IDS__)
  AND period_end_time > CAST(DATE '__HISTORY_START_DATE__' AS TIMESTAMP_NTZ)
  AND period_start_time < CAST(DATE '__END_DATE__' AS TIMESTAMP_NTZ)
  AND period_end_time > period_start_time;
-- COMMAND ----------
CREATE OR REPLACE TABLE __CATALOG__.__SCHEMA__.network_segments USING DELTA
COMMENT 'Cluster segments bounded by all node/workload endpoints and UTC midnights. Single active workload is an estimated time association; shared bytes remain unassigned.'
AS
WITH cluster_bounds AS (
  SELECT workspace_id, cluster_id, min(interval_start) first_time, max(interval_end) last_time
  FROM __CATALOG__.__SCHEMA__.silver_nodes GROUP BY workspace_id, cluster_id
), boundaries AS (
  SELECT workspace_id, cluster_id, interval_start boundary FROM __CATALOG__.__SCHEMA__.silver_nodes
  UNION
  SELECT workspace_id, cluster_id, interval_end boundary FROM __CATALOG__.__SCHEMA__.silver_nodes
  UNION
  SELECT w.workspace_id, w.cluster_id, greatest(w.interval_start, b.first_time) boundary
  FROM __CATALOG__.__SCHEMA__.silver_workload_intervals w
  JOIN cluster_bounds b ON w.workspace_id = b.workspace_id AND w.cluster_id = b.cluster_id
  WHERE w.interval_start < b.last_time AND w.interval_end > b.first_time
  UNION
  SELECT w.workspace_id, w.cluster_id, least(w.interval_end, b.last_time) boundary
  FROM __CATALOG__.__SCHEMA__.silver_workload_intervals w
  JOIN cluster_bounds b ON w.workspace_id = b.workspace_id AND w.cluster_id = b.cluster_id
  WHERE w.interval_start < b.last_time AND w.interval_end > b.first_time
  UNION
  SELECT workspace_id, cluster_id, CAST(midnight AS TIMESTAMP_NTZ) boundary
  FROM cluster_bounds
  LATERAL VIEW explode(CASE WHEN DATE(first_time) < DATE(last_time - INTERVAL 1 MICROSECOND)
    THEN sequence(date_add(DATE(first_time), 1), DATE(last_time - INTERVAL 1 MICROSECOND), INTERVAL 1 DAY)
    ELSE CAST(array() AS ARRAY<DATE>) END) d AS midnight
), pairs AS (
  SELECT workspace_id, cluster_id, boundary segment_start,
    lead(boundary) OVER (PARTITION BY workspace_id, cluster_id ORDER BY boundary) segment_end
  FROM boundaries
), measured AS (
  -- Aggregate physical counters BEFORE any workload join to prevent task fanout.
  SELECT s.workspace_id, s.cluster_id, s.segment_start, s.segment_end,
    timestampdiff(MICROSECOND, s.segment_start, s.segment_end) / 1000000.0 segment_duration_seconds,
    sum(n.received_bytes * timestampdiff(MICROSECOND,
      greatest(s.segment_start, n.interval_start), least(s.segment_end, n.interval_end))
      / 1000000.0 / n.interval_seconds) received_bytes,
    sum(n.sent_bytes * timestampdiff(MICROSECOND,
      greatest(s.segment_start, n.interval_start), least(s.segment_end, n.interval_end))
      / 1000000.0 / n.interval_seconds) sent_bytes,
    sum(timestampdiff(MICROSECOND, greatest(s.segment_start, n.interval_start),
      least(s.segment_end, n.interval_end)) / 1000000.0) observed_node_seconds,
    count(*) observed_nodes
  FROM pairs s
  JOIN __CATALOG__.__SCHEMA__.silver_nodes n
    ON s.workspace_id = n.workspace_id AND s.cluster_id = n.cluster_id
    AND n.interval_start < s.segment_end AND n.interval_end > s.segment_start
  WHERE s.segment_end > s.segment_start
  GROUP BY s.workspace_id, s.cluster_id, s.segment_start, s.segment_end
), active AS (
  SELECT m.workspace_id, m.cluster_id, m.segment_start,
    count(DISTINCT w.workload_key) active_workload_count,
    collect_set(w.workload_key) active_workload_keys,
    max(w.workload_type) workload_type, max(w.workload_id) workload_id,
    max(w.job_id) job_id, max(w.job_run_id) job_run_id,
    max(w.pipeline_id) pipeline_id, max(w.update_id) update_id
  FROM measured m
  LEFT JOIN __CATALOG__.__SCHEMA__.silver_workload_intervals w
    ON m.workspace_id = w.workspace_id AND m.cluster_id = w.cluster_id
    AND w.interval_start < m.segment_end AND w.interval_end > m.segment_start
  GROUP BY m.workspace_id, m.cluster_id, m.segment_start
)
SELECT DATE(m.segment_start) usage_date, m.workspace_id, m.cluster_id,
  'CLASSIC' compute_type, m.segment_start, m.segment_end, m.segment_duration_seconds,
  a.active_workload_count, a.active_workload_keys,
  CASE WHEN a.active_workload_count = 1 THEN 'SINGLE_ACTIVE_WORKLOAD'
    WHEN a.active_workload_count > 1 THEN 'SHARED_AMBIGUOUS'
    ELSE 'UNATTRIBUTED' END attribution_status,
  CASE WHEN a.active_workload_count = 1 THEN a.workload_type
    WHEN a.active_workload_count > 1 THEN 'SHARED_AMBIGUOUS'
    ELSE 'UNATTRIBUTED' END workload_type,
  CASE WHEN a.active_workload_count = 1 THEN a.workload_id END workload_id,
  CASE WHEN a.active_workload_count = 1 THEN a.job_id END job_id,
  CASE WHEN a.active_workload_count = 1 THEN a.job_run_id END job_run_id,
  CASE WHEN a.active_workload_count = 1 THEN a.pipeline_id END pipeline_id,
  CASE WHEN a.active_workload_count = 1 THEN a.update_id END update_id,
  m.received_bytes, m.sent_bytes, m.received_bytes + m.sent_bytes total_bytes,
  m.observed_node_seconds, m.observed_nodes,
  m.received_bytes * 8.0 / m.segment_duration_seconds / 1000000.0 cluster_received_mbps,
  m.sent_bytes * 8.0 / m.segment_duration_seconds / 1000000.0 cluster_sent_mbps,
  current_timestamp() materialized_at
FROM measured m
JOIN active a ON m.workspace_id = a.workspace_id AND m.cluster_id = a.cluster_id
  AND m.segment_start = a.segment_start;
-- COMMAND ----------
CREATE OR REPLACE TABLE __CATALOG__.__SCHEMA__.network_cluster_daily USING DELTA AS
SELECT usage_date, workspace_id, cluster_id, compute_type,
  sum(received_bytes) measured_received_bytes, sum(sent_bytes) measured_sent_bytes,
  sum(total_bytes) measured_total_bytes,
  sum(CASE WHEN attribution_status = 'SINGLE_ACTIVE_WORKLOAD' THEN total_bytes ELSE 0 END) single_active_total_bytes,
  sum(CASE WHEN attribution_status = 'SHARED_AMBIGUOUS' THEN total_bytes ELSE 0 END) shared_total_bytes,
  sum(CASE WHEN attribution_status = 'UNATTRIBUTED' THEN total_bytes ELSE 0 END) unattributed_total_bytes,
  sum(observed_node_seconds) observed_node_seconds,
  sum(segment_duration_seconds) observed_cluster_seconds,
  max(cluster_received_mbps) peak_received_mbps, max(cluster_sent_mbps) peak_sent_mbps,
  current_timestamp() materialized_at
FROM __CATALOG__.__SCHEMA__.network_segments
GROUP BY usage_date, workspace_id, cluster_id, compute_type;
-- COMMAND ----------
CREATE OR REPLACE VIEW __CATALOG__.__SCHEMA__.silver_run_base AS
WITH job_periods AS (
  SELECT workspace_id, job_id, job_run_id, period_start_time, period_end_time, result_state
  FROM __CATALOG__.__SCHEMA__.bronze_job_run_timeline
  UNION ALL
  SELECT t.workspace_id, t.job_id, t.job_run_id, t.period_start_time, t.period_end_time,
    CAST(NULL AS STRING) result_state
  FROM __CATALOG__.__SCHEMA__.bronze_job_task_run_timeline t
  WHERE NOT EXISTS (
    SELECT 1 FROM __CATALOG__.__SCHEMA__.bronze_job_run_timeline j
    WHERE t.workspace_id = j.workspace_id AND t.job_id = j.job_id AND t.job_run_id = j.job_run_id
  )
), jobs AS (
  SELECT workspace_id, 'JOB' workload_type, job_id workload_id, job_run_id run_id,
    concat('JOB:', job_id, ':', job_run_id) workload_key,
    job_id, job_run_id, CAST(NULL AS STRING) pipeline_id, CAST(NULL AS STRING) update_id,
    min(period_start_time) run_start_time, max(period_end_time) run_end_time,
    max_by(result_state, CASE WHEN result_state IS NOT NULL THEN period_end_time END) result_state
  FROM job_periods
  WHERE workspace_id IN (__WORKSPACE_IDS__)
  GROUP BY workspace_id, job_id, job_run_id
), pipeline_periods AS (
  SELECT workspace_id, pipeline_id, update_id, period_start_time, period_end_time, result_state
  FROM __CATALOG__.__SCHEMA__.bronze_pipeline_update_timeline
  UNION ALL
  SELECT p.workspace_id, p.pipeline_id, p.update_id, p.period_start_time, p.period_end_time,
    CAST(NULL AS STRING) result_state
  FROM __CATALOG__.__SCHEMA__.bronze_pipeline_intervals p
  WHERE NOT EXISTS (
    SELECT 1 FROM __CATALOG__.__SCHEMA__.bronze_pipeline_update_timeline t
    WHERE p.workspace_id = t.workspace_id AND p.pipeline_id = t.pipeline_id AND p.update_id = t.update_id
  )
), pipelines AS (
  SELECT workspace_id, 'PIPELINE' workload_type, pipeline_id workload_id, update_id run_id,
    concat('PIPELINE:', pipeline_id, ':', update_id) workload_key,
    CAST(NULL AS STRING) job_id, CAST(NULL AS STRING) job_run_id, pipeline_id, update_id,
    min(period_start_time) run_start_time, max(period_end_time) run_end_time,
    max_by(result_state, CASE WHEN result_state IS NOT NULL THEN period_end_time END) result_state
  FROM pipeline_periods
  WHERE workspace_id IN (__WORKSPACE_IDS__)
  GROUP BY workspace_id, pipeline_id, update_id
)
SELECT workspace_id, workload_type, workload_id, run_id, workload_key,
  job_id, job_run_id, pipeline_id, update_id,
  convert_timezone(current_timezone(), 'UTC', CAST(run_start_time AS TIMESTAMP_NTZ)) run_start_time,
  convert_timezone(current_timezone(), 'UTC', CAST(run_end_time AS TIMESTAMP_NTZ)) run_end_time,
  result_state
FROM (SELECT * FROM jobs UNION ALL SELECT * FROM pipelines)
WHERE run_start_time < to_timestamp('__END_DATE__T00:00:00Z')
  AND run_end_time > to_timestamp('__HISTORY_START_DATE__T00:00:00Z')
  AND run_end_time > run_start_time;
-- COMMAND ----------
CREATE OR REPLACE TABLE __CATALOG__.__SCHEMA__.network_run_inventory USING DELTA AS
WITH latest_jobs AS (
  SELECT workspace_id, job_id, name job_name FROM __CATALOG__.__SCHEMA__.bronze_jobs
  QUALIFY row_number() OVER (PARTITION BY workspace_id, job_id ORDER BY change_time DESC) = 1
), task_compute AS (
  SELECT workspace_id, job_id, job_run_id, explode(compute_ids) cluster_id
  FROM __CATALOG__.__SCHEMA__.bronze_job_task_run_timeline
), known_classic_clusters AS (
  SELECT DISTINCT workspace_id, cluster_id FROM __CATALOG__.__SCHEMA__.bronze_clusters
  UNION
  SELECT DISTINCT workspace_id, cluster_id FROM __CATALOG__.__SCHEMA__.bronze_node_timeline
), classic AS (
  SELECT DISTINCT workspace_id, workload_type, workload_id, run_id
  FROM __CATALOG__.__SCHEMA__.silver_workload_intervals
  UNION
  SELECT DISTINCT t.workspace_id, 'JOB' workload_type, t.job_id workload_id, t.job_run_id run_id
  FROM task_compute t
  JOIN known_classic_clusters c ON t.workspace_id = c.workspace_id AND t.cluster_id = c.cluster_id
), billing AS (
  SELECT workspace_id, job_id, job_run_id,
    -- A serverless SQL SKU is SQL warehouse evidence, not a second compute type.
    max(CASE WHEN sku_name LIKE '%SERVERLESS%' AND sku_name NOT LIKE '%SQL%' THEN 1 ELSE 0 END) serverless_evidence,
    max(CASE WHEN sku_name LIKE '%SQL%' THEN 1 ELSE 0 END) sql_evidence,
    max(CASE WHEN cluster_id IS NOT NULL THEN 1 ELSE 0 END) classic_evidence
  FROM __CATALOG__.__SCHEMA__.bronze_billing_compute
  GROUP BY workspace_id, job_id, job_run_id
), overrides AS (
  SELECT * FROM __CATALOG__.__SCHEMA__.bronze_compute_classification
  WHERE compute_type IN ('CLASSIC', 'SERVERLESS', 'SQL_WAREHOUSE', 'MIXED', 'UNKNOWN')
  QUALIFY row_number() OVER (
    PARTITION BY workspace_id, workload_type, workload_id, run_id ORDER BY ingested_at DESC
  ) = 1
), observations AS (
  SELECT r.workspace_id, r.workload_key,
    count(s.segment_start) associated_segments,
    count(CASE WHEN s.attribution_status = 'SINGLE_ACTIVE_WORKLOAD' THEN 1 END) exclusive_segments,
    count(CASE WHEN s.attribution_status = 'SHARED_AMBIGUOUS' THEN 1 END) shared_segments,
    sum(CASE WHEN s.attribution_status = 'SINGLE_ACTIVE_WORKLOAD' THEN s.total_bytes END) attributed_total_bytes
  FROM __CATALOG__.__SCHEMA__.silver_run_base r
  LEFT JOIN __CATALOG__.__SCHEMA__.network_segments s
    ON r.workspace_id = s.workspace_id AND array_contains(s.active_workload_keys, r.workload_key)
  GROUP BY r.workspace_id, r.workload_key
)
SELECT r.*, j.job_name,
  CASE
    WHEN o.compute_type = 'MIXED' THEN 'MIXED'
    -- Manual evidence cannot erase independently observed compute. In particular,
    -- classic node bytes must never acquire a serverless/SQL-only run label.
    WHEN ((c.run_id IS NOT NULL OR coalesce(b.classic_evidence, 0) = 1 OR o.compute_type = 'CLASSIC')
      AND (coalesce(b.serverless_evidence, 0) = 1 OR coalesce(b.sql_evidence, 0) = 1
        OR o.compute_type IN ('SERVERLESS', 'SQL_WAREHOUSE')))
      OR ((coalesce(b.serverless_evidence, 0) = 1 OR o.compute_type = 'SERVERLESS')
        AND (coalesce(b.sql_evidence, 0) = 1 OR o.compute_type = 'SQL_WAREHOUSE')) THEN 'MIXED'
    WHEN o.compute_type IN ('CLASSIC', 'SERVERLESS', 'SQL_WAREHOUSE') THEN o.compute_type
    WHEN coalesce(b.serverless_evidence, 0) = 1 THEN 'SERVERLESS'
    WHEN c.run_id IS NOT NULL OR coalesce(b.classic_evidence, 0) = 1 THEN 'CLASSIC'
    WHEN coalesce(b.sql_evidence, 0) = 1 THEN 'SQL_WAREHOUSE'
    ELSE 'UNKNOWN' END compute_type,
  CASE WHEN o.compute_type IN ('CLASSIC', 'SERVERLESS', 'SQL_WAREHOUSE', 'MIXED') THEN o.evidence_source
    WHEN coalesce(b.serverless_evidence, 0) = 1 THEN 'BILLING_SERVERLESS_SKU'
    WHEN c.run_id IS NOT NULL THEN 'VERIFIED_CLASSIC_CLUSTER_LINK'
    WHEN coalesce(b.classic_evidence, 0) = 1 THEN 'BILLING_CLUSTER_ID'
    WHEN coalesce(b.sql_evidence, 0) = 1 THEN 'BILLING_SQL_SKU'
    ELSE 'INSUFFICIENT_COMPUTE_EVIDENCE' END compute_evidence,
  timestampdiff(MICROSECOND, r.run_start_time, r.run_end_time) / 1000000.0 duration_seconds,
  CASE WHEN v.exclusive_segments > 0 AND v.shared_segments > 0 THEN 'PARTIAL_EXCLUSIVE'
    WHEN v.exclusive_segments > 0 THEN 'OBSERVED_EXCLUSIVE'
    WHEN v.shared_segments > 0 THEN 'SHARED_ONLY'
    ELSE 'NO_NODE_METRICS' END network_coverage,
  v.attributed_total_bytes,
  v.associated_segments, v.exclusive_segments, v.shared_segments,
  current_timestamp() materialized_at
FROM __CATALOG__.__SCHEMA__.silver_run_base r
LEFT JOIN latest_jobs j ON r.workspace_id = j.workspace_id AND r.job_id = j.job_id
LEFT JOIN classic c ON r.workspace_id = c.workspace_id AND r.workload_type = c.workload_type
  AND r.workload_id = c.workload_id AND r.run_id = c.run_id
LEFT JOIN billing b ON r.workspace_id = b.workspace_id AND r.job_id = b.job_id AND r.job_run_id = b.job_run_id
LEFT JOIN overrides o ON r.workspace_id = o.workspace_id AND r.workload_type = o.workload_type
  AND r.workload_id = o.workload_id AND r.run_id = o.run_id
LEFT JOIN observations v ON r.workspace_id = v.workspace_id AND r.workload_key = v.workload_key;
-- COMMAND ----------
CREATE OR REPLACE TABLE __CATALOG__.__SCHEMA__.network_daily USING DELTA AS
WITH days AS (
  SELECT r.*, explode(sequence(
    greatest(DATE(r.run_start_time), DATE '__HISTORY_START_DATE__'),
    least(DATE(r.run_end_time - INTERVAL 1 MICROSECOND), date_sub(DATE '__END_DATE__', 1)),
    INTERVAL 1 DAY)) usage_date
  FROM __CATALOG__.__SCHEMA__.network_run_inventory r
), run_days AS (
  SELECT d.*,
    timestampdiff(MICROSECOND,
      greatest(run_start_time, CAST(usage_date AS TIMESTAMP_NTZ)),
      least(run_end_time, CAST(date_add(usage_date, 1) AS TIMESTAMP_NTZ))) / 1000000.0 day_duration_seconds
  FROM days d
), measured AS (
  SELECT usage_date, workspace_id, cluster_id, compute_type, workload_type, workload_id,
    job_id, job_run_id, pipeline_id, update_id, attribution_status,
    sum(received_bytes) received_bytes, sum(sent_bytes) sent_bytes, sum(total_bytes) total_bytes,
    sum(observed_node_seconds) observed_node_seconds,
    sum(segment_duration_seconds) allocated_cluster_seconds
  FROM __CATALOG__.__SCHEMA__.network_segments
  GROUP BY usage_date, workspace_id, cluster_id, compute_type, workload_type, workload_id,
    job_id, job_run_id, pipeline_id, update_id, attribution_status
), daily_presence AS (
  SELECT s.usage_date, s.workspace_id, k.workload_key,
    count(CASE WHEN s.attribution_status = 'SHARED_AMBIGUOUS' THEN 1 END) shared_segments
  FROM __CATALOG__.__SCHEMA__.network_segments s
  LATERAL VIEW explode(s.active_workload_keys) k AS workload_key
  GROUP BY s.usage_date, s.workspace_id, k.workload_key
)
SELECT m.usage_date, m.workspace_id, m.cluster_id,
  CASE WHEN m.attribution_status = 'SINGLE_ACTIVE_WORKLOAD' THEN coalesce(r.compute_type, m.compute_type)
    ELSE m.compute_type END compute_type,
  m.workload_type, m.workload_id, m.job_id, m.job_run_id, m.pipeline_id, m.update_id,
  m.attribution_status, m.received_bytes, m.sent_bytes, m.total_bytes,
  m.observed_node_seconds, m.allocated_cluster_seconds,
  r.job_name, r.result_state, r.day_duration_seconds run_duration_seconds,
  CASE WHEN m.attribution_status = 'SINGLE_ACTIVE_WORKLOAD' AND coalesce(p.shared_segments, 0) > 0 THEN 'PARTIAL_EXCLUSIVE'
    WHEN m.attribution_status = 'SINGLE_ACTIVE_WORKLOAD' THEN 'OBSERVED_EXCLUSIVE'
    ELSE m.attribution_status END network_coverage,
  current_timestamp() materialized_at
FROM measured m
LEFT JOIN run_days r ON m.usage_date = r.usage_date AND m.workspace_id = r.workspace_id
  AND m.workload_type = r.workload_type AND m.workload_id = r.workload_id
  AND coalesce(m.job_run_id, m.update_id) = r.run_id
LEFT JOIN daily_presence p ON r.usage_date = p.usage_date AND r.workspace_id = p.workspace_id
  AND r.workload_key = p.workload_key
UNION ALL
SELECT r.usage_date, r.workspace_id, CAST(NULL AS STRING) cluster_id, r.compute_type,
  r.workload_type, r.workload_id, r.job_id, r.job_run_id, r.pipeline_id, r.update_id,
  CASE WHEN coalesce(p.shared_segments, 0) > 0 THEN 'SHARED_ONLY' ELSE 'NO_NODE_METRICS' END attribution_status,
  CAST(NULL AS DOUBLE) received_bytes, CAST(NULL AS DOUBLE) sent_bytes, CAST(NULL AS DOUBLE) total_bytes,
  CAST(NULL AS DOUBLE) observed_node_seconds, CAST(NULL AS DOUBLE) allocated_cluster_seconds,
  r.job_name, r.result_state, r.day_duration_seconds run_duration_seconds,
  CASE WHEN coalesce(p.shared_segments, 0) > 0 THEN 'SHARED_ONLY' ELSE 'NO_NODE_METRICS' END network_coverage,
  current_timestamp() materialized_at
FROM run_days r
LEFT JOIN daily_presence p ON r.usage_date = p.usage_date AND r.workspace_id = p.workspace_id
  AND r.workload_key = p.workload_key
WHERE NOT EXISTS (
  SELECT 1 FROM measured m
  WHERE m.usage_date = r.usage_date AND m.workspace_id = r.workspace_id
    AND m.workload_type = r.workload_type AND m.workload_id = r.workload_id
    AND coalesce(m.job_run_id, m.update_id) = r.run_id
);
