-- Reconciliation compares clipped persisted counters with all allocation buckets.
-- No expected-node denominator exists here: observed seconds are not coverage %.
CREATE OR REPLACE TABLE __CATALOG__.__SCHEMA__.network_reconciliation USING DELTA AS
WITH source AS (
  SELECT workspace_id, cluster_id,
    sum(received_bytes * timestampdiff(MICROSECOND, interval_start, interval_end)
      / 1000000.0 / interval_seconds) source_received_bytes,
    sum(sent_bytes * timestampdiff(MICROSECOND, interval_start, interval_end)
      / 1000000.0 / interval_seconds) source_sent_bytes
  FROM __CATALOG__.__SCHEMA__.silver_nodes
  GROUP BY workspace_id, cluster_id
), modeled AS (
  SELECT workspace_id, cluster_id, sum(received_bytes) modeled_received_bytes,
    sum(sent_bytes) modeled_sent_bytes
  FROM __CATALOG__.__SCHEMA__.network_segments
  GROUP BY workspace_id, cluster_id
), daily AS (
  SELECT workspace_id, cluster_id, sum(received_bytes) daily_received_bytes,
    sum(sent_bytes) daily_sent_bytes
  FROM __CATALOG__.__SCHEMA__.network_daily
  WHERE cluster_id IS NOT NULL
  GROUP BY workspace_id, cluster_id
)
SELECT coalesce(s.workspace_id, m.workspace_id) workspace_id,
  coalesce(s.cluster_id, m.cluster_id) cluster_id,
  coalesce(s.source_received_bytes, 0) source_received_bytes,
  coalesce(s.source_sent_bytes, 0) source_sent_bytes,
  coalesce(m.modeled_received_bytes, 0) modeled_received_bytes,
  coalesce(m.modeled_sent_bytes, 0) modeled_sent_bytes,
  coalesce(d.daily_received_bytes, 0) daily_received_bytes,
  coalesce(d.daily_sent_bytes, 0) daily_sent_bytes,
  coalesce(m.modeled_received_bytes, 0) - coalesce(s.source_received_bytes, 0) received_error_bytes,
  coalesce(m.modeled_sent_bytes, 0) - coalesce(s.source_sent_bytes, 0) sent_error_bytes,
  coalesce(d.daily_received_bytes, 0) - coalesce(m.modeled_received_bytes, 0) daily_received_error_bytes,
  coalesce(d.daily_sent_bytes, 0) - coalesce(m.modeled_sent_bytes, 0) daily_sent_error_bytes,
  greatest(0.01, (coalesce(s.source_received_bytes, 0) + coalesce(s.source_sent_bytes, 0)) * 1e-9) tolerance_bytes,
  current_timestamp() checked_at
FROM source s
FULL OUTER JOIN modeled m ON s.workspace_id = m.workspace_id AND s.cluster_id = m.cluster_id
LEFT JOIN daily d ON coalesce(s.workspace_id, m.workspace_id) = d.workspace_id
  AND coalesce(s.cluster_id, m.cluster_id) = d.cluster_id;
-- COMMAND ----------
CREATE OR REPLACE TABLE __CATALOG__.__SCHEMA__.network_quality USING DELTA AS
WITH checks AS (
  SELECT 'byte_conservation' check_name,
    CAST(count_if(abs(received_error_bytes) > tolerance_bytes OR abs(sent_error_bytes) > tolerance_bytes
      OR abs(daily_received_error_bytes) > tolerance_bytes OR abs(daily_sent_error_bytes) > tolerance_bytes) AS DOUBLE) check_value,
    'FAIL' nonzero_status,
    'Clusters whose source, segment and daily received/sent bytes differ beyond floating-point tolerance.' detail
  FROM __CATALOG__.__SCHEMA__.network_reconciliation
  UNION ALL
  SELECT 'negative_or_missing_segment_bytes', CAST(count_if(received_bytes < 0 OR sent_bytes < 0
    OR received_bytes IS NULL OR sent_bytes IS NULL OR segment_duration_seconds <= 0) AS DOUBLE),
    'FAIL', 'Measured segments require non-negative counters and positive duration.'
  FROM __CATALOG__.__SCHEMA__.network_segments
  UNION ALL
  SELECT 'unmeasured_rows_have_bytes', CAST(count_if(attribution_status IN ('NO_NODE_METRICS', 'SHARED_ONLY')
    AND (received_bytes IS NOT NULL OR sent_bytes IS NOT NULL OR total_bytes IS NOT NULL)) AS DOUBLE),
    'FAIL', 'Unmeasured workload rows must use NULL rather than zero or allocated shared bytes.'
  FROM __CATALOG__.__SCHEMA__.network_daily
  UNION ALL
  SELECT 'nonclassic_only_rows_have_node_bytes', CAST(count_if(compute_type IN ('SERVERLESS', 'SQL_WAREHOUSE')
    AND (received_bytes IS NOT NULL OR sent_bytes IS NOT NULL OR total_bytes IS NOT NULL)) AS DOUBLE),
    'FAIL', 'Classic node measurements require CLASSIC or MIXED compute evidence, even when a manual adapter conflicts.'
  FROM __CATALOG__.__SCHEMA__.network_daily
  UNION ALL
  SELECT 'out_of_scope_workspace', CAST(count_if(workspace_id NOT IN (__WORKSPACE_IDS__)) AS DOUBLE),
    'FAIL', 'Gold output must remain within the explicitly configured workspace list.'
  FROM (
    SELECT workspace_id FROM __CATALOG__.__SCHEMA__.network_segments
    UNION ALL SELECT workspace_id FROM __CATALOG__.__SCHEMA__.network_cluster_daily
    UNION ALL SELECT workspace_id FROM __CATALOG__.__SCHEMA__.network_daily
    UNION ALL SELECT workspace_id FROM __CATALOG__.__SCHEMA__.network_run_inventory
  )
  UNION ALL
  SELECT 'invalid_source_node_intervals', CAST(count_if(end_time <= start_time OR start_time IS NULL
    OR end_time IS NULL OR network_received_bytes IS NULL OR network_sent_bytes IS NULL
    OR network_received_bytes < 0 OR network_sent_bytes < 0) AS DOUBLE),
    'WARN', 'Invalid persisted source counters are excluded; their bytes cannot be reconstructed.'
  FROM __CATALOG__.__SCHEMA__.bronze_node_timeline
  WHERE workspace_id IN (__WORKSPACE_IDS__)
    AND start_time < to_timestamp('__END_DATE__T00:00:00Z')
    AND coalesce(end_time, start_time) >= to_timestamp('__HISTORY_START_DATE__T00:00:00Z')
  UNION ALL
  SELECT 'overlapping_same_node_intervals', CAST(count_if(interval_start < previous_end) AS DOUBLE),
    'FAIL', 'Overlapping intervals for one cluster instance can duplicate physical traffic.'
  FROM (
    SELECT *, max(interval_end) OVER (PARTITION BY workspace_id, cluster_id, instance_id
      ORDER BY interval_start ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) previous_end
    FROM __CATALOG__.__SCHEMA__.silver_nodes
  )
  UNION ALL
  SELECT 'runs_without_node_metrics', CAST(count_if(network_coverage = 'NO_NODE_METRICS') AS DOUBLE),
    'WARN', 'Includes serverless, SQL, unmapped pipelines, missing short-lived nodes, collection gaps and source retention limits. Missing is never zero.'
  FROM __CATALOG__.__SCHEMA__.network_run_inventory
  UNION ALL
  SELECT 'runs_with_shared_traffic', CAST(count_if(network_coverage IN ('SHARED_ONLY', 'PARTIAL_EXCLUSIVE')) AS DOUBLE),
    'WARN', 'Shared traffic remains in cluster accounting and is not divided between active workloads.'
  FROM __CATALOG__.__SCHEMA__.network_run_inventory
  UNION ALL
  SELECT 'unknown_compute_type_runs', CAST(count_if(compute_type = 'UNKNOWN') AS DOUBLE),
    'WARN', 'Missing compute IDs or billing evidence do not prove serverless execution.'
  FROM __CATALOG__.__SCHEMA__.network_run_inventory
  UNION ALL
  SELECT 'no_node_data', CAST(CASE WHEN count(*) = 0 THEN 1 ELSE 0 END AS DOUBLE),
    'WARN', 'No valid classic node counters exist in the requested reporting window.'
  FROM __CATALOG__.__SCHEMA__.silver_nodes
  UNION ALL
  SELECT 'node_source_stale', CAST(CASE WHEN max(end_time) IS NULL
    OR max(end_time) < CAST(DATE '__END_DATE__' AS TIMESTAMP_NTZ) - INTERVAL 2 DAYS THEN 1 ELSE 0 END AS DOUBLE),
    'WARN', 'Latest persisted node interval is more than two days before requested window end. Idle estates can also produce this warning.'
  FROM __CATALOG__.__SCHEMA__.silver_nodes
)
SELECT check_name, coalesce(check_value, 0) check_value,
  CASE WHEN coalesce(check_value, 0) = 0 THEN 'PASS' ELSE nonzero_status END status,
  detail, current_timestamp() checked_at
FROM checks;
-- COMMAND ----------
SELECT assert_true(count_if(status = 'FAIL') = 0,
  'Network model invariant failed. Inspect network_quality and network_reconciliation before using dashboard totals.')
FROM __CATALOG__.__SCHEMA__.network_quality;
