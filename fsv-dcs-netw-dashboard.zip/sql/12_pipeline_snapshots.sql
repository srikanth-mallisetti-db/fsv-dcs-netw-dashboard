-- Opt-in: pipeline_update_timeline must be available and readable in this region.
MERGE INTO __CATALOG__.__SCHEMA__.bronze_pipeline_update_timeline t
USING (
  SELECT CAST(workspace_id AS STRING) workspace_id, pipeline_id, update_id,
    period_start_time, period_end_time, result_state,
    to_json(compute) compute_json, to_json(trigger_details) trigger_details_json,
    current_timestamp() ingested_at
  FROM system.lakeflow.pipeline_update_timeline
  WHERE CAST(workspace_id AS STRING) IN (__WORKSPACE_IDS__)
    AND period_start_time < to_timestamp('__END_DATE__T00:00:00Z')
    AND period_end_time > to_timestamp('__START_DATE__T00:00:00Z')
  QUALIFY row_number() OVER (
    PARTITION BY workspace_id, pipeline_id, update_id, period_start_time
    ORDER BY period_end_time DESC, result_state DESC
  ) = 1
) s
ON t.workspace_id = s.workspace_id AND t.pipeline_id = s.pipeline_id
  AND t.update_id = s.update_id AND t.period_start_time = s.period_start_time
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;
