SET TIME ZONE 'UTC';
-- COMMAND ----------
MERGE INTO __CATALOG__.__SCHEMA__.bronze_node_timeline t
USING (
  SELECT CAST(workspace_id AS STRING) workspace_id, cluster_id, instance_id, driver,
    start_time, end_time, network_received_bytes, network_sent_bytes,
    current_timestamp() ingested_at
  FROM system.compute.node_timeline
  WHERE CAST(workspace_id AS STRING) IN (__WORKSPACE_IDS__)
    AND start_time < to_timestamp('__END_DATE__T00:00:00Z')
    AND end_time > to_timestamp('__NODE_START_DATE__T00:00:00Z')
  QUALIFY row_number() OVER (
    PARTITION BY workspace_id, cluster_id, instance_id, start_time
    ORDER BY end_time DESC, network_received_bytes DESC, network_sent_bytes DESC
  ) = 1
) s
ON t.workspace_id = s.workspace_id AND t.cluster_id = s.cluster_id
  AND t.instance_id = s.instance_id AND t.start_time = s.start_time
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;
-- COMMAND ----------
MERGE INTO __CATALOG__.__SCHEMA__.bronze_job_run_timeline t
USING (
  SELECT CAST(workspace_id AS STRING) workspace_id, CAST(job_id AS STRING) job_id,
    CAST(run_id AS STRING) job_run_id, period_start_time, period_end_time,
    result_state, termination_code, current_timestamp() ingested_at
  FROM system.lakeflow.job_run_timeline
  WHERE CAST(workspace_id AS STRING) IN (__WORKSPACE_IDS__)
    AND period_start_time < to_timestamp('__END_DATE__T00:00:00Z')
    AND period_end_time > to_timestamp('__START_DATE__T00:00:00Z')
  QUALIFY row_number() OVER (
    PARTITION BY workspace_id, job_id, run_id, period_start_time
    ORDER BY period_end_time DESC, result_state DESC
  ) = 1
) s
ON t.workspace_id = s.workspace_id AND t.job_id = s.job_id
  AND t.job_run_id = s.job_run_id AND t.period_start_time = s.period_start_time
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;
-- COMMAND ----------
MERGE INTO __CATALOG__.__SCHEMA__.bronze_job_task_run_timeline t
USING (
  SELECT CAST(workspace_id AS STRING) workspace_id, CAST(job_id AS STRING) job_id,
    CAST(job_run_id AS STRING) job_run_id, CAST(run_id AS STRING) task_run_id,
    task_key, period_start_time, period_end_time, compute_ids, result_state,
    termination_code, current_timestamp() ingested_at
  FROM system.lakeflow.job_task_run_timeline
  WHERE CAST(workspace_id AS STRING) IN (__WORKSPACE_IDS__)
    AND period_start_time < to_timestamp('__END_DATE__T00:00:00Z')
    AND period_end_time > to_timestamp('__START_DATE__T00:00:00Z')
  QUALIFY row_number() OVER (
    PARTITION BY workspace_id, job_id, job_run_id, run_id, period_start_time
    ORDER BY period_end_time DESC, result_state DESC
  ) = 1
) s
ON t.workspace_id = s.workspace_id AND t.job_id = s.job_id
  AND t.job_run_id = s.job_run_id AND t.task_run_id = s.task_run_id
  AND t.period_start_time = s.period_start_time
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;
-- COMMAND ----------
MERGE INTO __CATALOG__.__SCHEMA__.bronze_jobs t
USING (
  SELECT CAST(workspace_id AS STRING) workspace_id, CAST(job_id AS STRING) job_id,
    name, change_time, delete_time, current_timestamp() ingested_at
  FROM system.lakeflow.jobs
  WHERE CAST(workspace_id AS STRING) IN (__WORKSPACE_IDS__)
  QUALIFY row_number() OVER (
    PARTITION BY workspace_id, job_id, change_time ORDER BY delete_time DESC, name
  ) = 1
) s
ON t.workspace_id = s.workspace_id AND t.job_id = s.job_id AND t.change_time = s.change_time
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;
-- COMMAND ----------
MERGE INTO __CATALOG__.__SCHEMA__.bronze_clusters t
USING (
  SELECT CAST(workspace_id AS STRING) workspace_id, cluster_id, cluster_name,
    cluster_source, change_time, delete_time, current_timestamp() ingested_at
  FROM system.compute.clusters
  WHERE CAST(workspace_id AS STRING) IN (__WORKSPACE_IDS__)
  QUALIFY row_number() OVER (
    PARTITION BY workspace_id, cluster_id, change_time ORDER BY delete_time DESC, cluster_name
  ) = 1
) s
ON t.workspace_id = s.workspace_id AND t.cluster_id = s.cluster_id AND t.change_time = s.change_time
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;
