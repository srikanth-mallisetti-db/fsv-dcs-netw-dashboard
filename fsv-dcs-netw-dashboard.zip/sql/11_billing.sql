-- Optional source. Billing provides positive compute-type evidence, never network bytes.
MERGE INTO __CATALOG__.__SCHEMA__.bronze_billing_compute t
USING (
  SELECT record_id, CAST(workspace_id AS STRING) workspace_id,
    CAST(usage_metadata.job_id AS STRING) job_id,
    CAST(usage_metadata.job_run_id AS STRING) job_run_id,
    usage_metadata.cluster_id cluster_id, sku_name,
    usage_start_time, usage_end_time, record_type, current_timestamp() ingested_at
  FROM system.billing.usage
  WHERE CAST(workspace_id AS STRING) IN (__WORKSPACE_IDS__)
    AND usage_date >= DATE '__START_DATE__'
    AND usage_date < DATE '__END_DATE__'
    AND usage_metadata.job_id IS NOT NULL
    AND usage_metadata.job_run_id IS NOT NULL
  QUALIFY row_number() OVER (PARTITION BY record_id ORDER BY usage_end_time DESC) = 1
) s
ON t.record_id = s.record_id
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;
