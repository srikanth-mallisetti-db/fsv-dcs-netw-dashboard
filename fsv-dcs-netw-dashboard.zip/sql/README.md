# SQL data contract

Run files in numeric order with the Python runner. Each `-- COMMAND ----------`
separates a single warehouse statement. Files 11–13 are optional sources. The
catalog must already exist. The target schema is a single-writer pilot deployment;
refreshes rebuild gold from persisted bronze, so schedule one refresh at a time.

Source filters use timestamps with an explicit UTC offset. Silver and gold
interval endpoints are `TIMESTAMP_NTZ` values representing UTC. Daily boundaries
are UTC; session timezone does not change allocation or daily dates. The SQL uses
`convert_timezone` and requires a current SQL warehouse or Databricks Runtime
13.3 LTS or newer.

The runner replaces these tokens after validating inputs:

| Token | Meaning |
| --- | --- |
| `__CATALOG__`, `__SCHEMA__` | Individually quoted Unity Catalog identifiers |
| `__WORKSPACE_IDS__` | Nonempty, SQL-quoted string literal list |
| `__START_DATE__` | Inclusive source refresh date for job, task, billing and pipeline periods |
| `__NODE_START_DATE__` | Inclusive node source refresh date; never assume older source history exists |
| `__HISTORY_START_DATE__` | Inclusive retained reporting window start |
| `__END_DATE__` | Exclusive source and reporting end date |
| `__PIPELINE_ID__` | One explicitly configured pipeline UUID for optional event-log adapter |

## Gold tables

| Table | Grain and meaning |
| --- | --- |
| `network_segments` | One workspace/cluster/UTC segment. Boundaries include every node interval endpoint, workload interval endpoint and UTC midnight. Physical node bytes are aggregated before the workload join. |
| `network_cluster_daily` | One UTC day/workspace/cluster. Physical receive/send totals; exclusive, shared and unattributed buckets reconcile to the total. Compute type is `CLASSIC`. |
| `network_run_inventory` | One workspace/workload type/workload ID/run ID. JOB rows use parent `job_run_id`; PIPELINE rows use `update_id`. Includes runs without measurements. |
| `network_daily` | One UTC day/workspace/cluster/workload run/attribution status, plus one NULL-cluster workload-day row where no exclusive estimate exists. Includes shared/unattributed cluster buckets and unmeasured workloads. |
| `network_reconciliation` | One workspace/cluster. Independently compares clipped bronze counters, segments and daily output with a floating-point tolerance. |
| `network_quality` | One named check with numeric `check_value`, `status` (`PASS`, `WARN`, `FAIL`), `detail`, and `checked_at`. FAIL checks abort the refresh. |

`received_bytes`, `sent_bytes`, and `total_bytes` are bytes, represented as DOUBLE
after time proration. Source node fields are BIGINT byte totals within each
interval; do not difference consecutive rows or multiply them by seconds.
`cluster_received_mbps` and `cluster_sent_mbps` are physical interval-average
megabits per second, using 1,000,000 bits per megabit. They do not report link
capacity, instantaneous peaks or an external-storage endpoint's bandwidth.
`observed_node_seconds` counts all observed driver and worker time.
`segment_duration_seconds` / `observed_cluster_seconds` count wall time once per
cluster, irrespective of node count. They are not a percentage of expected data.

`SINGLE_ACTIVE_WORKLOAD` means an **estimated association** with the only known
active distinct job run or pipeline update. Parallel tasks within one job run do
not multiply bytes. More than one distinct active workload produces a single
`SHARED_AMBIGUOUS` cluster bucket; its bytes are never equally divided. No known
active workload produces `UNATTRIBUTED`. Untracked activity on a shared cluster
can still exist during a single known workload, so this is not exact per-run
measurement. Every interval uses half-open `[start, end)` overlap semantics.

Inventory `attributed_total_bytes` includes only exclusive estimates, and is NULL
when none exists. `network_coverage` is `OBSERVED_EXCLUSIVE`,
`PARTIAL_EXCLUSIVE` (some shared segments), `SHARED_ONLY`, or `NO_NODE_METRICS`.
The word observed does not promise complete telemetry. Serverless and SQL
warehouses have no node counters in this source. Missing measurements remain
NULL, including when other runs recorded a real zero-byte interval.

Compute classification uses positive evidence from a known classic cluster link,
billing SKU/cluster metadata or an explicit classification adapter. A run with
both classic and serverless/SQL evidence is `MIXED`. Missing compute IDs alone
produce `UNKNOWN`, never `SERVERLESS`. Billing quantities are not byte estimates.
Job names use the latest retained definition, including deleted jobs. Recorded
run duration is the envelope of retained parent timeline slices, falling back to
task slices only when the parent is absent. The first collection, source
retention and ongoing runs can make this envelope incomplete.

Do not sum `run_duration_seconds` from `network_daily`: the duration repeats when
one run has multiple clusters. Use `network_run_inventory.duration_seconds` and
count distinct workspace/workload/run keys for run counts. Physical cluster
accounting lacks a job dimension and remains unchanged when filtering a job's
exclusive estimates. Summing workload estimates excludes shared bytes.

## Optional pipeline bridge

`12_pipeline_snapshots.sql` preserves update inventory and serializes `compute`
and `trigger_details`; it assumes no undocumented child field in `compute`.
`13_pipeline_events.sql` examines available `event_log()` history. It maps update
timeline slices only when exactly one cluster is observed for the update. This
placement is explicitly labeled `EVENT_LOG_SINGLE_OBSERVED_CLUSTER_ESTIMATE`.
Earlier event-log retention gaps can hide other clusters, so this remains an
estimate. Multi-cluster updates stay in inventory without automatic network
attribution. Source corrections remove stale automatically derived mappings.

For verified cluster transitions, populate `bronze_pipeline_intervals` with
workspace/pipeline/update/cluster IDs and actual bounded execution intervals.
Use an `evidence_source` other than the adapter's reserved label. Populate
manual rows for the whole update's verified placements: their presence prevents
automatic estimates for that update and removes obsolete adapter-owned rows.
Populate
`job_task_run_id` and `parent_job_id` only when the trigger bridge is verified.
The matched orchestration task is then excluded as a separate network consumer;
the pipeline update owns its verified interval. Pipeline network bytes are not
automatically attributed to its parent job. Populate
`bronze_compute_classification` when a verified pipeline or job compute type is
available but the standard sources cannot identify it.

Source ingestion uses MERGE natural keys, preserves source byte totals and
retains older snapshots. It does not synthesize pre-retention history. Late
arrival is picked up only within the configured refresh overlap; rerun a wider
backfill for older corrections. Inspect `network_quality` before publishing a
dashboard or treating a failed refresh's intermediate gold tables as current.
