-- Render identifiers and date/workspace placeholders with the repository runner.
-- All timestamps, midnight boundaries, and daily reporting dates use UTC.
SET TIME ZONE 'UTC';
-- COMMAND ----------
CREATE SCHEMA IF NOT EXISTS __CATALOG__.__SCHEMA__;
-- COMMAND ----------
CREATE TABLE IF NOT EXISTS __CATALOG__.__SCHEMA__.bronze_node_timeline (
  workspace_id STRING, cluster_id STRING, instance_id STRING, driver BOOLEAN,
  start_time TIMESTAMP, end_time TIMESTAMP,
  network_received_bytes BIGINT, network_sent_bytes BIGINT, ingested_at TIMESTAMP
) USING DELTA
COMMENT 'Persisted classic-compute node interval counters in bytes; source system.compute.node_timeline. Not external ingress or NIC capacity.';
-- COMMAND ----------
CREATE TABLE IF NOT EXISTS __CATALOG__.__SCHEMA__.bronze_job_run_timeline (
  workspace_id STRING, job_id STRING, job_run_id STRING,
  period_start_time TIMESTAMP, period_end_time TIMESTAMP,
  result_state STRING, termination_code STRING, ingested_at TIMESTAMP
) USING DELTA;
-- COMMAND ----------
CREATE TABLE IF NOT EXISTS __CATALOG__.__SCHEMA__.bronze_job_task_run_timeline (
  workspace_id STRING, job_id STRING, job_run_id STRING, task_run_id STRING,
  task_key STRING, period_start_time TIMESTAMP, period_end_time TIMESTAMP,
  compute_ids ARRAY<STRING>, result_state STRING, termination_code STRING,
  ingested_at TIMESTAMP
) USING DELTA;
-- COMMAND ----------
CREATE TABLE IF NOT EXISTS __CATALOG__.__SCHEMA__.bronze_jobs (
  workspace_id STRING, job_id STRING, name STRING, change_time TIMESTAMP,
  delete_time TIMESTAMP, ingested_at TIMESTAMP
) USING DELTA;
-- COMMAND ----------
CREATE TABLE IF NOT EXISTS __CATALOG__.__SCHEMA__.bronze_clusters (
  workspace_id STRING, cluster_id STRING, cluster_name STRING,
  cluster_source STRING, change_time TIMESTAMP, delete_time TIMESTAMP,
  ingested_at TIMESTAMP
) USING DELTA;
-- COMMAND ----------
CREATE TABLE IF NOT EXISTS __CATALOG__.__SCHEMA__.bronze_billing_compute (
  record_id STRING, workspace_id STRING, job_id STRING, job_run_id STRING,
  cluster_id STRING, sku_name STRING, usage_start_time TIMESTAMP,
  usage_end_time TIMESTAMP, record_type STRING, ingested_at TIMESTAMP
) USING DELTA
COMMENT 'Optional billing evidence of serverless/SQL compute only. Usage quantity is never used as a byte proxy.';
-- COMMAND ----------
CREATE TABLE IF NOT EXISTS __CATALOG__.__SCHEMA__.bronze_pipeline_update_timeline (
  workspace_id STRING, pipeline_id STRING, update_id STRING,
  period_start_time TIMESTAMP, period_end_time TIMESTAMP,
  result_state STRING, compute_json STRING, trigger_details_json STRING,
  ingested_at TIMESTAMP
) USING DELTA;
-- COMMAND ----------
CREATE TABLE IF NOT EXISTS __CATALOG__.__SCHEMA__.bronze_pipeline_intervals (
  workspace_id STRING, pipeline_id STRING, update_id STRING, cluster_id STRING,
  period_start_time TIMESTAMP, period_end_time TIMESTAMP,
  parent_job_id STRING, parent_job_run_id STRING, job_task_run_id STRING,
  evidence_source STRING, ingested_at TIMESTAMP
) USING DELTA
COMMENT 'Explicit verified classic pipeline-to-cluster interval adapter. Bound intervals using event-log origin.cluster_id and lifecycle evidence; do not assume every cluster spans the entire update.';
-- COMMAND ----------
CREATE TABLE IF NOT EXISTS __CATALOG__.__SCHEMA__.bronze_compute_classification (
  workspace_id STRING, workload_type STRING, workload_id STRING, run_id STRING,
  compute_type STRING, evidence_source STRING, ingested_at TIMESTAMP
) USING DELTA
COMMENT 'Optional verified classification override for JOB or PIPELINE runs; compute_type CLASSIC, SERVERLESS, SQL_WAREHOUSE, MIXED, or UNKNOWN. Absence of metrics is not serverless evidence.';
