-- Opt-in per pipeline. event_log requires pipeline-owner or suitable view access.
-- A single observed cluster is an estimate of update placement, not lifecycle proof.
-- Multi-cluster updates are deliberately not automatically mapped. For precise
-- autoscaling/restart transitions, populate bronze_pipeline_intervals explicitly.
CREATE OR REPLACE VIEW __CATALOG__.__SCHEMA__.silver_pipeline_event_cluster_candidates AS
SELECT CAST(origin.org_id AS STRING) workspace_id, origin.pipeline_id pipeline_id,
  origin.update_id update_id, max(origin.cluster_id) cluster_id,
  count(DISTINCT origin.cluster_id) observed_cluster_count
FROM event_log('__PIPELINE_ID__')
-- Inspect all available event history, including earlier clusters for updates
-- that started before this refresh's lower bound.
WHERE timestamp < to_timestamp('__END_DATE__T00:00:00Z')
  AND CAST(origin.org_id AS STRING) IN (__WORKSPACE_IDS__)
  AND origin.pipeline_id = '__PIPELINE_ID__'
  AND origin.update_id IS NOT NULL AND origin.cluster_id IS NOT NULL
  AND EXISTS (
    SELECT 1 FROM __CATALOG__.__SCHEMA__.bronze_pipeline_update_timeline p
    WHERE p.workspace_id = CAST(origin.org_id AS STRING)
      AND p.pipeline_id = origin.pipeline_id AND p.update_id = origin.update_id
      AND p.period_start_time < to_timestamp('__END_DATE__T00:00:00Z')
      AND p.period_end_time > to_timestamp('__START_DATE__T00:00:00Z')
  )
GROUP BY origin.org_id, origin.pipeline_id, origin.update_id;
-- COMMAND ----------
DELETE FROM __CATALOG__.__SCHEMA__.bronze_pipeline_intervals t
WHERE t.evidence_source = 'EVENT_LOG_SINGLE_OBSERVED_CLUSTER_ESTIMATE'
  AND t.workspace_id IN (__WORKSPACE_IDS__)
  AND t.pipeline_id = '__PIPELINE_ID__'
  AND (
    EXISTS (
      SELECT 1 FROM __CATALOG__.__SCHEMA__.silver_pipeline_event_cluster_candidates e
      WHERE t.workspace_id = e.workspace_id AND t.pipeline_id = e.pipeline_id
        AND t.update_id = e.update_id
    )
    -- Manual placement owns the entire update, even when its event history is
    -- unavailable. Remove only this adapter's obsolete estimates, never manual rows.
    OR EXISTS (
      SELECT 1 FROM __CATALOG__.__SCHEMA__.bronze_pipeline_intervals manual
      WHERE t.workspace_id = manual.workspace_id AND t.pipeline_id = manual.pipeline_id
        AND t.update_id = manual.update_id
        AND coalesce(manual.evidence_source, '') <> 'EVENT_LOG_SINGLE_OBSERVED_CLUSTER_ESTIMATE'
    )
  );
-- COMMAND ----------
MERGE INTO __CATALOG__.__SCHEMA__.bronze_pipeline_intervals t
USING (
  SELECT p.workspace_id, p.pipeline_id, p.update_id, e.cluster_id,
    p.period_start_time, p.period_end_time,
    get_json_object(p.trigger_details_json, '$.job_task.job_id') parent_job_id,
    j.job_run_id parent_job_run_id,
    get_json_object(p.trigger_details_json, '$.job_task.job_task_run_id') job_task_run_id,
    'EVENT_LOG_SINGLE_OBSERVED_CLUSTER_ESTIMATE' evidence_source,
    current_timestamp() ingested_at
  FROM __CATALOG__.__SCHEMA__.bronze_pipeline_update_timeline p
  JOIN __CATALOG__.__SCHEMA__.silver_pipeline_event_cluster_candidates e
    ON p.workspace_id = e.workspace_id AND p.pipeline_id = e.pipeline_id AND p.update_id = e.update_id
  LEFT JOIN (
    SELECT DISTINCT workspace_id, job_id, task_run_id, job_run_id
    FROM __CATALOG__.__SCHEMA__.bronze_job_task_run_timeline
  ) j ON p.workspace_id = j.workspace_id
    AND get_json_object(p.trigger_details_json, '$.job_task.job_id') = j.job_id
    AND get_json_object(p.trigger_details_json, '$.job_task.job_task_run_id') = j.task_run_id
  WHERE e.observed_cluster_count = 1
    AND p.period_start_time < to_timestamp('__END_DATE__T00:00:00Z')
    -- Recreate every persisted slice for touched updates, including slices before
    -- this refresh, after deleting this adapter's previous placement estimate.
    AND p.period_end_time > p.period_start_time
    -- A bounded manual mapping is authoritative for every cluster and slice in
    -- the update. Adding a whole-update estimate would expand its verified bounds.
    AND NOT EXISTS (
      SELECT 1 FROM __CATALOG__.__SCHEMA__.bronze_pipeline_intervals manual
      WHERE p.workspace_id = manual.workspace_id AND p.pipeline_id = manual.pipeline_id
        AND p.update_id = manual.update_id
        AND coalesce(manual.evidence_source, '') <> 'EVENT_LOG_SINGLE_OBSERVED_CLUSTER_ESTIMATE'
    )
) s
ON t.workspace_id = s.workspace_id AND t.pipeline_id = s.pipeline_id
  AND t.update_id = s.update_id AND t.cluster_id = s.cluster_id
  AND t.period_start_time = s.period_start_time
WHEN MATCHED AND t.evidence_source = 'EVENT_LOG_SINGLE_OBSERVED_CLUSTER_ESTIMATE' THEN UPDATE SET *
WHEN NOT MATCHED THEN INSERT *;
