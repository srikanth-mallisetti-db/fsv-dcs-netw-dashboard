#!/usr/bin/env python3
"""Build the portable Fiserv AI/BI dashboard using only the Python standard library.

The generated dataset SQL deliberately uses bare view names. Set dataset_catalog
and dataset_schema when importing the dashboard. This program does not connect
to a workspace, execute SQL, create resources, or publish a dashboard.
"""

from __future__ import annotations

import argparse
import html
import json
import re
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "dashboards" / "fiserv_network_observability.lvdash.json"
SQL_OUTPUT = ROOT / "dashboards" / "dataset_queries.sql"
PREVIEW_OUTPUT = ROOT / "dashboards" / "design_preview.html"
GIB = "1073741824.0"
UTC_NOW = "convert_timezone(current_timezone(), 'UTC', localtimestamp())"
UTC_TODAY = f"to_date({UTC_NOW})"


def dataset(name: str, title: str, sql: str, fields: str) -> dict[str, Any]:
    result = {
        "name": name,
        "displayName": title,
        "queryLines": [line + "\n" for line in sql.strip().splitlines()],
    }
    DATASET_FIELDS[name] = set(fields.split())
    return result


DATASET_FIELDS: dict[str, set[str]] = {}


def make_datasets() -> list[dict[str, Any]]:
    DATASET_FIELDS.clear()
    daily_columns = f"""workspace_id, cluster_id, compute_type, workload_type,
       workload_id, job_id, job_run_id, pipeline_id, update_id, job_name,
       attribution_status, network_coverage,
       CASE WHEN attribution_status = 'SINGLE_ACTIVE_WORKLOAD'
            THEN received_bytes / {GIB} END AS estimated_received_gib,
       CASE WHEN attribution_status = 'SINGLE_ACTIVE_WORKLOAD'
            THEN sent_bytes / {GIB} END AS estimated_sent_gib,
       CASE WHEN attribution_status = 'SINGLE_ACTIVE_WORKLOAD'
            THEN total_bytes / {GIB} END AS estimated_total_gib"""
    daily_fields = "workspace_id cluster_id compute_type workload_type workload_id job_id job_run_id pipeline_id update_id job_name attribution_status network_coverage estimated_received_gib estimated_sent_gib estimated_total_gib"
    run_columns = f"""workspace_id, workload_type, workload_id, job_id, job_run_id,
       pipeline_id, update_id, job_name, compute_type,
       run_start_time, run_end_time,
       duration_seconds / 3600.0 AS duration_hours, result_state,
       network_coverage, attributed_total_bytes / {GIB} AS estimated_total_gib,
       concat_ws(':', workspace_id, workload_type, workload_id,
                 coalesce(job_run_id, update_id, 'UNKNOWN')) AS run_key,
       CASE WHEN network_coverage = 'NO_NODE_METRICS'
            THEN concat_ws(':', workspace_id, workload_type, workload_id,
                           coalesce(job_run_id, update_id, 'UNKNOWN'))
       END AS no_metrics_run_key"""
    run_fields = "workspace_id workload_type workload_id job_id job_run_id pipeline_id update_id job_name compute_type run_start_time run_end_time duration_hours result_state network_coverage estimated_total_gib run_key no_metrics_run_key"
    return [
        dataset(
            "cluster_daily", "Physical cluster bytes — daily UTC accounting",
            f"""SELECT usage_date AS daily_date, workspace_id, cluster_id, compute_type,
       measured_received_bytes / {GIB} AS measured_received_gib,
       measured_sent_bytes / {GIB} AS measured_sent_gib,
       measured_total_bytes / {GIB} AS measured_total_gib,
       single_active_total_bytes / {GIB} AS single_active_gib,
       shared_total_bytes / {GIB} AS shared_gib,
       unattributed_total_bytes / {GIB} AS unattributed_gib,
       observed_node_seconds / 3600.0 AS observed_node_hours
FROM network_cluster_daily
WHERE usage_date >= date_sub({UTC_TODAY}, 89)
ORDER BY daily_date, measured_total_gib DESC""",
            "daily_date workspace_id cluster_id compute_type measured_received_gib measured_sent_gib measured_total_gib single_active_gib shared_gib unattributed_gib observed_node_hours",
        ),
        dataset(
            "workload_daily", "Workload associations — daily UTC estimates",
            f"""SELECT usage_date AS daily_date, {daily_columns}
FROM network_daily
WHERE usage_date >= date_sub({UTC_TODAY}, 89)
ORDER BY daily_date DESC, estimated_total_gib DESC, workload_id, job_run_id""",
            "daily_date " + daily_fields,
        ),
        dataset(
            "job_history", "Workload associations — rolling 90 UTC dates",
            f"""SELECT usage_date AS history_date, {daily_columns}
FROM network_daily
WHERE usage_date >= date_sub({UTC_TODAY}, 89)
  AND usage_date <= {UTC_TODAY}
ORDER BY history_date, workload_id, job_run_id""",
            "history_date " + daily_fields,
        ),
        dataset(
            "run_history", "Workload runs started — rolling 90 UTC dates",
            f"""SELECT to_date(run_start_time) AS history_date, {run_columns}
FROM network_run_inventory
WHERE to_date(run_start_time) >= date_sub({UTC_TODAY}, 89)
  AND to_date(run_start_time) <= {UTC_TODAY}
ORDER BY run_start_time DESC""",
            "history_date " + run_fields,
        ),
        dataset(
            "cluster_segments", "Physical cluster timeline — observed intervals",
            f"""SELECT usage_date AS timeline_date, workspace_id, cluster_id,
       'CLASSIC' AS compute_type,
       segment_start, segment_end, segment_duration_seconds,
       date_trunc('MINUTE', segment_start) AS timeline_minute,
       active_workload_count, attribution_status,
       received_bytes / {GIB} AS received_gib,
       sent_bytes / {GIB} AS sent_gib,
       total_bytes / {GIB} AS total_gib,
       cluster_received_mbps, cluster_sent_mbps
FROM network_segments
WHERE usage_date >= date_sub({UTC_TODAY}, 89)
ORDER BY segment_start, workspace_id, cluster_id""",
            "timeline_date workspace_id cluster_id compute_type segment_start segment_end segment_duration_seconds timeline_minute active_workload_count attribution_status received_gib sent_gib total_gib cluster_received_mbps cluster_sent_mbps",
        ),
        dataset(
            "coverage_runs", "Run inventory — coverage including serverless",
            f"""SELECT to_date(run_start_time) AS timeline_date, {run_columns}
FROM network_run_inventory
WHERE to_date(run_start_time) >= date_sub({UTC_TODAY}, 89)
ORDER BY run_start_time DESC""",
            "timeline_date " + run_fields,
        ),
        dataset(
            "quality", "Pipeline checks and freshness — all configured workspaces",
            f"""WITH freshness AS (
  SELECT max(segment_end) AS latest_observed_interval_end_utc,
         convert_timezone(current_timezone(), 'UTC',
                          CAST(max(materialized_at) AS TIMESTAMP_NTZ)) AS latest_model_row_materialized_at_utc
  FROM network_segments
)
SELECT q.check_name, q.check_value, q.status, q.detail,
       convert_timezone(current_timezone(), 'UTC',
                        CAST(q.checked_at AS TIMESTAMP_NTZ)) AS checked_at_utc,
       f.latest_observed_interval_end_utc,
       f.latest_model_row_materialized_at_utc,
       {UTC_NOW} AS queried_at_utc,
       timestampdiff(MICROSECOND, f.latest_observed_interval_end_utc,
                     {UTC_NOW}) / 3600000000.0 AS observed_data_age_hours
FROM network_quality q
CROSS JOIN freshness f
ORDER BY CASE q.status WHEN 'FAIL' THEN 0 WHEN 'WARN' THEN 1 ELSE 2 END,
         q.check_name""",
            "check_name check_value status detail checked_at_utc latest_observed_interval_end_utc latest_model_row_materialized_at_utc queried_at_utc observed_data_age_hours",
        ),
    ]


def field(name: str, expression: str | None = None) -> dict[str, str]:
    return {"name": name, "expression": expression or f"`{name}`"}


def metric(column: str, aggregation: str = "SUM") -> dict[str, str]:
    if aggregation == "COUNT_DISTINCT":
        return field(f"countdistinct({column})", f"COUNT(DISTINCT `{column}`)")
    return field(f"{aggregation.lower()}({column})", f"{aggregation}(`{column}`)")


def number(places: int = 2, percent: bool = False) -> dict[str, Any]:
    return {"type": "number-percent" if percent else "number-plain",
            "decimalPlaces": {"type": "max", "places": places}}


def encoding(name: str, title: str, scale: str | None = None,
             unit: str | None = None) -> dict[str, Any]:
    result: dict[str, Any] = {"fieldName": name, "displayName": title}
    if scale:
        result["scale"] = {"type": scale}
        if scale == "quantitative":
            result["scale"]["domainMin"] = 0
    if unit:
        result["format"] = number()
        result["formatTemplate"] = "{{ @formatted }} " + unit
    return result


def frame(title: str, description: str = "") -> dict[str, Any]:
    result: dict[str, Any] = {"showTitle": True, "title": title}
    if description:
        result.update(showDescription=True, description=description)
    return result


def query(dataset_name: str, fields: list[dict[str, str]],
          disaggregated: bool = False, orders: list[dict[str, str]] | None = None) -> list[dict[str, Any]]:
    result: dict[str, Any] = {"datasetName": dataset_name, "fields": fields,
                              "disaggregated": disaggregated}
    if orders:
        result["orders"] = orders
    return [{"name": "main_query", "query": result}]


def text_widget(name: str, text: str) -> dict[str, Any]:
    return {"name": name, "multilineTextboxSpec": {"lines": text.splitlines(keepends=True)}}


def counter(name: str, title: str, dataset_name: str, column: str,
            aggregation: str = "SUM", unit: str = "", description: str = "") -> dict[str, Any]:
    value = metric(column, aggregation)
    return {"name": name, "queries": query(dataset_name, [value]),
            "spec": {"version": 2, "widgetType": "counter", "frame": frame(title, description),
                     "encodings": {"value": encoding(value["name"], title, unit=unit or None)}}}


def trend(name: str, title: str, dataset_name: str, date_column: str,
          measures: list[tuple[str, str]], aggregation: str = "SUM",
          unit: str = "GiB", description: str = "", widget_type: str = "line") -> dict[str, Any]:
    values = [metric(column, aggregation) for column, _ in measures]
    y: dict[str, Any] = {"scale": {"type": "quantitative", "domainMin": 0},
                       "fields": [encoding(value["name"], title, unit=unit)
                                  for value, (_, title) in zip(values, measures)]}
    return {"name": name, "queries": query(dataset_name, [field(date_column), *values],
                                             orders=[{"direction": "ASC", "expression": f"`{date_column}`"}]),
            "spec": {"version": 3, "widgetType": widget_type,
                     "frame": frame(title, description),
                     "encodings": {"x": encoding(date_column, "UTC date / time", "temporal"), "y": y}}}


def coverage_bar() -> dict[str, Any]:
    count = metric("run_key", "COUNT_DISTINCT")
    return {"name": "history-coverage-bar",
            "queries": query("run_history", [field("network_coverage"), count]),
            "spec": {"version": 3, "widgetType": "bar",
                     "frame": frame("Coverage of runs started", "Run inventory stays visible when bytes are unknown."),
                     "encodings": {
                         "x": encoding("network_coverage", "Coverage", "categorical"),
                         "y": encoding(count["name"], "Workload runs", "quantitative")}}}


def table(name: str, title: str, dataset_name: str,
          columns: list[tuple[str, str, str | None]], description: str = "") -> dict[str, Any]:
    return {"name": name, "queries": query(dataset_name, [field(column) for column, _, _ in columns], True),
            "spec": {"version": 2, "widgetType": "table", "frame": frame(title, description),
                     "encodings": {"columns": [encoding(column, title, unit=unit)
                                                for column, title, unit in columns]}}}


def freshness_table() -> dict[str, Any]:
    columns = [
        ("latest_observed_interval_end_utc", "Latest observed interval end (UTC)", None),
        ("latest_model_row_materialized_at_utc", "Latest segment row materialized (UTC)", None),
        ("checked_at_utc", "Quality checked (UTC)", None),
        ("queried_at_utc", "Dashboard queried (UTC)", None),
        ("observed_data_age_hours", "Observed data age", "hours"),
    ]
    values = [metric(column, "MAX") for column, _, _ in columns]
    return {"name": "pipeline-freshness", "queries": query("quality", values),
            "spec": {"version": 2, "widgetType": "table",
                     "frame": frame("Pipeline freshness · all configured workspaces",
                                    "Age is time since the latest observed interval, not measured ingestion delay. Idle estates can also have old data."),
                     "encodings": {"columns": [encoding(value["name"], title, unit=unit)
                                                for value, (_, title, unit) in zip(values, columns)]}}}


def filter_widget(name: str, title: str, dataset_names: list[str], column: str,
                  widget_type: str = "filter-multi-select", date_days: int | None = None) -> dict[str, Any]:
    queries = []
    bindings = []
    for dataset_name in dataset_names:
        query_name = f"{dataset_name}_{column}"
        queries.append({"name": query_name,
                        "query": {"datasetName": dataset_name, "fields": [field(column)],
                                  "disaggregated": False}})
        bindings.append({"fieldName": column, "displayName": title, "queryName": query_name})
    spec: dict[str, Any] = {"version": 2, "widgetType": widget_type,
                            "frame": frame(title), "encodings": {"fields": bindings}}
    if widget_type == "filter-text-entry":
        spec.update(matchMode="exact-match", isCaseSensitive=True)
    if date_days is not None:
        spec["selection"] = {"defaultSelection": {"range": {
            "dataType": "DATE", "min": {"value": f"now-{date_days - 1}d/d"},
            "max": {"value": "now/d"}}}}
    return {"name": name, "queries": queries, "spec": spec}


def placement(widget: dict[str, Any], x: int, y: int, width: int, height: int) -> dict[str, Any]:
    return {"widget": widget, "position": {"x": x, "y": y, "width": width, "height": height}}


def page(name: str, title: str, layout: list[dict[str, Any]], global_filters: bool = False) -> dict[str, Any]:
    return {"name": name, "displayName": title,
            "pageType": "PAGE_TYPE_GLOBAL_FILTERS" if global_filters else "PAGE_TYPE_CANVAS",
            "layoutVersion": "GRID_V1", "layout": layout}


WORKLOAD_COLUMNS = [
    ("daily_date", "UTC date", None), ("workspace_id", "Workspace", None),
    ("workload_type", "Type", None), ("workload_id", "Job / pipeline ID", None),
    ("job_run_id", "Job run ID", None), ("update_id", "Pipeline update ID", None),
    ("cluster_id", "Cluster", None), ("compute_type", "Compute", None),
    ("estimated_received_gib", "Estimated receive", "GiB"),
    ("estimated_sent_gib", "Estimated send", "GiB"),
    ("network_coverage", "Coverage", None), ("attribution_status", "Association", None),
]
RUN_COLUMNS = [
    ("run_start_time", "Recorded start (UTC)", None), ("workspace_id", "Workspace", None),
    ("workload_type", "Type", None), ("workload_id", "Job / pipeline ID", None),
    ("job_run_id", "Job run ID", None), ("update_id", "Pipeline update ID", None),
    ("compute_type", "Compute", None), ("duration_hours", "Recorded duration", "hours"),
    ("result_state", "Result", None), ("network_coverage", "Coverage", None),
    ("estimated_total_gib", "Recorded-run estimate", "GiB"),
]


def make_dashboard() -> dict[str, Any]:
    datasets = make_datasets()
    daily = page("daily", "Daily usage", [
        placement(text_widget("daily-title", "# Fiserv · Network observability\n"), 0, 0, 12, 1),
        placement(text_widget("daily-intro", "**Start with physical cluster traffic, then inspect workload associations.** Dates use UTC. GiB = 2³⁰ bytes. Node metrics include all network traffic, including internal traffic; they do not isolate external storage or prove network saturation.\n"), 0, 1, 12, 2),
        placement(filter_widget("daily-date", "Daily window (UTC)", ["cluster_daily", "workload_daily"], "daily_date", "filter-date-range-picker", 7), 0, 3, 4, 2),
        placement(filter_widget("daily-workload-type", "Workload type", ["workload_daily"], "workload_type"), 4, 3, 4, 2),
        placement(filter_widget("daily-association", "Association status", ["workload_daily"], "attribution_status"), 8, 3, 4, 2),
        placement(counter("daily-measured", "Observed physical traffic", "cluster_daily", "measured_total_gib", unit="GiB", description="Receive + send, counted once per cluster interval."), 0, 5, 4, 3),
        placement(counter("daily-exclusive", "Single active workload bucket", "cluster_daily", "single_active_gib", unit="GiB", description="Time-prorated association; workload consumption is estimated."), 4, 5, 4, 3),
        placement(counter("daily-shared", "Shared / ambiguous bucket", "cluster_daily", "shared_gib", unit="GiB", description="Concurrent workloads; bytes are not assigned to each run."), 8, 5, 4, 3),
        placement(trend("daily-traffic", "Physical receive and send", "cluster_daily", "daily_date", [("measured_received_gib", "Receive"), ("measured_sent_gib", "Send")], description="Cluster totals remain independent of job and workload filters."), 0, 8, 6, 6),
        placement(trend("daily-buckets", "Physical traffic by association bucket", "cluster_daily", "daily_date", [("single_active_gib", "Single active workload"), ("shared_gib", "Shared / ambiguous"), ("unattributed_gib", "Unattributed")], widget_type="bar", description="These disjoint buckets reconcile to observed physical traffic."), 6, 8, 6, 6),
        placement(table("daily-workload-table", "Daily workload / run breakdown", "workload_daily", WORKLOAD_COLUMNS, "NULL means unknown. Choose one Job ID in global filters, then open 90-day history."), 0, 14, 12, 7),
        placement(text_widget("daily-accounting-note", "**Keep the accounting separate.** Physical cluster totals above do not change when selecting a Job ID. Workload estimates below exclude shared / ambiguous and unattributed traffic. Do not add estimated run bytes to physical bytes, or multiply shared traffic across concurrent runs. Business-hour patterns must be interpreted in the customer's local timezone.\n"), 0, 21, 12, 2),
        placement(table("daily-cluster-table", "Physical daily cluster accounting", "cluster_daily", [
            ("daily_date", "UTC date", None), ("workspace_id", "Workspace", None),
            ("cluster_id", "Cluster", None), ("compute_type", "Compute", None),
            ("measured_total_gib", "Physical total", "GiB"),
            ("single_active_gib", "Single active", "GiB"), ("shared_gib", "Shared / ambiguous", "GiB"),
            ("unattributed_gib", "Unattributed", "GiB"), ("observed_node_hours", "Observed node time", "hours"),
        ], "Observed node time is not a coverage percentage or cluster wall-clock runtime."), 0, 23, 12, 6),
    ])
    history = page("history", "90-day history", [
        placement(text_widget("history-title", "# Job and pipeline history · 90 UTC dates\n"), 0, 0, 12, 1),
        placement(text_widget("history-intro", "Select one **Job ID** in global filters for the requested job drilldown. For pipelines, clear Job ID and enter a Pipeline ID below. The query retains today and the previous 89 UTC dates, independently of the Daily usage window. Unobserved dates are missing observations, not zero traffic.\n"), 0, 1, 12, 2),
        placement(filter_widget("history-date", "History window (UTC)", ["job_history", "run_history"], "history_date", "filter-date-range-picker", 90), 0, 3, 4, 2),
        placement(filter_widget("history-pipeline", "Pipeline ID (exact)", ["job_history", "run_history"], "pipeline_id", "filter-text-entry"), 4, 3, 4, 2),
        placement(filter_widget("history-workload-type", "Workload type", ["job_history", "run_history"], "workload_type"), 8, 3, 4, 2),
        placement(counter("history-estimated", "Single-workload traffic estimate", "job_history", "estimated_total_gib", unit="GiB", description="Daily associated bytes; excludes concurrent workloads."), 0, 5, 4, 3),
        placement(counter("history-runs", "Runs with a recorded start", "run_history", "run_key", "COUNT_DISTINCT", description="Unique job runs / pipeline updates by recorded start date."), 4, 5, 4, 3),
        placement(counter("history-no-metrics", "Runs without node metrics", "run_history", "no_metrics_run_key", "COUNT_DISTINCT", description="Includes unsupported serverless network telemetry."), 8, 5, 4, 3),
        placement(trend("history-estimates", "Daily single-workload network estimates", "job_history", "history_date", [("estimated_received_gib", "Estimated receive"), ("estimated_sent_gib", "Estimated send")], description="A time association, not an exact job-level byte meter. Blank / NULL is unknown."), 0, 8, 12, 6),
        placement(trend("history-duration", "Mean recorded duration by run start day", "run_history", "history_date", [("duration_hours", "Mean recorded duration")], aggregation="AVG", unit="hours", description="Timeline envelope by UTC recorded start date; ongoing / retained history can be partial."), 0, 14, 6, 6),
        placement(coverage_bar(), 6, 14, 6, 6),
        placement(table("history-run-table", "Run and pipeline update inventory", "run_history", RUN_COLUMNS, "Recorded-run estimates can span dates outside this window; recorded duration can be partial. Daily estimates use usage date."), 0, 20, 12, 7),
        placement(text_widget("history-limitations", "**Serverless comparison:** workload duration and result are available, but node timeline network telemetry does not cover serverless compute. Its byte values remain NULL. A shorter duration after migration alone does not establish that network contention has been resolved; use external Azure / storage evidence and a controlled comparison.\n"), 0, 27, 12, 2),
    ])
    timeline = page("timeline", "Cluster timeline & coverage", [
        placement(text_widget("timeline-title", "# Cluster timeline and observation gaps\n"), 0, 0, 12, 1),
        placement(text_widget("timeline-intro", "Select one **Workspace** and **Cluster ID** to investigate an incident. Rate charts show the maximum observed cluster interval rate within each UTC minute. Without a cluster selection they show the busiest observed cluster per minute. Node metrics cannot identify a storage endpoint, network error cause, or infrastructure capacity.\n"), 0, 1, 12, 2),
        placement(filter_widget("timeline-date", "Incident window (UTC)", ["cluster_segments", "coverage_runs"], "timeline_date", "filter-date-range-picker", 7), 0, 3, 6, 2),
        placement(filter_widget("timeline-cluster", "Cluster ID (select one)", ["cluster_segments"], "cluster_id", "filter-single-select"), 6, 3, 6, 2),
        placement(counter("timeline-max-rx", "Peak observed receive rate", "cluster_segments", "cluster_received_mbps", "MAX", "Mbps", "Maximum aggregate node rate over an observed interval."), 0, 5, 4, 3),
        placement(counter("timeline-max-tx", "Peak observed send rate", "cluster_segments", "cluster_sent_mbps", "MAX", "Mbps", "Mbps is decimal megabits per second, not MiB/s."), 4, 5, 4, 3),
        placement(counter("timeline-concurrency", "Peak concurrent workloads", "cluster_segments", "active_workload_count", "MAX", description="Distinct runs / updates active on the measured cluster."), 8, 5, 4, 3),
        placement(trend("timeline-rate", "Observed cluster network rate", "cluster_segments", "timeline_minute", [("cluster_received_mbps", "Receive"), ("cluster_sent_mbps", "Send")], "MAX", "Mbps", "Peaks are interval estimates. The line can bridge missing samples; inspect interval rows below."), 0, 8, 12, 6),
        placement(table("timeline-segments", "Observed intervals and concurrent workload counts", "cluster_segments", [
            ("segment_start", "Interval start (UTC)", None), ("segment_end", "Interval end (UTC)", None),
            ("workspace_id", "Workspace", None), ("cluster_id", "Cluster", None),
            ("segment_duration_seconds", "Interval", "seconds"),
            ("active_workload_count", "Active workloads", None), ("attribution_status", "Association", None),
            ("total_gib", "Physical traffic", "GiB"),
            ("cluster_received_mbps", "Receive rate", "Mbps"), ("cluster_sent_mbps", "Send rate", "Mbps"),
        ], "Shared traffic is retained once. Job filters do not remove concurrent or unattributed cluster traffic."), 0, 14, 12, 7),
        placement(table("timeline-coverage", "Runs with and without usable network observations", "coverage_runs", RUN_COLUMNS, "Workspace, compute and job filters apply. The Cluster ID filter affects the physical timeline only."), 0, 21, 12, 7),
        placement(text_widget("timeline-gaps", "**Read unknowns explicitly.** NO_NODE_METRICS and NULL bytes are not zero usage. PARTIAL coverage and shared intervals can understate workload estimates. Node time counts only reported nodes; it cannot establish completeness without an independent expected-node inventory. Late system-table arrivals can change recent dates after refresh.\n"), 0, 28, 12, 2),
        placement(text_widget("quality-section", "## Pipeline health · complete configured scope\n"), 0, 30, 12, 1),
        placement(freshness_table(), 0, 31, 12, 4),
        placement(table("pipeline-quality", "Pipeline quality checks · all configured workspaces", "quality", [
            ("status", "Status", None), ("check_name", "Check", None),
            ("check_value", "Affected rows / clusters", None),
            ("detail", "Interpretation", None), ("checked_at_utc", "Checked (UTC)", None),
        ], "PASS / WARN / FAIL checks are computed over the pipeline's full configured scope. Dashboard filters do not limit them."), 0, 35, 12, 7),
    ])
    all_datasets = [item["name"] for item in datasets if item["name"] != "quality"]
    workloads = ["workload_daily", "job_history", "run_history", "coverage_runs"]
    filters = page("global_filters", "Global filters", [
        placement(filter_widget("global-workspace", "Workspace", all_datasets, "workspace_id"), 0, 0, 4, 2),
        placement(filter_widget("global-job", "Job ID (select one)", workloads, "job_id", "filter-single-select"), 4, 0, 4, 2),
        placement(filter_widget("global-compute", "Compute type", all_datasets, "compute_type"), 8, 0, 4, 2),
    ], True)
    return {"datasets": datasets, "pages": [daily, history, timeline, filters],
            "uiSettings": {"theme": {
                "canvasBackgroundColor": {"light": "#F6F8FB", "dark": "#17212B"},
                "widgetBackgroundColor": {"light": "#FFFFFF", "dark": "#101820"},
                "widgetBorderColor": {"light": "#FFFFFF", "dark": "#101820"},
                "fontColor": {"light": "#152536", "dark": "#E6EEF5"},
                "selectionColor": {"light": "#0072B2", "dark": "#8BD5FF"},
                "visualizationColors": ["#0072B2", "#E69F00", "#009E73", "#CC79A7", "#D55E00", "#56B4E9"],
                "widgetHeaderAlignment": "LEFT", "widgetCornerRadius": 8,
            }}}


def encoding_fields(value: Any) -> set[str]:
    if isinstance(value, list):
        return set().union(*(encoding_fields(item) for item in value)) if value else set()
    if isinstance(value, dict):
        result = {value["fieldName"]} if "fieldName" in value else set()
        return result | set().union(*(encoding_fields(item) for item in value.values()))
    return set()


def validate(dashboard: dict[str, Any]) -> None:
    """Check shape, layout and local binding contracts; this is not remote SQL validation."""
    datasets = {item["name"]: item for item in dashboard["datasets"]}
    assert len(datasets) == len(dashboard["datasets"]), "Duplicate dataset names"
    for item in datasets.values():
        assert item["queryLines"] and all(line.endswith("\n") for line in item["queryLines"])
        sql = "".join(item["queryLines"])
        assert ";" not in sql, f"Dataset {item['name']} contains multiple statements"
        assert not re.search(r"\b(?:FROM|JOIN)\s+[`\w-]+\.", sql, re.IGNORECASE), "Use bare view names"
        assert "current_date()" not in sql.lower(), "Dataset dates must derive the current UTC date explicitly"
    names: set[str] = set()
    versions = {"counter": 2, "table": 2, "line": 3, "bar": 3,
                "filter-single-select": 2, "filter-multi-select": 2,
                "filter-date-range-picker": 2, "filter-text-entry": 2}
    for canvas in dashboard["pages"]:
        assert canvas["pageType"] in {"PAGE_TYPE_CANVAS", "PAGE_TYPE_GLOBAL_FILTERS"}
        assert canvas["layoutVersion"] == "GRID_V1"
        occupancy: dict[int, set[int]] = {}
        for item in canvas["layout"]:
            widget, position = item["widget"], item["position"]
            name = widget["name"]
            assert re.fullmatch(r"[A-Za-z0-9_-]{1,60}", name), f"Invalid widget name: {name}"
            assert name not in names, f"Duplicate widget name: {name}"
            names.add(name)
            assert 0 <= position["x"] and position["x"] + position["width"] <= 12
            assert position["height"] > 0 and position["y"] >= 0
            for y in range(position["y"], position["y"] + position["height"]):
                row = occupancy.setdefault(y, set())
                columns = set(range(position["x"], position["x"] + position["width"]))
                assert not row & columns, f"Overlapping widgets on {canvas['name']} row {y}"
                row.update(columns)
            if "multilineTextboxSpec" in widget:
                assert "spec" not in widget
                continue
            spec = widget["spec"]
            kind = spec["widgetType"]
            assert spec["version"] == versions[kind], f"Invalid version: {name}"
            assert spec["frame"]["showTitle"] and spec["frame"]["title"]
            queries = {item["name"]: item["query"] for item in widget["queries"]}
            for widget_query in queries.values():
                dataset_name = widget_query["datasetName"]
                assert dataset_name in datasets
                fields = widget_query["fields"]
                assert len({item["name"] for item in fields}) == len(fields)
                for selected in fields:
                    references = re.findall(r"`([^`]+)`", selected["expression"])
                    assert set(references) <= DATASET_FIELDS[dataset_name], f"Unknown columns in {name}: {references}"
                    assert "COUNT(DISTINCT(" not in selected["expression"], f"Invalid COUNT DISTINCT in {name}"
            if kind.startswith("filter-"):
                for binding in spec["encodings"]["fields"]:
                    assert binding["queryName"] in queries
                    bound_query = queries[binding["queryName"]]
                    assert bound_query["disaggregated"] is False
                    assert binding["fieldName"] in {item["name"] for item in bound_query["fields"]}
            else:
                selected_names = {item["name"] for selected in queries.values() for item in selected["fields"]}
                assert encoding_fields(spec["encodings"]) == selected_names, f"Field mismatch in {name}"
            if kind == "counter":
                assert position["height"] >= 3
                assert "color" not in spec["encodings"]["value"]
        assert all(columns == set(range(12)) for columns in occupancy.values()), f"Unfilled row on {canvas['name']}"
    assert "theme" in dashboard["uiSettings"]
    daily_date_names = [item["widget"]["name"] for item in dashboard["pages"][0]["layout"]
                        if item["widget"].get("spec", {}).get("widgetType") == "filter-date-range-picker"]
    assert daily_date_names == ["daily-date"]
    assert not any(item["widget"]["spec"]["widgetType"] == "filter-date-range-picker"
                   for item in dashboard["pages"][-1]["layout"]), "Global date would clip the job history"
    quality_queries = []
    for canvas in dashboard["pages"]:
        for item in canvas["layout"]:
            widget = item["widget"]
            if widget.get("spec", {}).get("widgetType", "").startswith("filter-"):
                assert all(binding["query"]["datasetName"] != "quality" for binding in widget["queries"]), "Pipeline-wide quality must not be filtered to a dashboard slice"
            if widget["name"] in {"pipeline-freshness", "pipeline-quality"}:
                quality_queries.append(widget["queries"][0]["query"]["datasetName"])
    assert quality_queries == ["quality", "quality"], "Expose both data freshness and quality checks"


def preview_html(dashboard: dict[str, Any]) -> str:
    """A data-free visual layout review; it does not emulate the AI/BI renderer."""
    def prose(text: str) -> str:
        escaped = html.escape(text.strip())
        if escaped.startswith("# "):
            return f"<h2>{escaped[2:]}</h2>"
        if escaped.startswith("## "):
            return f"<h2>{escaped[3:]}</h2>"
        escaped = re.sub(r"\*\*(.*?)\*\*", r"<strong>\1</strong>", escaped)
        return f"<p>{escaped}</p>"

    sections = []
    ordered_pages = [dashboard["pages"][-1], *dashboard["pages"][:-1]]
    for canvas in ordered_pages:
        cards = []
        for item in canvas["layout"]:
            widget, position = item["widget"], item["position"]
            style = f"grid-column:{position['x'] + 1}/span {position['width']};grid-row:{position['y'] + 1}/span {position['height']}"
            if "multilineTextboxSpec" in widget:
                cards.append(f'<article class="prose" style="{style}">{prose("".join(widget["multilineTextboxSpec"]["lines"]))}</article>')
                continue
            spec = widget["spec"]
            kind = spec["widgetType"]
            title = html.escape(spec["frame"]["title"])
            description = html.escape(spec["frame"].get("description", ""))
            subtitle = f"<p class=description>{description}</p>" if description else ""
            if kind.startswith("filter-"):
                selected = "All · set in AI/BI"
                if kind == "filter-date-range-picker":
                    minimum = spec["selection"]["defaultSelection"]["range"]["min"]["value"]
                    days = int(re.search(r"now-(\d+)d", minimum).group(1)) + 1
                    selected = f"Last {days} UTC dates"
                body = f'<div class="filter-value">{selected}<span>⌄</span></div>'
            elif kind == "counter":
                body = '<div class="counter-value">—</div><div class="empty-note">Awaiting validated warehouse data</div>'
            elif kind == "table":
                headers = "".join(f"<th>{html.escape(column['displayName'])}</th>" for column in spec["encodings"]["columns"])
                body = f'<div class="table-scroll"><table><thead><tr>{headers}</tr></thead></table></div><div class="table-empty">Rows will appear after ingestion and warehouse query validation.</div>'
            else:
                y = spec["encodings"]["y"]
                series = y.get("fields", [y])
                labels = "".join(f'<span class="legend"><i style="background:{dashboard["uiSettings"]["theme"]["visualizationColors"][index]}"></i>{html.escape(value.get("displayName", ""))}</span>' for index, value in enumerate(series))
                body = f'<div class="legend-row">{labels}</div><div class="chart-empty">Chart will populate from the dashboard dataset.<br><small>No customer observations or synthetic values are shown.</small></div>'
            cards.append(f'<article class="card {kind}" style="{style}"><h3>{title}</h3>{subtitle}{body}</article>')
        sections.append(f'<section id="{canvas["name"]}"><div class="page-label">{html.escape(canvas["displayName"])}</div><div class="dashboard-grid">{"".join(cards)}</div></section>')
    navigation = "".join(f'<a href="#{canvas["name"]}">{html.escape(canvas["displayName"])}</a>' for canvas in ordered_pages)
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fiserv network observability — dashboard design preview</title><style>
:root{{font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#152536;background:#f6f8fb;font-size:14px}}
*{{box-sizing:border-box}}body{{margin:0}}header{{padding:24px 32px;background:#152536;color:#fff}}header h1{{font-size:24px;margin:0 0 8px}}header p{{margin:0;color:#c5d6e7}}
nav{{display:flex;gap:24px;padding:14px 32px;background:#fff;border-bottom:1px solid #dbe3eb;position:sticky;top:0;z-index:1}}a{{color:#0072b2;text-decoration:none;font-weight:600}}
main{{max-width:1540px;margin:auto;padding:16px 24px}}section{{scroll-margin-top:60px;margin-bottom:44px}}.page-label{{font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:#647b90;margin:12px 0}}
.dashboard-grid{{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));grid-auto-rows:48px;gap:10px}}.card{{background:#fff;border-radius:8px;padding:14px;overflow:hidden}}
.prose{{padding:0 4px;overflow:hidden}}h2{{font-size:23px;margin:0}}h3{{font-size:14px;margin:0 0 8px}}p{{line-height:1.55;margin:0}}.description{{font-size:12px;color:#647b90;margin-bottom:8px}}
.counter-value{{font-size:36px;line-height:1.05;font-weight:650}}.empty-note{{font-size:11px;color:#8093a5;margin-top:3px}}.filter-value{{background:#f6f8fb;padding:9px 12px;border-radius:4px;color:#647b90;display:flex;justify-content:space-between}}
.counter .description{{font-size:11px;line-height:1.4;margin-bottom:4px}}
.legend-row{{display:flex;gap:18px;margin:12px 0;font-size:12px}}.legend{{display:flex;align-items:center;gap:5px}}.legend i{{width:8px;height:8px;border-radius:50%;display:inline-block}}
.chart-empty{{margin-top:18px;min-height:135px;height:60%;border-left:1px solid #dae4ed;border-bottom:1px solid #dae4ed;background:repeating-linear-gradient(to top,transparent,transparent 39px,#eef3f7 40px);display:flex;flex-direction:column;align-items:center;justify-content:center;color:#8093a5;text-align:center;gap:5px}}.chart-empty small{{font-size:11px}}
.table-scroll{{overflow:auto;margin:16px -4px 0}}table{{border-collapse:collapse;width:100%;font-size:11px}}th{{text-align:left;white-space:nowrap;color:#647b90;padding:12px 10px;background:#f6f8fb;border-bottom:1px solid #dbe3eb}}.table-empty{{padding-top:60px;text-align:center;color:#8093a5;font-size:12px}}
footer{{padding:24px;text-align:center;color:#647b90;font-size:12px}}@media(max-width:800px){{main{{padding:12px}}nav{{gap:14px;overflow:auto;white-space:nowrap}}.dashboard-grid{{display:block}}.card,.prose{{margin-bottom:12px;min-height:88px}}.line,.bar,.table{{min-height:250px}}.counter{{min-height:150px}}}}
</style></head><body><header><h1>Fiserv · Network observability</h1><p>Design preview · no customer data · generated from the same layout as the AI/BI dashboard</p></header>
<nav>{navigation}</nav><main>{''.join(sections)}</main>
<footer>This file reviews layout and metric interpretation. Actual AI/BI rendering and all dataset SQL require validation in the selected Azure Databricks workspace.</footer></body></html>
"""


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Validate local bindings and that committed artifacts are current")
    parser.add_argument("--output", type=Path, default=OUTPUT, help="JSON output path")
    args = parser.parse_args()
    dashboard = make_dashboard()
    validate(dashboard)
    json_text = json.dumps(dashboard, ensure_ascii=False, indent=2) + "\n"
    sql_text = "-- Generated by scripts/build_dashboard.py. Test every statement on the target warehouse.\n-- Set catalog/schema externally; all source view names are intentionally bare.\n\n"
    sql_text += "\n\n".join(f"-- Dataset: {item['name']} — {item['displayName']}\n{''.join(item['queryLines']).rstrip()};" for item in dashboard["datasets"]) + "\n"
    preview_text = preview_html(dashboard)
    if args.check:
        assert args.output.read_text(encoding="utf-8") == json_text, "Dashboard JSON is stale; run scripts/build_dashboard.py"
        assert SQL_OUTPUT.read_text(encoding="utf-8") == sql_text, "Dataset SQL is stale; run scripts/build_dashboard.py"
        assert PREVIEW_OUTPUT.read_text(encoding="utf-8") == preview_text, "Design preview is stale; run scripts/build_dashboard.py"
        print(f"Validated {len(dashboard['datasets'])} datasets and {sum(len(p['layout']) for p in dashboard['pages'])} widgets; artifacts are current. Remote SQL and rendering validation are still required.")
        return
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json_text, encoding="utf-8", newline="\n")
    SQL_OUTPUT.write_text(sql_text, encoding="utf-8", newline="\n")
    PREVIEW_OUTPUT.write_text(preview_text, encoding="utf-8", newline="\n")
    print(f"Wrote {args.output}\nWrote {SQL_OUTPUT}\nWrote {PREVIEW_OUTPUT}")


if __name__ == "__main__":
    main()
