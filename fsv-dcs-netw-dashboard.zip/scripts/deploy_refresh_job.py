#!/usr/bin/env python3
"""Upload the refresh sources and create or reset a paused serverless job.

This deployer uses an explicitly selected Databricks CLI profile. It uploads only
the Python package files, numbered SQL templates, and refresh notebook needed by
the job; credentials and local CLI configuration are never packaged. Standard
serverless mode suits this hourly refresh, which has no startup latency SLA.
"""

from __future__ import annotations

import argparse
import base64
from datetime import datetime, timezone
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import tempfile


REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from fsv_network.databricks_cli import DatabricksCLI
from fsv_network.pipeline import Settings, default_dates


def positive_int(value: str) -> int:
    result = int(value)
    if result <= 0:
        raise argparse.ArgumentTypeError("must be a positive integer")
    return result


def workspace_paths(value: str) -> tuple[str, str]:
    """Return the API path and corresponding /Workspace filesystem path."""
    if not value.startswith("/") or value.startswith("//"):
        raise ValueError("workspace-root must be an absolute workspace folder path")
    if any(part in {".", ".."} for part in value.split("/")) or any(ord(c) < 32 for c in value):
        raise ValueError("workspace-root cannot contain traversal or control characters")
    root = str(PurePosixPath(value))
    if root == "/Workspace":
        root = "/"
    elif root.startswith("/Workspace/"):
        root = root[len("/Workspace"):]
    if root == "/":
        raise ValueError("workspace-root must name a dedicated deployment folder")
    return root, "/Workspace" + root


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--profile", required=True, help="Explicit authenticated Databricks CLI profile")
    result.add_argument("--warehouse-id", required=True,
                        help="Deployment warehouse context; the notebook itself runs Spark SQL on serverless")
    result.add_argument("--catalog", required=True)
    result.add_argument("--schema", required=True)
    result.add_argument("--workspace-ids", required=True, help="Comma-separated numeric source workspace IDs")
    result.add_argument("--workspace-root", required=True,
                        help="Dedicated workspace folder, for example /Workspace/Shared/fiserv-network")
    result.add_argument("--job-id", type=positive_int,
                        help="Explicit job to reset; omit to create a new job, even when names match")
    result.add_argument("--state-file", type=Path,
                        help="Optional local JSON job ID file; use the git-ignored state/ directory")
    result.add_argument("--activate", action="store_true",
                        help="Enable the hourly schedule; omitted means PAUSED, including on reset")
    result.add_argument("--include-pipelines", action="store_true")
    result.add_argument("--pipeline-id", action="append", default=[])
    result.add_argument("--without-billing", action="store_true")
    result.add_argument("--lookback-days", type=positive_int, default=7)
    result.add_argument("--history-days", type=positive_int, default=120)
    return result


def deployment(args: argparse.Namespace) -> tuple[dict, list[tuple[Path, str, str]], str]:
    """Build and validate the complete deployment before the first remote call."""
    api_root, filesystem_root = workspace_paths(args.workspace_root)
    start, end, history = default_dates(
        datetime.now(timezone.utc).date(), args.lookback_days, args.history_days,
    )
    settings = Settings(
        args.catalog, args.schema,
        tuple(part.strip() for part in args.workspace_ids.split(",")),
        start, end, history, not args.without_billing, args.include_pipelines,
        tuple(args.pipeline_id),
    )
    if not args.profile.strip() or not args.warehouse_id.strip():
        raise ValueError("profile and warehouse-id cannot be blank")
    sources = [(REPO_ROOT / "src" / "fsv_network" / name,
                f"{api_root}/src/fsv_network/{name}", "RAW")
               for name in ("__init__.py", "pipeline.py")]
    sql_files = sorted(path for path in (REPO_ROOT / "sql").glob("*.sql")
                       if re.match(r"^[0-9]+_", path.name))
    if not sql_files:
        raise ValueError("No numbered SQL templates found in the repository")
    sources.extend((path, f"{api_root}/sql/{path.name}", "RAW") for path in sql_files)
    notebook_path = f"{api_root}/notebooks/refresh_network_observability"
    sources.append((REPO_ROOT / "notebooks" / "refresh_network_observability.py", notebook_path, "SOURCE"))
    for local_path, _, _ in sources:
        if not local_path.is_file():
            raise ValueError(f"Required deployment source is missing: {local_path}")

    job = json.loads((REPO_ROOT / "config" / "refresh_job.example.json").read_text(encoding="utf-8"))
    tasks = job.get("tasks", [])
    if len(tasks) != 1 or "notebook_task" not in tasks[0]:
        raise ValueError("The refresh job template must contain exactly one notebook task")
    classic_keys = {"new_cluster", "job_clusters", "job_cluster_key", "existing_cluster_id",
                    "instance_pool_id", "node_type_id", "num_workers", "autoscale", "spark_version"}
    if classic_keys & job.keys() or classic_keys & tasks[0].keys():
        raise ValueError("The refresh job template must use serverless compute")
    if not isinstance(job.get("schedule"), dict):
        raise ValueError("The refresh job template must contain its hourly schedule")
    job["schedule"]["pause_status"] = "UNPAUSED" if args.activate else "PAUSED"
    job["performance_target"] = "STANDARD"
    job.setdefault("tags", {})["aidevkit_project"] = "ai-dev-kit"
    notebook = tasks[0]["notebook_task"]
    notebook["notebook_path"] = notebook_path
    notebook["source"] = "WORKSPACE"
    notebook["base_parameters"] = {
        "repo_root": filesystem_root,
        "catalog": settings.catalog,
        "schema": settings.schema,
        "workspace_ids": ",".join(sorted(set(settings.workspace_ids))),
        "lookback_days": str(args.lookback_days),
        "history_days": str(args.history_days),
        "include_billing": str(settings.include_billing).lower(),
        "include_pipelines": str(settings.include_pipelines).lower(),
        "pipeline_ids": ",".join(settings.pipeline_ids),
    }
    return job, sources, api_root


def write_state(path: Path, job_id: int) -> None:
    """Save only the job identity, atomically, without authentication material."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n", dir=path.parent, prefix=path.name + ".",
                                         suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            os.chmod(temporary, 0o600)
            handle.write(json.dumps({"job_id": job_id}) + "\n")
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main(argv: list[str] | None = None) -> None:
    argument_parser = parser()
    args = argument_parser.parse_args(argv)
    try:
        job, sources, api_root = deployment(args)
    except ValueError as error:
        argument_parser.error(str(error))
    client = DatabricksCLI(args.profile, args.warehouse_id)
    directories = {api_root, *(str(PurePosixPath(remote).parent) for _, remote, _ in sources)}
    for directory in sorted(directories, key=lambda value: (value.count("/"), value)):
        client.command(["api", "post", "/api/2.0/workspace/mkdirs"], {"path": directory})
    for local_path, remote_path, import_format in sources:
        body = {
            "path": remote_path,
            "format": import_format,
            "overwrite": True,
            "content": base64.b64encode(local_path.read_bytes()).decode("ascii"),
        }
        if import_format == "SOURCE":
            body["language"] = "PYTHON"
        print(f"Uploading {local_path.relative_to(REPO_ROOT)}", file=sys.stderr, flush=True)
        client.command(["api", "post", "/api/2.0/workspace/import"], body)
    if args.job_id is not None:
        client.command(["jobs", "reset"], {"job_id": args.job_id, "new_settings": job})
        job_id = args.job_id
    else:
        response = client.command(["jobs", "create"], job)
        job_id = int(response["job_id"])
        if job_id <= 0:
            raise RuntimeError("Databricks returned an invalid job ID")
    if args.state_file is not None:
        write_state(args.state_file, job_id)
    print(json.dumps({"job_id": job_id}))


if __name__ == "__main__":
    main()
