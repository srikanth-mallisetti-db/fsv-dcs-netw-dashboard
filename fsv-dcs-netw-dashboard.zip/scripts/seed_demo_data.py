#!/usr/bin/env python3
"""Seed and deploy an isolated, conspicuously labeled synthetic dashboard demo.

Only <catalog>.network_observability_demo is written. Production reporting tables
are read with WHERE false to copy their output schemas; no production data is
copied or changed. Use --render-only to inspect the SQL and dashboard locally.
The same --as-of-utc value reproduces the deterministic workload/rate patterns.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from fsv_network.databricks_cli import DatabricksCLI


LABEL = "SYNTHETIC DEMO"
DISPLAY_NAME = "SYNTHETIC DEMO — Fiserv network bandwidth & workload history"
TABLES = ("network_segments", "network_cluster_daily", "network_run_inventory",
          "network_daily", "network_quality")


def identifier(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value):
        raise ValueError("Catalog and schema must be simple SQL identifiers")
    return f"`{value}`"


def utc_timestamp(value: str) -> datetime:
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise argparse.ArgumentTypeError("--as-of-utc requires an explicit UTC offset")
    return result.astimezone(timezone.utc).replace(second=0, microsecond=0)


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--profile", required=True)
    p.add_argument("--warehouse-id", required=True)
    p.add_argument("--host", required=True)
    p.add_argument("--catalog", required=True)
    p.add_argument("--schema", required=True)
    p.add_argument("--source-schema", required=True)
    p.add_argument("--workspace-id", required=True)
    p.add_argument("--parent-path", required=True)
    p.add_argument("--as-of-utc", type=utc_timestamp,
                   default=datetime.now(timezone.utc).replace(second=0, microsecond=0))
    p.add_argument("--output-dir", type=Path, default=ROOT / "build" / "synthetic-demo")
    p.add_argument("--state-file", type=Path, default=ROOT / "state" / "demo-dashboard.json")
    p.add_argument("--render-only", action="store_true")
    p.add_argument("--publish", action="store_true")
    return p


def build_plan(args: argparse.Namespace) -> list[tuple[str, str]]:
    if args.schema != "network_observability_demo" or args.schema == args.source_schema:
        raise ValueError("This script can write only the separate network_observability_demo schema")
    if not re.fullmatch(r"[0-9]+", args.workspace_id):
        raise ValueError("workspace-id must be the explicitly selected numeric workspace ID")
    if not args.profile.strip() or not args.warehouse_id.strip():
        raise ValueError("An explicit profile and warehouse ID are required")
    if not args.host.startswith("https://"):
        raise ValueError("host must be an HTTPS workspace URL")
    target = f"{identifier(args.catalog)}.{identifier(args.schema)}"
    source = f"{identifier(args.catalog)}.{identifier(args.source_schema)}"
    cutoff = args.as_of_utc.strftime("%Y-%m-%d %H:%M:%S")
    today = args.as_of_utc.date().isoformat()
    stamp = f"TIMESTAMP_NTZ '{cutoff}'"
    days = f"SELECT date_sub(DATE '{today}', CAST(id AS INT)) usage_date, 89 - CAST(id AS INT) day_index FROM range(90)"
    shared_cluster = "DEMO_CLASSIC_SHARED"
    batch_cluster = "DEMO_CLASSIC_SETTLEMENT"
    plan = [("create_demo_schema", f"CREATE SCHEMA IF NOT EXISTS {target} COMMENT 'SYNTHETIC DEMO ONLY — contains no observed customer telemetry'")]
    for table_name in TABLES:
        plan.append((f"empty_demo_{table_name}",
                     f"CREATE OR REPLACE TABLE {target}.{table_name} USING DELTA COMMENT 'SYNTHETIC DEMO ONLY — deterministic artificial observations' AS SELECT * FROM {source}.{table_name} WHERE false"))
    plan.append(("seed_workload_runs", f"""CREATE OR REPLACE TABLE {target}.demo_seed_runs USING DELTA
COMMENT 'SYNTHETIC DEMO ONLY — parent workload inventory, not Databricks job records'
AS WITH days AS ({days}), candidates AS (
  SELECT usage_date, day_index, 'JOB' workload_type, 'DEMO_JOB_HISTORICAL' workload_id,
    concat('DEMO_RUN_HISTORICAL_', date_format(usage_date, 'yyyyMMdd')) run_id,
    '[SYNTHETIC DEMO] Historical storage backfill' job_name,
    CASE WHEN day_index >= 75 AND pmod(day_index, 3) <> 0 THEN 'SERVERLESS' ELSE 'CLASSIC' END compute_type,
    '{shared_cluster}' cluster_id,
    timestampadd(HOUR, 14, CAST(usage_date AS TIMESTAMP_NTZ)) run_start_time,
    timestampadd(HOUR, CASE WHEN pmod(day_index, 7) = 0 THEN 22 ELSE 16 END,
                 CAST(usage_date AS TIMESTAMP_NTZ)) run_end_time,
    'SUCCEEDED' result_state
  FROM days
  UNION ALL
  SELECT usage_date, day_index, 'JOB', 'DEMO_JOB_DAILY_INGEST',
    concat('DEMO_RUN_DAILY_', date_format(usage_date, 'yyyyMMdd')),
    '[SYNTHETIC DEMO] Scheduled daily ingestion', 'CLASSIC', '{shared_cluster}',
    timestampadd(HOUR, 14, CAST(usage_date AS TIMESTAMP_NTZ)),
    timestampadd(HOUR, CASE WHEN pmod(day_index, 7) = 0 THEN 18 ELSE 15 END,
                 CAST(usage_date AS TIMESTAMP_NTZ)),
    CASE WHEN pmod(day_index, 14) = 0 THEN 'TIMEDOUT' ELSE 'SUCCEEDED' END
  FROM days
  UNION ALL
  SELECT usage_date, day_index, 'JOB', 'DEMO_JOB_SETTLEMENT',
    concat('DEMO_RUN_SETTLEMENT_', date_format(usage_date, 'yyyyMMdd')),
    '[SYNTHETIC DEMO] Payment settlement batch', 'CLASSIC', '{batch_cluster}',
    timestampadd(HOUR, 9, CAST(usage_date AS TIMESTAMP_NTZ)),
    timestampadd(HOUR, 10, CAST(usage_date AS TIMESTAMP_NTZ)), 'SUCCEEDED'
  FROM days
  UNION ALL
  SELECT usage_date, day_index, 'PIPELINE', 'DEMO_PIPELINE_INGEST',
    concat('DEMO_UPDATE_', date_format(usage_date, 'yyyyMMdd')),
    '[SYNTHETIC DEMO] Lakeflow declarative ingestion', 'CLASSIC', '{shared_cluster}',
    timestampadd(HOUR, 16, CAST(usage_date AS TIMESTAMP_NTZ)),
    timestampadd(HOUR, 18, CAST(usage_date AS TIMESTAMP_NTZ)), 'SUCCEEDED'
  FROM days
)
SELECT '{args.workspace_id}' workspace_id, usage_date, day_index, workload_type,
  workload_id, run_id, concat(workload_type, ':', workload_id, ':', run_id) workload_key,
  CASE WHEN workload_type = 'JOB' THEN workload_id END job_id,
  CASE WHEN workload_type = 'JOB' THEN run_id END job_run_id,
  CASE WHEN workload_type = 'PIPELINE' THEN workload_id END pipeline_id,
  CASE WHEN workload_type = 'PIPELINE' THEN run_id END update_id,
  job_name, compute_type, CASE WHEN compute_type = 'CLASSIC' THEN cluster_id END cluster_id,
  run_start_time, least(run_end_time, {stamp}) run_end_time,
  CASE WHEN run_end_time <= {stamp} THEN result_state END result_state
FROM candidates WHERE run_start_time < {stamp}"""))
    plan.append(("seed_physical_classic_segments", f"""INSERT INTO {target}.network_segments (
  usage_date, workspace_id, cluster_id, compute_type, segment_start, segment_end,
  segment_duration_seconds, active_workload_count, active_workload_keys,
  attribution_status, workload_type, workload_id, job_id, job_run_id, pipeline_id, update_id,
  received_bytes, sent_bytes, total_bytes, observed_node_seconds, observed_nodes,
  cluster_received_mbps, cluster_sent_mbps, materialized_at)
WITH days AS ({days}), intervals AS (
  SELECT d.usage_date, d.day_index, CAST(m.id AS INT) minute_of_day, c.cluster_id,
    timestampadd(MINUTE, CAST(m.id AS INT), CAST(d.usage_date AS TIMESTAMP_NTZ)) segment_start,
    least(timestampadd(MINUTE, CAST(m.id + 1 AS INT), CAST(d.usage_date AS TIMESTAMP_NTZ)), {stamp}) segment_end
  FROM days d CROSS JOIN range(1440) m
  CROSS JOIN (VALUES ('{shared_cluster}'), ('{batch_cluster}')) c(cluster_id)
), active AS (
  SELECT i.*, count(DISTINCT r.workload_key) active_workload_count,
    collect_set(r.workload_key) active_workload_keys,
    max(r.workload_type) active_type, max(r.workload_id) active_id,
    max(r.job_id) job_id, max(r.job_run_id) job_run_id,
    max(r.pipeline_id) pipeline_id, max(r.update_id) update_id,
    (CASE WHEN i.cluster_id = '{shared_cluster}' THEN 2.0 ELSE 0.5 END
     + sum(CASE WHEN r.workload_id = 'DEMO_JOB_HISTORICAL'
         THEN CASE WHEN pmod(i.day_index, 7) = 0 THEN 280.0 + pmod(i.day_index * 17, 80) ELSE 40.0 + pmod(i.day_index, 9) END
       WHEN r.workload_id = 'DEMO_JOB_DAILY_INGEST' THEN 18.0
       WHEN r.workload_id = 'DEMO_PIPELINE_INGEST' THEN 12.0
       WHEN r.workload_id = 'DEMO_JOB_SETTLEMENT' THEN 9.0 ELSE 0.0 END))
       * (1.0 + 0.10 * sin(i.day_index + i.minute_of_day / 25.0)) gib_per_hour
  FROM intervals i LEFT JOIN {target}.demo_seed_runs r
    ON r.usage_date = i.usage_date AND r.cluster_id = i.cluster_id AND r.compute_type = 'CLASSIC'
    AND r.run_start_time < i.segment_end AND r.run_end_time > i.segment_start
  WHERE i.segment_start < {stamp}
  GROUP BY ALL
), measured AS (
  SELECT *, timestampdiff(SECOND, segment_start, segment_end) * 1.0 segment_seconds,
    gib_per_hour * 1073741824.0 * timestampdiff(SECOND, segment_start, segment_end) / 3600.0 total
  FROM active
)
SELECT usage_date, '{args.workspace_id}', cluster_id, 'CLASSIC', segment_start, segment_end,
  segment_seconds, active_workload_count, active_workload_keys,
  CASE WHEN active_workload_count = 1 THEN 'SINGLE_ACTIVE_WORKLOAD'
    WHEN active_workload_count > 1 THEN 'SHARED_AMBIGUOUS' ELSE 'UNATTRIBUTED' END,
  CASE WHEN active_workload_count = 1 THEN active_type
    WHEN active_workload_count > 1 THEN 'SHARED_AMBIGUOUS' ELSE 'UNATTRIBUTED' END,
  CASE WHEN active_workload_count = 1 THEN active_id END,
  CASE WHEN active_workload_count = 1 THEN job_id END,
  CASE WHEN active_workload_count = 1 THEN job_run_id END,
  CASE WHEN active_workload_count = 1 THEN pipeline_id END,
  CASE WHEN active_workload_count = 1 THEN update_id END,
  total * 0.9, total * 0.1, total, segment_seconds * 4, 4,
  total * 0.9 * 8.0 / segment_seconds / 1000000.0,
  total * 0.1 * 8.0 / segment_seconds / 1000000.0, current_timestamp()
FROM measured"""))
    plan.append(("derive_demo_cluster_daily", f"""INSERT INTO {target}.network_cluster_daily (
  usage_date, workspace_id, cluster_id, compute_type, measured_received_bytes,
  measured_sent_bytes, measured_total_bytes, single_active_total_bytes, shared_total_bytes,
  unattributed_total_bytes, observed_node_seconds, observed_cluster_seconds,
  peak_received_mbps, peak_sent_mbps, materialized_at)
SELECT usage_date, workspace_id, cluster_id, compute_type,
  sum(received_bytes), sum(sent_bytes), sum(total_bytes),
  sum(CASE WHEN attribution_status = 'SINGLE_ACTIVE_WORKLOAD' THEN total_bytes ELSE 0 END),
  sum(CASE WHEN attribution_status = 'SHARED_AMBIGUOUS' THEN total_bytes ELSE 0 END),
  sum(CASE WHEN attribution_status = 'UNATTRIBUTED' THEN total_bytes ELSE 0 END),
  sum(observed_node_seconds), sum(segment_duration_seconds),
  max(cluster_received_mbps), max(cluster_sent_mbps), current_timestamp()
FROM {target}.network_segments GROUP BY usage_date, workspace_id, cluster_id, compute_type"""))
    plan.append(("derive_demo_run_inventory", f"""INSERT INTO {target}.network_run_inventory (
  workspace_id, workload_type, workload_id, run_id, workload_key,
  job_id, job_run_id, pipeline_id, update_id, run_start_time, run_end_time, result_state,
  job_name, compute_type, compute_evidence, duration_seconds, network_coverage,
  attributed_total_bytes, associated_segments, exclusive_segments, shared_segments, materialized_at)
WITH observations AS (
  SELECT r.workload_key, count(s.segment_start) associated_segments,
    count(CASE WHEN s.attribution_status = 'SINGLE_ACTIVE_WORKLOAD' THEN 1 END) exclusive_segments,
    count(CASE WHEN s.attribution_status = 'SHARED_AMBIGUOUS' THEN 1 END) shared_segments,
    sum(CASE WHEN s.attribution_status = 'SINGLE_ACTIVE_WORKLOAD' THEN s.total_bytes END) attributed_total_bytes
  FROM {target}.demo_seed_runs r LEFT JOIN {target}.network_segments s
    ON r.usage_date = s.usage_date AND r.workspace_id = s.workspace_id
    AND array_contains(s.active_workload_keys, r.workload_key)
  GROUP BY r.workload_key
)
SELECT r.workspace_id, r.workload_type, r.workload_id, r.run_id, r.workload_key,
  r.job_id, r.job_run_id, r.pipeline_id, r.update_id, r.run_start_time, r.run_end_time,
  r.result_state, r.job_name, r.compute_type, 'SYNTHETIC_DEMO_CLASSIFICATION',
  timestampdiff(SECOND, r.run_start_time, r.run_end_time) * 1.0,
  CASE WHEN o.exclusive_segments > 0 AND o.shared_segments > 0 THEN 'PARTIAL_EXCLUSIVE'
    WHEN o.exclusive_segments > 0 THEN 'OBSERVED_EXCLUSIVE'
    WHEN o.shared_segments > 0 THEN 'SHARED_ONLY' ELSE 'NO_NODE_METRICS' END,
  o.attributed_total_bytes, o.associated_segments, o.exclusive_segments, o.shared_segments,
  current_timestamp()
FROM {target}.demo_seed_runs r JOIN observations o ON r.workload_key = o.workload_key"""))
    plan.append(("derive_demo_workload_daily", f"""INSERT INTO {target}.network_daily (
  usage_date, workspace_id, cluster_id, compute_type, workload_type, workload_id,
  job_id, job_run_id, pipeline_id, update_id, attribution_status,
  received_bytes, sent_bytes, total_bytes, observed_node_seconds, allocated_cluster_seconds,
  job_name, result_state, run_duration_seconds, network_coverage, materialized_at)
WITH measured AS (
  SELECT usage_date, workspace_id, cluster_id, compute_type, workload_type, workload_id,
    job_id, job_run_id, pipeline_id, update_id, attribution_status,
    sum(received_bytes) received_bytes, sum(sent_bytes) sent_bytes, sum(total_bytes) total_bytes,
    sum(observed_node_seconds) observed_node_seconds, sum(segment_duration_seconds) allocated_cluster_seconds
  FROM {target}.network_segments GROUP BY ALL
)
SELECT m.*, r.job_name, r.result_state, r.duration_seconds,
  CASE WHEN m.attribution_status = 'SINGLE_ACTIVE_WORKLOAD' THEN r.network_coverage
    ELSE m.attribution_status END, current_timestamp()
FROM measured m LEFT JOIN {target}.network_run_inventory r
  ON m.workspace_id = r.workspace_id AND m.workload_type = r.workload_type
  AND m.workload_id = r.workload_id AND coalesce(m.job_run_id, m.update_id) = r.run_id
UNION ALL
SELECT to_date(r.run_start_time), r.workspace_id, CAST(NULL AS STRING), r.compute_type,
  r.workload_type, r.workload_id, r.job_id, r.job_run_id, r.pipeline_id, r.update_id,
  CASE WHEN r.network_coverage = 'SHARED_ONLY' THEN 'SHARED_ONLY' ELSE 'NO_NODE_METRICS' END,
  CAST(NULL AS DOUBLE), CAST(NULL AS DOUBLE), CAST(NULL AS DOUBLE),
  CAST(NULL AS DOUBLE), CAST(NULL AS DOUBLE), r.job_name, r.result_state, r.duration_seconds,
  r.network_coverage, current_timestamp()
FROM {target}.network_run_inventory r
WHERE NOT EXISTS (SELECT 1 FROM measured m
  WHERE m.workspace_id = r.workspace_id AND m.workload_type = r.workload_type
    AND m.workload_id = r.workload_id AND coalesce(m.job_run_id, m.update_id) = r.run_id)"""))
    plan.append(("derive_demo_quality", f"""INSERT INTO {target}.network_quality
WITH checks AS (
  SELECT 'byte_conservation' check_name,
    CAST(CASE WHEN abs(sum(measured_total_bytes)
      - (SELECT sum(total_bytes) FROM {target}.network_segments))
      > greatest(0.01, sum(measured_total_bytes) * 1e-9) THEN 1 ELSE 0 END AS DOUBLE) check_value,
    'FAIL' nonzero_status, 'Synthetic physical segment and cluster-daily bytes reconcile.' detail
  FROM {target}.network_cluster_daily
  UNION ALL SELECT 'negative_or_missing_segment_bytes', CAST(count_if(total_bytes < 0 OR total_bytes IS NULL) AS DOUBLE),
    'FAIL', 'Synthetic measured intervals have positive durations and nonnegative counters.' FROM {target}.network_segments
  UNION ALL SELECT 'unmeasured_rows_have_bytes', CAST(count_if(attribution_status IN ('NO_NODE_METRICS', 'SHARED_ONLY')
    AND total_bytes IS NOT NULL) AS DOUBLE), 'FAIL', 'Unknown synthetic workload bytes remain NULL.' FROM {target}.network_daily
  UNION ALL SELECT 'out_of_scope_workspace', CAST(count_if(workspace_id <> '{args.workspace_id}') AS DOUBLE),
    'FAIL', 'Only the explicitly selected workspace ID labels these artificial rows.' FROM {target}.network_daily
  UNION ALL SELECT 'invalid_source_node_intervals', CAST(0 AS DOUBLE), 'WARN',
    'This demo generates intervals directly and does not ingest customer node sources.'
  UNION ALL SELECT 'overlapping_same_node_intervals', CAST(0 AS DOUBLE), 'FAIL',
    'Synthetic per-cluster minute intervals are generated without overlaps.'
  UNION ALL SELECT 'runs_without_node_metrics', CAST(count_if(network_coverage = 'NO_NODE_METRICS') AS DOUBLE),
    'WARN', 'Synthetic serverless runs intentionally have no network byte observations.' FROM {target}.network_run_inventory
  UNION ALL SELECT 'runs_with_shared_traffic', CAST(count_if(network_coverage IN ('SHARED_ONLY', 'PARTIAL_EXCLUSIVE')) AS DOUBLE),
    'WARN', 'Synthetic concurrent workloads retain shared bytes only in cluster accounting.' FROM {target}.network_run_inventory
  UNION ALL SELECT 'unknown_compute_type_runs', CAST(count_if(compute_type = 'UNKNOWN') AS DOUBLE),
    'WARN', 'All synthetic compute classifications are explicit demo inputs.' FROM {target}.network_run_inventory
  UNION ALL SELECT 'no_node_data', CAST(CASE WHEN count(*) = 0 THEN 1 ELSE 0 END AS DOUBLE),
    'WARN', 'Synthetic classic intervals exist; these are not observed customer counters.' FROM {target}.network_segments
  UNION ALL SELECT 'node_source_stale', CAST(CASE WHEN max(segment_end) < {stamp} - INTERVAL 2 DAYS THEN 1 ELSE 0 END AS DOUBLE),
    'WARN', 'Freshness is relative to the synthetic seed cutoff, not a customer ingestion SLA.' FROM {target}.network_segments
)
SELECT check_name, check_value,
  CASE WHEN check_value = 0 THEN 'PASS' ELSE nonzero_status END,
  concat('SYNTHETIC DEMO — ', detail), current_timestamp() FROM checks"""))
    plan.append(("validate_demo_invariants", f"""SELECT
  assert_true((SELECT count(*) FROM {target}.network_quality WHERE status = 'FAIL') = 0, 'Synthetic quality invariant failed'),
  assert_true((SELECT count(*) FROM {target}.network_run_inventory WHERE compute_type = 'SERVERLESS' AND attributed_total_bytes IS NOT NULL) = 0, 'Synthetic serverless bytes must be NULL'),
  assert_true((SELECT count(*) FROM {target}.network_daily WHERE workspace_id <> '{args.workspace_id}') = 0, 'Unexpected synthetic workspace'),
  assert_true(abs((SELECT sum(total_bytes) FROM {target}.network_segments)
    - (SELECT sum(total_bytes) FROM {target}.network_daily))
    <= greatest(0.01, (SELECT sum(total_bytes) FROM {target}.network_segments) * 1e-9), 'Synthetic daily physical conservation failed')"""))
    return plan


def demo_dashboard() -> dict:
    dashboard = json.loads((ROOT / "dashboards" / "fiserv_network_observability.lvdash.json").read_text(encoding="utf-8"))
    for page in dashboard["pages"]:
        page["displayName"] = f"{LABEL} · {page['displayName']}"
        if page["pageType"] != "PAGE_TYPE_CANVAS":
            continue
        text_widgets = [item["widget"] for item in page["layout"] if "multilineTextboxSpec" in item["widget"]]
        title = text_widgets[0]["multilineTextboxSpec"]["lines"]
        title[0] = "# SYNTHETIC DEMO — " + title[0].removeprefix("# ")
        text_widgets[1]["multilineTextboxSpec"]["lines"].insert(0,
            "**SYNTHETIC DEMO: all rows, patterns, job IDs and results are artificial; no customer telemetry is shown. Illustrative data; no serverless performance conclusion can be drawn.** ")
        # Make room for the explicit demo disclosure without changing the source dashboard.
        for item in page["layout"]:
            if item["widget"] is text_widgets[1]:
                item["position"]["height"] += 1
            elif item["position"]["y"] >= 3:
                item["position"]["y"] += 1
    return dashboard


def write_state(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n", dir=path.parent, prefix=path.name + ".",
                                     suffix=".tmp", delete=False) as handle:
        temporary = Path(handle.name)
        os.chmod(temporary, 0o600)
        handle.write(json.dumps(value, indent=2) + "\n")
    os.replace(temporary, path)


def main(argv: list[str] | None = None) -> None:
    p = parser()
    args = p.parse_args(argv)
    try:
        plan = build_plan(args)
    except ValueError as error:
        p.error(str(error))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    dashboard = demo_dashboard()
    dashboard_path = args.output_dir / "synthetic_demo.lvdash.json"
    dashboard_path.write_text(json.dumps(dashboard, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
    (args.output_dir / "seed_demo.sql").write_text("\n\n".join(f"-- {label}\n{sql};" for label, sql in plan) + "\n", encoding="utf-8", newline="\n")
    if args.render_only:
        print(f"Rendered {len(plan)} synthetic-only SQL statements and {dashboard_path}")
        return
    client = DatabricksCLI(args.profile, args.warehouse_id)
    auth = client.command(["auth", "env"])
    actual_host = auth.get("env", {}).get("DATABRICKS_HOST", "").rstrip("/")
    if actual_host != args.host.rstrip("/"):
        raise ValueError("Explicit profile host does not match --host; no demo mutations performed")
    previous = json.loads(args.state_file.read_text(encoding="utf-8")) if args.state_file.exists() else None
    identity = {"synthetic": True, "profile": args.profile, "host": args.host.rstrip("/"),
                "catalog": args.catalog, "schema": args.schema}
    if previous is not None and any(previous.get(key) != value for key, value in identity.items()):
        raise ValueError("Existing demo dashboard state belongs to a different target; no demo mutations performed")
    if previous is not None:
        existing = client.command(["lakeview", "get", previous["dashboard_id"]])
        if not existing.get("display_name", "").startswith(LABEL):
            raise ValueError("State points to a dashboard that is not clearly labeled synthetic; refusing update")
    for label, sql in plan:
        print(f"Executing demo-only step {label}", flush=True)
        client.execute(sql, args.catalog, None if label == "create_demo_schema" else args.schema)
    command = [sys.executable, "-m", "fsv_network", "validate-dashboard", "--profile", args.profile,
               "--warehouse-id", args.warehouse_id, "--catalog", args.catalog, "--schema", args.schema,
               "--workspace-ids", args.workspace_id, "--dashboard-file", str(dashboard_path)]
    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(ROOT / "src") + os.pathsep + environment.get("PYTHONPATH", "")
    subprocess.run(command, env=environment, cwd=ROOT, check=True)
    flags = ["--dataset-catalog", args.catalog, "--dataset-schema", args.schema,
             "--warehouse-id", args.warehouse_id]
    body = {"serialized_dashboard": json.dumps(dashboard), "display_name": DISPLAY_NAME}
    if previous is not None:
        dashboard_id = previous["dashboard_id"]
        client.command(["lakeview", "update", dashboard_id, *flags], body)
    else:
        body["parent_path"] = args.parent_path
        response = client.command(["lakeview", "create", *flags], body)
        dashboard_id = response["dashboard_id"]
    state = {**identity, "warehouse_id": args.warehouse_id, "dashboard_id": dashboard_id,
             "as_of_utc": args.as_of_utc.isoformat(), "published": False,
             "draft_url": f"{args.host.rstrip('/')}/sql/dashboardsv3/{dashboard_id}"}
    # Persist the identity immediately after create/update, before further calls.
    write_state(args.state_file, state)
    if args.publish:
        client.command(["lakeview", "publish", dashboard_id, "--warehouse-id", args.warehouse_id])
        state["published"] = True
        state["published_url"] = state["draft_url"] + "/published"
        write_state(args.state_file, state)
    print(json.dumps(state, indent=2), flush=True)


if __name__ == "__main__":
    main()
