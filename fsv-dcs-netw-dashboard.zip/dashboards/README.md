# Fiserv network observability dashboard

The portable AI/BI artifact is `fiserv_network_observability.lvdash.json`. It uses standard AI/BI widgets and the gold views created by the SQL pipeline. No DAB files, workspace IDs, warehouse IDs, or catalog/schema names are embedded.

Open `design_preview.html` for a visual review of the page layout and metric definitions. It contains no customer observations or synthetic values and does not emulate the Databricks renderer.

## Report flow

| Page | Main question | Visuals and details |
| --- | --- | --- |
| Daily usage | Which clusters moved the most data, and which run associations are available? | Physical GiB counters; receive/send trend; disjoint association buckets; daily job run and pipeline update details; reconciled cluster accounting. |
| 90-day history | How has one job's associated traffic changed over the previous 90 UTC dates? | Estimated receive/send trend; run durations; run coverage counts; complete run and pipeline update inventory. |
| Cluster timeline & coverage | When did cluster traffic spike, how many workloads overlapped, and is the pipeline healthy? | Peak interval Mbps; minute-level rate chart; interval details with concurrent workloads; run coverage; model/source freshness timestamps; PASS/WARN/FAIL checks. |

```text
Daily usage
  Physical receive/send → accounting buckets → daily run details
                                                 │
                              Select one Job ID in global filters
                                                 ↓
90-day history
  Daily estimates → run duration + coverage → run inventory

Cluster timeline & coverage
  Select workspace + cluster → interval rates → overlaps + gaps
```

## Filters and drilldown

1. Select workspace and compute type in **Global filters**. Selecting `SERVERLESS` keeps its run inventory visible; physical classic network charts have no serverless observations.
2. Inspect the Daily usage table to find a job's `job_id` and `job_run_id`, then select one **Job ID** in Global filters and open **90-day history**. Job IDs are workspace-scoped, so select one workspace when investigating a single job.
3. For pipelines, clear the Job ID filter and enter an exact Pipeline ID on the history page.
4. Use the history page's date control to narrow its independently maintained 90-date window. The Daily usage date filter cannot clip this history. The initial daily and incident windows span seven UTC dates, including today.
5. Select a cluster on the incident page. Without a selection, the rate chart shows the maximum observed cluster interval rate within each minute across selected workspaces. Each of its receive/send series can therefore come from a different cluster or interval.

Workspace and compute filters bind to the six usage/inventory datasets. Job filters bind only to workload daily/history and run inventories. Workload type, association status and Pipeline ID filters also affect their explicit workload datasets only. Physical cluster accounting remains independent of these workload filters, because removing other runs from shared clusters would create misleading cluster totals. The incident Cluster ID filter affects the physical intervals; the run inventory remains workspace/job/compute-scoped. The seventh dataset exposes pipeline-wide quality and freshness over all configured workspaces; dashboard filters deliberately do not narrow those checks.

## Read the measures carefully

- **Physical GiB** counts received plus sent node-interface bytes once per observed cluster interval. It includes internal traffic; it does not measure only storage ingestion. The three physical association buckets are disjoint and reconcile to this total.
- **Single-workload GiB estimates** associate time-prorated node bytes with the one active workload in an interval. Background and internal traffic can still be present. These are not exact per-job network counters.
- **Shared / ambiguous GiB** stays in a physical cluster bucket. It is not copied into every concurrent job, and it is excluded from the per-workload estimates. No even-split estimate is presented.
- **Unattributed GiB** has observed network bytes and no associated tracked workload.
- **NULL bytes** and missing dates mean unknown observations. In particular, node timeline metrics do not measure serverless network usage; no zero is substituted for an unsupported serverless byte measurement.
- **Mbps** is decimal megabits per second (`bytes × 8 / interval seconds / 1,000,000`), aggregated over observed nodes. It is an interval rate, not an instantaneous spike measurement or percentage of infrastructure capacity.
- **Observed node hours** sums reported node seconds. It is neither cluster wall-clock runtime nor a telemetry coverage percentage.
- The run count and duration chart use **recorded run start dates**. Daily network estimates use **usage dates**. A long-running workload can contribute daily bytes to this window even if its run began before the inventory window. The inventory's recorded-run estimate can also extend beyond a narrowed history date selection. **Recorded duration** is the envelope of retained timeline periods, with task periods as a fallback when the parent job timeline is absent. It can be partial during initial collection, for an ongoing run, or after source retention has removed early periods.
- Recent observations can change as system tables arrive late. Lines may visually bridge missing samples; the interval and coverage tables are the diagnostic evidence.
- **Freshness** separates the latest observed interval end, latest segment row materialization time, quality check time, and dashboard query time. Observed data age is the hours since the latest interval; it is not a measured ingestion delay. An idle estate, a historical reporting window, or missing telemetry can also produce old observations. NULL timestamps mean no observed segment row was available.
- **Quality status** is computed by `network_quality`: PASS means a configured check found no affected records; WARN highlights interpretability/coverage issues; FAIL identifies a model invariant failure. Inspect each check's explanation and resolve FAIL results before trusting totals. These checks cover the whole configured pipeline scope rather than the selected dashboard slice.

Gold timestamps and dynamic dataset date bounds are normalized to UTC. Dataset SQL computes the current UTC date explicitly, even if the SQL session timezone differs. UTC date boundaries are deliberate; convert incident/business hours to the customer's local timezone when interpreting the results. The dashboard makes no claim that switching to serverless resolves contention. Compare run duration and result with Azure networking and source-storage observations in a controlled migration trial.

## Build and local validation

From the repository root:

```sh
python3 scripts/build_dashboard.py
python3 scripts/build_dashboard.py --check
```

The builder writes the JSON, readable `dataset_queries.sql`, and data-free HTML preview. Its local checks validate widget versions, field bindings, required page structure, unique widget names, bare view references, line boundaries, and full, non-overlapping grid layouts. They also verify the committed artifacts are current. Python's standard library is the only dependency.

These checks do not execute SQL or guarantee rendering. Before importing or publishing, validate every dataset statement in `dataset_queries.sql` on the selected SQL warehouse and inspect the draft dashboard. Supply the dataset catalog and schema externally during import/create/update, and keep queries on bare view names. In the CLI, `--dataset-catalog` and `--dataset-schema` must be flags; place them on every create/update call. Do not deploy with an automatically selected profile.

## View contract

| Source view | Dataset(s) | Grain used by the report |
| --- | --- | --- |
| `network_cluster_daily` | `cluster_daily` | UTC date × workspace × classic cluster; each physical byte belongs to one association bucket. |
| `network_daily` | `workload_daily`, `job_history` | UTC date × workspace × workload/run × cluster, plus physical shared/unattributed rows and unknown-byte inventory rows. |
| `network_run_inventory` | `run_history`, `coverage_runs` | Workspace × job run or pipeline update; includes classic, serverless, SQL warehouse, mixed, and unknown compute types. |
| `network_segments` | `cluster_segments` | Observed classic-cluster interval; node observations are combined before association with workload activity. |
| `network_quality` and `network_segments` | `quality` | One row per pipeline-wide quality check, with scalar latest observation/materialization timestamps. The freshness table aggregates the repeated scalar fields into a single row. |

The builder declares its expected output fields and checks every widget expression against them. It deliberately excludes daily workload duration from aggregate KPIs because a run can touch multiple clusters; the run inventory is the duration source.
