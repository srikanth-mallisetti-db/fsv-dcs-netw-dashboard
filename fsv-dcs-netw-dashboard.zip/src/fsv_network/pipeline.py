"""Render the same SQL for a SQL warehouse or a scheduled Spark notebook.

No credentials, workspace selection, or network access occurs in this module.
"""

from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path
import re


def identifier(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]{0,254}", value):
        raise ValueError(f"Invalid catalog/schema identifier: {value!r}")
    return f"`{value}`"


@dataclass(frozen=True)
class Settings:
    catalog: str
    schema: str
    workspace_ids: tuple[str, ...]
    start_date: date
    end_date: date
    history_start_date: date
    include_billing: bool = True
    include_pipelines: bool = False
    pipeline_ids: tuple[str, ...] = ()

    def __post_init__(self):
        identifier(self.catalog)
        identifier(self.schema)
        if not self.workspace_ids or any(not re.fullmatch(r"[0-9]+", w) for w in self.workspace_ids):
            raise ValueError("Provide explicit numeric workspace IDs; an account-wide default is not allowed")
        if self.start_date >= self.end_date:
            raise ValueError("start_date must precede the exclusive end_date")
        if self.history_start_date > self.start_date:
            raise ValueError("history_start_date must be on or before start_date")
        if self.pipeline_ids and not self.include_pipelines:
            raise ValueError("pipeline_ids require include_pipelines")
        for pid in self.pipeline_ids:
            if not re.fullmatch(r"[A-Za-z0-9-]+", pid):
                raise ValueError(f"Invalid pipeline ID: {pid!r}")

    def substitutions(self) -> dict[str, str]:
        return {
            "__CATALOG__": identifier(self.catalog),
            "__SCHEMA__": identifier(self.schema),
            "__WORKSPACE_IDS__": ", ".join(f"'{w}'" for w in sorted(set(self.workspace_ids))),
            "__START_DATE__": self.start_date.isoformat(),
            "__NODE_START_DATE__": self.start_date.isoformat(),
            "__END_DATE__": self.end_date.isoformat(),
            "__HISTORY_START_DATE__": self.history_start_date.isoformat(),
        }


def render(text: str, settings: Settings, extra: dict[str, str] | None = None) -> str:
    for key, value in (settings.substitutions() | (extra or {})).items():
        text = text.replace(key, value)
    unresolved = re.findall(r"__[A-Z][A-Z0-9_]*__", text)
    if unresolved:
        raise ValueError(f"Unresolved SQL placeholders: {sorted(set(unresolved))}")
    return text


def split_statements(text: str) -> list[str]:
    """Split only on explicit cell delimiters, preserving SQL string semicolons."""
    cells = re.split(r"(?m)^\s*-- COMMAND ----------\s*$", text)
    return [cell.strip() for cell in cells if re.sub(r"(?m)^\s*--.*$", "", cell).strip()]


def plan(repo_root: Path, settings: Settings) -> list[tuple[str, str]]:
    files = ["00_setup.sql", "10_snapshots.sql"]
    if settings.include_billing:
        files.append("11_billing.sql")
    if settings.include_pipelines:
        files.append("12_pipeline_snapshots.sql")
    files += ["20_model.sql", "30_quality.sql"]
    output = []
    for filename in files:
        # Pipeline event-log adapters must run after timeline ingestion, before gold.
        if filename == "20_model.sql":
            for pid in settings.pipeline_ids:
                template = (repo_root / "sql" / "13_pipeline_events.sql").read_text(encoding="utf-8")
                for i, sql in enumerate(split_statements(render(template, settings, {"__PIPELINE_ID__": pid}))):
                    output.append((f"13_pipeline_events-{pid}-{i + 1}", sql))
        template = (repo_root / "sql" / filename).read_text(encoding="utf-8")
        for i, sql in enumerate(split_statements(render(template, settings))):
            output.append((f"{Path(filename).stem}-{i + 1}", sql))
    return output


def default_dates(today: date, lookback_days: int = 7, history_days: int = 120):
    if not 1 <= lookback_days <= history_days:
        raise ValueError("Require 1 <= lookback_days <= history_days")
    return today - timedelta(days=lookback_days - 1), today + timedelta(days=1), today - timedelta(days=history_days - 1)
