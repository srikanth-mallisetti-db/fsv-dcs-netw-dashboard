"""Explicit-profile Databricks CLI adapter; no SDK or PAT handling required."""

import json
import os
from pathlib import Path
import subprocess
import tempfile
import time


class DatabricksCLI:
    def __init__(self, profile: str, warehouse_id: str):
        if not profile.strip() or not warehouse_id.strip():
            raise ValueError("An explicit profile and warehouse ID are required")
        self.profile = profile
        self.warehouse_id = warehouse_id

    def command(self, args: list[str], body: dict | None = None):
        with tempfile.TemporaryDirectory(prefix="fsv-network-") as tmp:
            cmd = ["databricks", *args, "--profile", self.profile, "-o", "json"]
            if body is not None:
                path = Path(tmp) / "request.json"
                path.write_text(json.dumps(body), encoding="utf-8")
                os.chmod(path, 0o600)
                cmd.extend(["--json", "@" + str(path)])
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", timeout=90)
            except FileNotFoundError as exc:
                raise RuntimeError(
                    "Databricks CLI was not found. Install the approved Databricks CLI and ensure "
                    "databricks (databricks.exe on Windows) is available on PATH."
                ) from exc
            if result.returncode:
                raise RuntimeError(result.stderr.strip() or f"Databricks CLI failed ({result.returncode})")
            return json.loads(result.stdout) if result.stdout.strip() else {}

    def execute(self, sql: str, catalog: str | None, schema: str | None, timeout_seconds: int = 1800):
        body = {
            "warehouse_id": self.warehouse_id,
            "statement": sql,
            "wait_timeout": "10s",
            "on_wait_timeout": "CONTINUE",
            "row_limit": 100,
        }
        if catalog:
            body["catalog"] = catalog
        if schema:
            body["schema"] = schema
        response = self.command(["api", "post", "/api/2.0/sql/statements"], body)
        statement_id = response.get("statement_id")
        deadline = time.monotonic() + timeout_seconds
        while response.get("status", {}).get("state") in {"PENDING", "RUNNING"}:
            if time.monotonic() >= deadline:
                if statement_id:
                    self.command(["api", "post", f"/api/2.0/sql/statements/{statement_id}/cancel"], {})
                raise TimeoutError(f"SQL statement {statement_id} exceeded {timeout_seconds}s")
            time.sleep(2)
            response = self.command(["api", "get", f"/api/2.0/sql/statements/{statement_id}"])
        if response.get("status", {}).get("state") != "SUCCEEDED":
            raise RuntimeError(f"SQL statement {statement_id} failed: {response.get('status')}")
        return response
