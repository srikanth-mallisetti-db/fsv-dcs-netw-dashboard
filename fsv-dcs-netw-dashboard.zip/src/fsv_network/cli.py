"""Repository CLI. Run with PYTHONPATH=src python -m fsv_network ..."""

import argparse
from datetime import date, datetime, timezone
import json
from pathlib import Path

from .databricks_cli import DatabricksCLI
from .pipeline import Settings, default_dates, plan


def parser():
    p = argparse.ArgumentParser(description="Fiserv Azure Databricks network observability")
    p.add_argument("action", choices=["render", "refresh", "validate-dashboard", "deploy-dashboard"])
    p.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[2])
    p.add_argument("--catalog", required=True)
    p.add_argument("--schema", required=True)
    p.add_argument("--workspace-ids", required=True, help="Comma-separated numeric IDs in this region/metastore")
    p.add_argument("--profile", help="Required for every remote action; no implicit DEFAULT")
    p.add_argument("--warehouse-id", help="Required for every remote action")
    p.add_argument("--lookback-days", type=int, default=7, help="Use 90 on first collection, then 7 for late data")
    p.add_argument("--history-days", type=int, default=120)
    p.add_argument("--start-date", type=date.fromisoformat)
    p.add_argument("--end-date", type=date.fromisoformat, help="Exclusive UTC date")
    p.add_argument("--without-billing", action="store_true")
    p.add_argument("--include-pipelines", action="store_true")
    p.add_argument("--pipeline-id", action="append", default=[])
    p.add_argument("--output-dir", type=Path, default=Path("build/rendered"))
    p.add_argument("--dashboard-file", type=Path)
    p.add_argument("--dashboard-id", help="Update this dashboard instead of creating a new one")
    p.add_argument("--parent-path", help="Existing workspace folder for a new dashboard")
    p.add_argument("--publish", action="store_true", help="Publish after validated draft create/update")
    return p


def main(argv=None):
    p = parser()
    args = p.parse_args(argv)
    start, end, history = default_dates(datetime.now(timezone.utc).date(), args.lookback_days, args.history_days)
    settings = Settings(args.catalog, args.schema, tuple(w.strip() for w in args.workspace_ids.split(",")),
                        args.start_date or start, args.end_date or end,
                        min(history, args.start_date or start), not args.without_billing,
                        args.include_pipelines, tuple(args.pipeline_id))
    if args.action == "render":
        args.output_dir.mkdir(parents=True, exist_ok=True)
        statements = plan(args.repo_root, settings)
        for label, sql in statements:
            (args.output_dir / f"{label}.sql").write_text(sql + "\n", encoding="utf-8", newline="\n")
        print(f"Rendered {len(statements)} SQL statements to {args.output_dir.resolve()}")
        return
    if not args.profile or not args.warehouse_id:
        p.error("Remote actions require --profile and --warehouse-id")
    client = DatabricksCLI(args.profile, args.warehouse_id)
    if args.action == "refresh":
        # Scope is validated before any workspace change. Gold is rebuilt only after all snapshots succeed.
        for label, sql in plan(args.repo_root, settings):
            print(f"Executing {label}", flush=True)
            client.execute(sql, settings.catalog, None)
        print("Refresh complete; inspect network_quality before interpreting job estimates.")
        return
    dashboard_path = args.dashboard_file or args.repo_root / "dashboards" / "fiserv_network_observability.lvdash.json"
    dashboard = json.loads(dashboard_path.read_text(encoding="utf-8"))
    # Query execution is mandatory immediately before every create/update/publish.
    for ds in dashboard["datasets"]:
        print(f"Validating dataset {ds['name']}", flush=True)
        client.execute("".join(ds["queryLines"]), args.catalog, args.schema)
    if args.action == "validate-dashboard":
        print(f"All {len(dashboard['datasets'])} datasets succeeded on the selected warehouse.")
        return
    if not args.dashboard_id and not args.parent_path:
        p.error("Creating a dashboard requires --parent-path (an existing workspace folder)")
    flags = ["--dataset-catalog", args.catalog, "--dataset-schema", args.schema,
             "--warehouse-id", args.warehouse_id]
    body = {"serialized_dashboard": json.dumps(dashboard)}
    if args.dashboard_id:
        result = client.command(["lakeview", "update", args.dashboard_id, *flags], body)
        dashboard_id = args.dashboard_id
    else:
        body.update(display_name="Fiserv | Network bandwidth & workload history", parent_path=args.parent_path)
        result = client.command(["lakeview", "create", *flags], body)
        dashboard_id = result["dashboard_id"]
    print(f"Dashboard ID: {dashboard_id}", flush=True)
    if args.publish:
        client.command(["lakeview", "publish", dashboard_id, "--warehouse-id", args.warehouse_id])
    print(json.dumps({"dashboard_id": dashboard_id, "published": args.publish}))
