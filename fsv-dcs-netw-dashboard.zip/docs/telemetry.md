# What the network measurements mean

The dashboard supports retrospective investigation of classic-compute network activity and its association with job runs and pipeline updates. It helps identify when a historical load coincides with high cluster traffic. Confirming that the load saturated a shared network link requires Azure and source-endpoint evidence as well.

## Sources and coverage

| Source | Purpose | Coverage and limitations |
| --- | --- | --- |
| `system.compute.node_timeline` | Observed bytes for each driver or worker interval | Classic compute; one record per instance per minute. Serverless and SQL warehouses are excluded. Nodes that run for less than 10 minutes might be absent. Default retention: 90 days. |
| `system.lakeflow.job_run_timeline` | Job run identity, intervals, outcome | Long runs have hourly slices. Default retention: 365 days. |
| `system.lakeflow.job_task_run_timeline` | Associate a job run with the compute used by its tasks | `compute_ids` can include classic clusters and SQL warehouses. Long tasks have hourly slices. Default retention: 365 days. |
| `system.lakeflow.jobs`, `system.compute.clusters` | Names and compute metadata | These sources contain historical versions; joins must select a single applicable version. |
| `system.lakeflow.pipeline_update_timeline` | Optional pipeline update inventory | Cluster association needs additional evidence described below. Default retention: 365 days. |
| `system.billing.usage` | Optional positive evidence of a run's compute type | DBUs, charges, and billable networking quantities are separate measures; they are not node network byte counters. |

Compute and Lakeflow telemetry is regional; billing usage is account-wide. A workspace in another region needs collection of its compute and Lakeflow telemetry from that region. Access requires the relevant system schemas to be available and the collector to have `USE CATALOG`, `USE SCHEMA`, and `SELECT` privileges, plus write access to its destination.

The 90-day retention window is an upper bound on available source history, not a guarantee of 90 days of measurements. Workspace age, collection availability, short-lived nodes, delayed delivery, and missing records can reduce coverage. Persist available data and show its actual dates. An account's optional configurable-retention Beta can change the defaults; increasing retention does not restore data already removed.

System tables update throughout the day and do not support real-time monitoring. Job and task timeline records are typically available within an hour of `period_end_time`; new workspaces can take longer. A recently completed or still-running workload may therefore be incomplete. Treat recent totals as provisional and re-read an overlapping lookback window on subsequent refreshes. Use source timestamps as well as collector execution time when assessing freshness.

## Bytes, rates, and daily totals

`network_received_bytes` and `network_sent_bytes` are byte totals for a node's interval. They are neither bytes per second nor cumulative counters requiring a difference. The minute granularity explains the documentation's example label, “MB received per minute.”

For a common cluster interval, calculate:

```text
received GiB = sum(node received bytes) / 1024^3
sent GiB     = sum(node sent bytes) / 1024^3
received Mbps = sum(node received bytes) * 8 / wall-clock seconds / 1,000,000
```

Include the driver and workers. Divide cluster bytes by elapsed wall-clock time, rather than summed node time: dividing by node time would produce an average per-node rate. Daily volume is a sum of bytes. An average rate depends on whether its denominator is observed active time or the entire day; label that denominator explicitly. A peak minute average can conceal shorter bursts.

This repository reports daily boundaries in UTC. Local business-hours analysis must convert timestamps using the agreed business timezone and account for daylight saving time. When an observed interval crosses a day or workload boundary, prorating its bytes assumes uniform traffic within that interval.

## Cluster traffic and job attribution

The counters describe node network activity without identifying the remote endpoint or application. They include traffic beyond the external historical read, such as shuffle, other storage access, retries, and background activity. A transfer between two measured nodes appears as sent bytes on one and received bytes on the other. Adding cluster RX and TX therefore double-counts that internal transfer. Keep directions separate when comparing against network capacity.

The task and job identifiers have different meanings:

| Source field | Meaning |
| --- | --- |
| `job_run_timeline.run_id` | Job run ID |
| `job_task_run_timeline.run_id` | Task run ID |
| `job_task_run_timeline.job_run_id` | Enclosing job run ID |
| `job_task_run_timeline.task_key` | Task name/key within the job |
| `job_task_run_timeline.compute_ids` | IDs of compute resources used by the task |

Match workspace and compute IDs, then intersect the time intervals. Several tasks in the same job run can use the same cluster concurrently; they must not multiply the job's allocated bytes. Terminal outcomes occur only on the final hourly slice, so an intermediate slice's null outcome does not imply failure.

Observed cluster bytes are measurements. Bytes associated with a job through overlapping execution are estimates: even one observed run on an all-purpose cluster does not prove exclusive use. Concurrent runs, interactive notebooks, and background processes can share it. Shared traffic cannot be assigned precisely from these sources alone. Preserve unattributed traffic and disclose the allocation rule when reviewing per-job totals. Dedicated job compute improves association, but still includes infrastructure and background traffic.

Missing node metrics do not identify serverless compute. Keep compute classification separate from telemetry coverage, and use positive metadata or billing evidence to distinguish classic, serverless, SQL warehouse, mixed, and unknown runs. An unavailable network measurement must remain null rather than become zero.

## Optional pipeline adapter

The pipeline timeline exposes `compute` as a struct, but its public reference does not specify all child fields. The snapshot preserves that value as JSON instead of assuming a `compute.cluster_id` path.

Pipeline event logs document `origin.org_id` (workspace ID), `origin.pipeline_id`, `origin.update_id`, and `origin.cluster_id`. These provide a bridge from an update to classic compute. Querying `event_log('<pipeline-id>')` requires pipeline-owner access or a suitably authorized view. Job-triggered updates can also expose `trigger_details.job_task.job_id` and `.job_task_run_id`; the latter joins the task run ID to find its enclosing job run.

The supplied event-log adapter maps an update only when it observes one distinct cluster and labels the mapping `EVENT_LOG_SINGLE_OBSERVED_CLUSTER_ESTIMATE`. An observed cluster ID does not establish that cluster's full lifetime or prove that all events were delivered. Multi-cluster, restarted, and ambiguous updates require explicitly verified cluster intervals in `bronze_pipeline_intervals`. Bound intervals with lifecycle evidence, retain their evidence source, and avoid assigning each observed cluster the entire update. Pipeline updates and their parent jobs are overlapping views of the same execution; do not add both totals together as independent consumption.

An alternative source is the Beta table `system.lakeflow_pipeline_events_preview.pipeline_events`, which documents top-level workspace, pipeline, update and event-time fields plus `origin.cluster_id`. It is optional and is not required by the baseline collection. Its planned GA path is `system.lakeflow.pipeline_events`, and its schema may change at that transition.

## Verify a suspected shared-link bottleneck

Azure network metrics are a separate investigation input; this repository does not collect them automatically.

1. Have the network owner trace the actual route from the classic cluster subnet to the external storage endpoint. Identify NAT, firewall/NVA, proxy, private endpoint, ExpressRoute or VPN components that the traffic really traverses. External cloud storage does not necessarily use the corporate WAN.
2. Establish directional capacity at each shared component: provisioned circuit/gateway SKU, VM/NIC limits, firewall throughput under the configured inspection policy, and endpoint account limits. Record normal business-hours utilization and latency. Node type alone cannot establish end-to-end available capacity.
3. Align Azure Monitor metrics with job intervals in UTC and at the same time grain. Check NAT bytes, packet drops and failed SNAT connections; firewall throughput, health and SNAT utilization; ExpressRoute ingress/egress bits per second and drops; or VPN tunnel bandwidth and drops. Use only components on the route. Azure metric names and dimensions vary by resource/SKU.
4. Request source-owner evidence for the same window: egress, successful and throttled requests, latency, timeouts and retry rates. For Azure Blob Storage, inspect `Egress`, `Transactions` by `ResponseType`, `SuccessE2ELatency`, and `SuccessServerLatency`. Other cloud providers have equivalent endpoint metrics.
5. Compare saturation or connection exhaustion with the historical load and affected jobs, then repeat under controlled concurrency or a reduced ingestion rate. High NIC traffic by itself establishes correlation. Link throughput near a measured limit, packet drops, or endpoint throttling provides stronger evidence of the constrained component.

Where permitted, Azure Virtual Network flow logs can help identify source/destination flows and bytes. They do not automatically identify a Databricks job run, and access, export, retention, and cluster/IP mapping require separate setup. Avoid starting a new dependency on legacy NSG flow logs; Azure is retiring that service.

## References

- [Compute system tables and network byte fields](https://learn.microsoft.com/en-us/azure/databricks/admin/system-tables/compute)
- [System table availability, retention, and limitations](https://learn.microsoft.com/en-us/azure/databricks/admin/system-tables/)
- [Lakeflow job, task, and pipeline timeline schemas](https://learn.microsoft.com/en-us/azure/databricks/admin/system-tables/jobs)
- [Pipeline event-log origin fields](https://learn.microsoft.com/en-us/azure/databricks/ldp/monitor-event-log-schema#origin-object) and [event-log access](https://learn.microsoft.com/en-us/azure/databricks/ldp/monitor-event-logs)
- [Optional Beta pipeline events system table](https://learn.microsoft.com/en-us/azure/databricks/admin/system-tables/pipeline-events)
- Azure Monitor references: [NAT Gateway](https://learn.microsoft.com/en-us/azure/nat-gateway/monitor-nat-gateway-reference), [Azure Firewall](https://learn.microsoft.com/en-us/azure/firewall/monitor-firewall-reference), [ExpressRoute](https://learn.microsoft.com/en-us/azure/expressroute/monitor-expressroute-reference), [VPN Gateway](https://learn.microsoft.com/en-us/azure/vpn-gateway/monitor-vpn-gateway-reference), [Blob Storage](https://learn.microsoft.com/en-us/azure/storage/blobs/monitor-blob-storage-reference)
- [Virtual Network flow logs](https://learn.microsoft.com/en-us/azure/network-watcher/vnet-flow-logs-overview)
