# Evaluate classic and serverless networking

Moving a historical load to serverless can change which network components it shares with other workloads. It does not guarantee that the load will stop affecting them. The source storage service, endpoint limits, cross-region path, private connectivity, or an intermediary may remain shared.

Classic compute normally runs in a VNet in the customer's Azure subscription. Serverless workloads run in a Databricks-managed compute plane. A classic route through a customer-managed hub firewall, NAT device, VPN, or ExpressRoute circuit may therefore differ from the serverless route. Have the network owners verify both paths; do not infer them solely from the compute label.

## Establish connectivity first

- Confirm that the workload and region support serverless, its data is accessible through supported Unity Catalog mechanisms, and the external source owner permits the serverless access path.
- Document DNS, routing, endpoint regions, firewalls and allowlists for both compute types. An account-level regional network connectivity configuration (NCC) manages serverless private endpoints. Resource owners must approve private endpoint requests where applicable.
- Follow the current Azure storage firewall guidance. The Azure documentation now requires Network Security Perimeter plus an `AzureDatabricksServerless` service-tag rule for storage service-endpoint connectivity; old serverless subnet allowlists can return 403. Other resources and private endpoint configurations need their own supported rules.
- Record cross-region placement and applicable networking charges. Billable connectivity/data-transfer records do not represent every byte moved and cannot replace throughput telemetry.

These are evaluation prerequisites. This repository does not modify Azure networking or migrate customer workloads.

## Compare the same work

Choose a representative historical partition and a control job whose reliability matters during business hours. Use the same input snapshot, transformations, output validation, identity/access rules, concurrency and endpoint region. Record differences that cannot be held constant. Avoid interpreting a warm-cache run against a cold historical read as a compute improvement.

Run the following controlled sequence within an agreed test window:

1. Record the control job's normal duration, failure rate, source latency and shared network utilization.
2. Run the historical load on classic compute alongside the control workload. Capture job/task IDs, source request metrics, relevant Azure route metrics, row/byte counts and output checks.
3. Run the same load on serverless with comparable control-workload concurrency. Capture both its changed network path and the same application/endpoint evidence.
4. Repeat enough times to distinguish a consistent improvement from source load variation, retries or cache effects. If needed, repeat with an agreed ingestion-rate or concurrency limit to test whether throttling relieves the shared constraint.

Agree on acceptance criteria before running: historical-load completion deadline, acceptable impact on the control job, retry/error limits, source throttling, output correctness and total cost. Test a relevant business-hours concurrency level only after a controlled run establishes safe operating bounds.

## Compare evidence at the right layer

| Evidence | Classic | Serverless |
| --- | --- | --- |
| Job/task timing, outcome and run identity | Lakeflow system tables | Lakeflow system tables |
| Driver/worker NIC bytes | `system.compute.node_timeline`, subject to coverage | Unavailable from this source; retain null |
| Per-job external-storage bytes | Requires destination/request evidence; job allocation from NIC totals remains estimated | Requires source/request evidence or supported workload telemetry |
| Shared-network pressure | Azure Monitor metrics for the verified classic route | Metrics for resources actually used by the verified serverless route |
| Source throttling and latency | Source-owner metrics and request logs | Same source-owner metrics and request logs |
| Workload progress and query execution | Spark/job/pipeline diagnostics as applicable | Query insights and supported job/pipeline diagnostics as applicable |

Compare directional traffic, elapsed time and end-to-end correctness. Pipeline rows/output bytes, Spark input bytes, DBUs, and billable network quantities measure different things from NIC traffic; label them separately. The absence of node counters on serverless is an observability gap, not evidence of lower traffic.

A favorable result is improved workload completion and control-job reliability with corroborating route and endpoint evidence. If both compute types hit the same source throttling limit, migration alone has not removed that constraint. Consider scheduling historical loads outside peak hours, limiting ingestion concurrency/rate, staging data closer to compute, or changing the verified constrained component based on the test evidence.

## References

- [Serverless network security and NCCs](https://learn.microsoft.com/en-us/azure/databricks/security/network/serverless-network-security/)
- [Classic compute plane networking](https://learn.microsoft.com/en-us/azure/databricks/security/network/classic/)
- [Serverless networking costs](https://learn.microsoft.com/en-us/azure/databricks/security/network/serverless-network-security/cost-management)
- [Compute system table limitations](https://learn.microsoft.com/en-us/azure/databricks/admin/system-tables/compute)
- [Compute metrics and serverless query insights](https://learn.microsoft.com/en-us/azure/databricks/compute/cluster-metrics)
- [Telemetry interpretation and Azure investigation inputs](telemetry.md)
