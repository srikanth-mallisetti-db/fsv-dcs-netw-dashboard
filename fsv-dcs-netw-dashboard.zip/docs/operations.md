# Collection and operations

## Access and scope

Use an existing Unity Catalog catalog and a dedicated destination schema. The collector needs `USE CATALOG`, `CREATE SCHEMA` if creating the schema, destination `USE SCHEMA` and `CREATE TABLE`, and ownership sufficient to replace its own views and tables. This implementation uses ordinary views and Delta tables. Readers need `USE CATALOG`, `USE SCHEMA`, and `SELECT` on reporting objects, or access through the dashboard's configured credentials.

The collector reads these system tables:

```text
system.compute.node_timeline
system.compute.clusters
system.lakeflow.jobs
system.lakeflow.job_run_timeline
system.lakeflow.job_task_run_timeline
system.billing.usage                         (default; disable explicitly if unavailable)
system.lakeflow.pipeline_update_timeline    (opt-in)
```

An account/metastore administrator must enable available system schemas and grant the collector `USE CATALOG` on `system`, `USE SCHEMA` on each required schema, and `SELECT` on the listed tables. These grants can expose account-wide telemetry: use an approved collector identity and scope destination readership accordingly. The collector filters to the explicit numeric workspace allowlist. Use a separate destination per region/metastore/scope, and one writer per destination. Do not run different workspace allowlists against the same destination: gold is rebuilt for the current configured scope.

The CLI requires an explicit profile for each remote action. The scheduled notebook uses its job run identity. It needs access to the same sources, repository files and target objects; local CLI authentication does not transfer to a scheduled job. No credentials are stored in the repository or job JSON.

## Schedule

1. Run the initial CLI refresh with the destination catalog/schema, explicit workspace IDs, billing/pipeline settings and `--lookback-days 90`. Source retention and actual telemetry availability determine the history returned. Empty node metrics on a fresh FE workspace are expected and do not validate the classic traffic path.
2. Deploy the collector with the helper below, then manually run the paused job. It uploads its runtime files into a dedicated workspace folder and sets `repo_root` explicitly. A Databricks Git folder is an alternative: open `notebooks/refresh_network_observability` and point `repo_root` at the checked-out repository.
3. Inspect `network_quality`, physical totals and a known run. Compare its classic cluster and time range with the compute metrics UI. Recent runs are provisional because source delivery is delayed.
4. Activate the hourly schedule after a successful run. Keep `lookback_days=7`, `history_days=120`, and `max_concurrent_runs=1`. Configure job failure notifications through the approved operational channel. Dashboard refresh/snapshot scheduling is independent of collector scheduling.
5. Increase lookback to recover delayed or corrected rows outside seven days. For an outage exceeding source retention, missing historical bytes cannot be reconstructed from job IDs or DBUs.

End dates are exclusive UTC calendar dates. A default refresh includes today's available partial data. Task and node MERGEs replace existing natural-key rows; repeated collection does not append duplicate counters. Metadata is retained to resolve names and positive compute evidence. The dashboard's 90-day history is separate from a single day's overview date filter.

### Deploy the workspace-file collector

The Azure pilot uses [this workspace](https://adb-7405616001663966.6.azuredatabricks.net). From the repository root, deploy with its explicitly selected profile and destination:

```bash
python3 scripts/deploy_refresh_job.py \
  --profile fsv-dcs-netw-dashboard \
  --warehouse-id 5607f4208a845089 \
  --catalog fiserv_network_observability --schema network_observability \
  --workspace-ids 7405616001663966 \
  --workspace-root /Workspace/Shared/fsv-dcs-netw-dashboard \
  --include-pipelines --state-file state/refresh-job.json
```

Replace these pilot values for a customer deployment. The helper requires Python 3.10+ and the authenticated CLI; it sets its own local import path, so `PYTHONPATH` and a package installation are unnecessary. `--warehouse-id` supplies the CLI adapter's deployment context; the scheduled notebook executes Spark SQL on serverless compute and does not use that warehouse.

The helper creates the workspace subfolders and overwrites only its runtime files: `src/fsv_network/__init__.py`, `src/fsv_network/pipeline.py`, the numbered `sql/*.sql` templates, and the refresh notebook. Python modules and SQL remain workspace files; the notebook is imported as Python source. Its `repo_root` points at `/Workspace/Shared/fsv-dcs-netw-dashboard`, allowing ordinary Python imports and SQL file reads on serverless. Credentials and CLI profile files are never uploaded.

The job inherits `config/refresh_job.example.json`: serverless **STANDARD**, one concurrent run, and an hourly schedule at minute 15 UTC. Its schedule starts **PAUSED**. Upload progress goes to stderr; stdout and the optional state file contain only `{"job_id": ...}`. The local `state/` directory is git-ignored.

Read the saved ID and trigger a manual run:

```bash
FSV_REFRESH_JOB_ID=$(python3 -c 'import json; print(json.load(open("state/refresh-job.json"))["job_id"])')
databricks jobs run-now "$FSV_REFRESH_JOB_ID" \
  --profile fsv-dcs-netw-dashboard --no-wait -o json
```

Inspect the returned run ID in Lakeflow Jobs. A successful notebook returns its catalog, schema, workspace scope and quality statuses through `dbutils.notebook.exit()`. Retrieve the notebook **task** run output or inspect the persisted `network_quality` table; a successful execution alone does not establish complete telemetry coverage.

After the manual run and quality checks succeed, enable scheduling on that same job:

```bash
python3 scripts/deploy_refresh_job.py \
  --profile fsv-dcs-netw-dashboard \
  --warehouse-id 5607f4208a845089 \
  --catalog fiserv_network_observability --schema network_observability \
  --workspace-ids 7405616001663966 \
  --workspace-root /Workspace/Shared/fsv-dcs-netw-dashboard \
  --include-pipelines --state-file state/refresh-job.json \
  --job-id "$FSV_REFRESH_JOB_ID" --activate
```

Each deployment without `--job-id` creates a new job, even if its name already exists; the helper never adopts a job by name or from the state file. With `--job-id`, it resets that job from the maintained template and supplied parameters, preserving its ID. Reset replaces job settings, including changes made separately in the UI. Omitting `--activate` pauses the schedule on both create and reset. Redeploy between runs because runtime files are overwritten in place. Preserve one writer per destination.

Use repeated `--pipeline-id PIPELINE_UUID` to configure readable pipeline event logs; these require `--include-pipelines`. Use `--without-billing` if billing access is unavailable. `--lookback-days` and `--history-days` override the seven-day collection and 120-day model defaults. The notebook's run identity needs access to the uploaded workspace files as well as the source and destination tables.

## Pipeline updates

Enable pipeline inventory using `include_pipelines=true` / `--include-pipelines`. Configure each readable event log through `pipeline_ids` / repeated `--pipeline-id`. The adapter reads documented origin IDs and links updates with exactly one observed cluster, labeling the whole-update interval as an estimate. It refreshes adapter-owned mappings when additional cluster evidence appears. It does not infer nested fields from the pipeline timeline's `compute` struct.

For updates with multiple clusters or incomplete lifecycle evidence, provide verified bounded rows in `bronze_pipeline_intervals`. Required identity and interval columns are declared in `sql/00_setup.sql`. Preserve an evidence source other than the adapter's reserved `EVENT_LOG_SINGLE_OBSERVED_CLUSTER_ESTIMATE`. Positive compute classifications can be supplied separately through `bronze_compute_classification`; missing metrics alone are not evidence of serverless. Review adapter evidence with the pipeline owner before treating its bytes as a workload estimate.

A manual mapping owns the entire update: the automatic adapter removes its obsolete estimates and does not expand or overwrite verified intervals. Independent positive compute evidence is combined; a serverless or SQL override cannot relabel observed classic traffic as serverless-only. Conflicting compute types appear as `MIXED`, and an `UNKNOWN` annotation does not erase known compute evidence.

The pipeline update is the consuming workload. A parent orchestration job can be recorded in the adapter; adding that parent's traffic to the update's traffic would count the same execution twice. Selecting a parent job does not automatically roll all pipeline update bytes into that job's estimate.

## Quality and recovery

Physical node counters are aggregated before workload joins. Segment boundaries include every measured node endpoint, workload endpoint and UTC midnight. A segment with one distinct active workload carries a time-prorated estimate; more than one stays `SHARED_AMBIGUOUS`; none stays `UNATTRIBUTED`. Concurrent tasks in the same job run do not create multiple workloads. This preserves measured physical totals without inventing an allocation for shared traffic.

Check source maximum timestamps, observed coverage, rejected node rows and conservation errors before interpreting totals. Unknown, SQL and serverless compute do not gain zero-byte records. Recorded run duration is the retained timeline envelope, independent of observed network coverage; an incomplete source history can truncate it.

The pilot model rebuilds reporting tables from the configured retained bronze history. Each Delta replacement is atomic, but the entire refresh is **not** a transaction across all tables. If a statement fails, the job fails and existing objects may reflect different refresh times; rerun after fixing the source/permission error and inspect `materialized_at`. Keep a dashboard snapshot until the full refresh and quality checks succeed. Do not have another refresh execute concurrently.

Bronze rows persist; `history_days` bounds modeled data and does not delete source snapshots. Establish a retention/access policy with the customer before production use. At estate scale, profile the segment range joins and use bounded, atomic partition replacements for affected days; the full-history rebuild is intended for this initial implementation. Do not run `VACUUM`, delete history, or change account retention as part of routine recovery.

## Deployment validation

`validate-dashboard` executes every dataset through the CLI on the selected SQL warehouse. `deploy-dashboard` repeats that validation immediately before creating/updating. It always passes dataset catalog/schema flags so bare table names remain portable. It updates a supplied dashboard ID; omission creates a new draft and URL.

Remote SQL fixture tests require `FSV_SQL_TEST_PROFILE`, `FSV_SQL_TEST_WAREHOUSE_ID`, `FSV_SQL_TEST_CATALOG`, and a new `FSV_SQL_TEST_SCHEMA` beginning with `fsv_network_test_`. They must never target the customer reporting schema. See the test module for required permissions and cleanup behavior.

Before customer handover, inspect the dashboard in the workspace, exercise workspace/job/date filters, confirm the history page retains its 90-day window, and verify measured/estimated/unknown labels. A successful JSON parse is not proof of correct data or rendering.
