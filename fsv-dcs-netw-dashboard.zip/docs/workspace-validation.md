# Azure pilot validation — 2026-10-15

This records the FE Azure deployment. It is a test workspace, not Fiserv production.

| Resource | Value |
| --- | --- |
| CLI profile | `fsv-dcs-netw-dashboard` |
| Workspace | `https://adb-7405616001663966.6.azuredatabricks.net` |
| Workspace ID / collector scope | `7405616001663966` |
| Catalog / schema | `fiserv_network_observability.network_observability` |
| SQL warehouse | `5607f4208a845089` — existing Serverless Starter Warehouse |
| Workspace source folder | `/Workspace/Shared/fsv-dcs-netw-dashboard` |
| Dashboard draft | [Open dashboard](https://adb-7405616001663966.6.azuredatabricks.net/sql/dashboardsv3/01f1c87e155c13fe86ad9fa51fadb02c) |
| Collector job | [Open job](https://adb-7405616001663966.6.azuredatabricks.net/jobs/252996507133026) |

The catalog was created with managed storage under the workspace's existing FE Azure storage. Required compute, Lakeflow and billing system schemas were enabled. The collector reads only the listed workspace ID.

## Completed checks

- Required system-table columns compiled on the Azure SQL warehouse, including optional pipeline-update inventory.
- The initial 90-day collection, reporting model and hard quality assertions completed successfully against real system tables.
- Eleven isolated SQL integration tests passed on this warehouse. They exercised byte conservation, parallel-task deduplication, concurrent-run ambiguity, UTC midnight and partial intervals, missing/serverless values, positive compute evidence, pipeline-parent deduplication, manual pipeline bounds, conflicting compute evidence, late corrections and empty node sources. The adapter test used a fixture event relation with the production DELETE/MERGE statements. Temporary fixture schemas were removed by test cleanup.
- All seven dashboard dataset queries executed successfully immediately before draft creation. The saved dashboard was read back and all dataset catalog/schema defaults and the warehouse ID were verified.
- Fourteen local tests passed after the Windows portability review, including UTF-8 request/response handling and a simulated legacy Windows code page. Encoding warnings were treated as errors. Deterministic dashboard generation, Python compilation and whitespace checks passed. The dashboard contains seven datasets and 43 widgets. Native PowerShell execution still requires validation on Windows.

## Data availability and remaining checks

The first collection returned zero node intervals, job runs and pipeline updates in this fresh workspace. All hard invariants passed. `no_node_data` and `node_source_stale` correctly returned `WARN`. Empty output is not evidence that classic workloads consumed zero bytes, and this workspace cannot yet establish real-world attribution accuracy or 90 days of observed history.

The collector's first serverless notebook run completed successfully in STANDARD mode (run `695298160205062`, task run `934895707238788`, approximately 7 minutes 27 seconds including setup). Its notebook output returned the configured catalog/schema/workspace scope and expected quality statuses. After the expanded regression suite passed, the final source files were uploaded to the same workspace paths and the existing job's hourly schedule was enabled at minute 15 UTC, with one concurrent run. The final model and its 12 quality checks were also executed on the SQL warehouse: ten passed and two correctly warned about absent/stale node data.

The data-free layout preview and dashboard contracts were reviewed. Live workspace rendering could not be inspected from the automated browser: Microsoft sign-in redirected to an Okta access denial. Inspect all three report pages in an authenticated browser before customer handover. Once representative classic workloads arrive, exercise workspace/job/date filters, confirm the independent 90-day history, and compare a known run with its cluster metrics. Pipeline event-log mappings require explicit pipeline IDs; none are configured in this fresh workspace.

The dashboard is a draft. No shared published snapshot or additional reader grants were created.

## Separate synthetic demonstration

[Open the SYNTHETIC DEMO dashboard](https://adb-7405616001663966.6.azuredatabricks.net/sql/dashboardsv3/01f1c8800b3f1dcab7b62b8b97f8f6c6). Its separate schema is `fiserv_network_observability.network_observability_demo`. The seed script reads only empty output schemas from the live reporting schema and writes only demo objects. Every report page identifies its artificial data and IDs; the schema and tables also carry synthetic-data comments.

The demonstration includes 90 UTC dates with normal ingestion, historical backfill spikes, shared/unattributed physical traffic, pipeline updates and serverless runs with NULL network measurements. Classic and serverless historical runs use the same artificial duration formula. These patterns illustrate dashboard behavior and support no performance conclusion about migrating Fiserv workloads.

The final seed cutoff is `2026-10-15T10:05:00Z`. Verification returned 257,530 synthetic minute segments, 618 daily rows and 357 workload runs over 90 dates, including nine serverless runs. No serverless run had non-NULL attributed bytes; no synthetic quality check failed. All seven dashboard dataset queries succeeded after the final seed. A separate read-only check confirmed the live schema still had zero segments and zero workload runs.
