# Customer deployment and handoff

Use this preflight with the executable commands in [Windows setup](windows-setup.md). The deployment uses Python, SQL and dashboard JSON directly. It has no bundle targets, workspace bindings or build artifacts to migrate from the earlier Masked Data Bridge project.

## Record the intended environment

Agree on these values before the first write:

| Value | Required decision |
| --- | --- |
| Workspace URL and CLI profile | Explicit customer **workspace** profile; verify the Azure host and signed-in identity |
| Source workspace IDs | Numeric IDs kept as strings, in the approved regional/metastore scope |
| SQL warehouse ID | Approved warehouse accessible to the deployment identity and dashboard users as configured |
| Destination catalog/schema | Existing catalog with approved managed storage; dedicated reporting schema |
| Deployment and job run identities | Owners, source/destination grants and service principal policy |
| Workspace runtime folder | Dedicated folder with edit access restricted to deployment owners/admins |
| Optional inputs | Billing availability, pipeline inventory and readable pipeline event-log IDs |
| Existing resource IDs | Collector job and dashboard IDs for updates; omit only on initial creation |
| Operations owner | Schedule, failure notifications, retention, readership and support responsibilities |
| Source revision | Transferred commit and archive checksum; customer changes recorded separately |

Keep one writer per destination and a fixed source workspace allowlist. Use separate destinations for different regions, metastores or scopes. A refresh rebuilds reporting objects for the configured scope; changing the allowlist is an operational migration, not a way to accumulate additional estates in the same tables.

The local deployment uses the selected SQL warehouse for the initial refresh and dashboard validation. The scheduled notebook executes Spark SQL on serverless Jobs compute. Its identity and compute permissions must work independently of workstation authentication.

## Unity Catalog and source access

Have the platform owner approve the existing destination catalog and storage configuration. The collector needs `USE CATALOG`, `CREATE SCHEMA` on the catalog when creating the schema, destination `USE SCHEMA` and `CREATE TABLE`, and ownership sufficient to replace its reporting tables and views. If administrators precreate the schema, grant the collector the required object creation privileges there. Readers need destination `USE CATALOG`, `USE SCHEMA` and `SELECT`, or access through the dashboard's configured credentials.

An account/metastore administrator must enable the available system schemas and grant source access to the collector identity:

| Source | Use |
| --- | --- |
| `system.compute.node_timeline` | Classic node receive/send measurements |
| `system.compute.clusters` | Cluster metadata |
| `system.lakeflow.jobs` | Job metadata |
| `system.lakeflow.job_run_timeline` | Job run inventory and retained duration |
| `system.lakeflow.job_task_run_timeline` | Task/compute time associations |
| `system.billing.usage` | Default positive compute evidence; disable with `--without-billing` if unavailable |
| `system.lakeflow.pipeline_update_timeline` | Optional pipeline inventory via `--include-pipelines` |
| Each configured pipeline event log | Optional update-to-cluster evidence via repeated `--pipeline-id` |

For example, an administrator can adapt these grants for the approved identity and repeat them for the other required schemas/tables:

```sql
GRANT USE CATALOG ON CATALOG system TO `<collector-principal>`;
GRANT USE SCHEMA ON SCHEMA system.compute TO `<collector-principal>`;
GRANT SELECT ON TABLE system.compute.node_timeline TO `<collector-principal>`;
GRANT SELECT ON TABLE system.compute.clusters TO `<collector-principal>`;
```

These are permission examples, not setup SQL executed by the project. Source grants can expose account-wide telemetry; destination filters do not restrict the identity's underlying source access. Coordinate pipeline event-log access with each pipeline owner. Use the same approved billing/pipeline options in the initial refresh and scheduled collector. Missing node metrics alone never establish serverless compute.

## Runtime and identity requirements

The supplied collector helper requires serverless Jobs support and deploys a notebook in **STANDARD** mode. It rejects classic cluster settings in its job template. If serverless is unavailable or disallowed, the helper/template require a deliberate customer-approved adaptation before scheduling; the current helper cannot select a classic cluster as a fallback.

The helper uploads executable Python/SQL and the notebook into the chosen workspace folder. Restrict edits to trusted deployment owners because the job executes those files with its run identity's privileges. Review inherited folder permissions and grant that identity read access to the runtime files. Confirm the deployment identity can create/update jobs and dashboards, use the warehouse, and manage its dedicated folder.

By default, a new job runs as its creator. If the customer requires a service principal, maintain the approved `run_as` setting in `config/refresh_job.example.json` and verify the deployer is permitted to use that principal. Maintain approved failure notification settings in that template too. `--job-id` performs a job reset from the template and supplied arguments; separate UI settings are replaced on deployment. Never put credentials in the template. This project needs no additional cross-workspace binding secret.

## Deployment sequence

1. Verify the source archive and tools, create the local environment and run the offline tests/render. Choose and authenticate the explicit customer profile. Verify its host, identity and warehouse.
2. Run the initial refresh with `--lookback-days 90` and the approved source scope. Inspect `network_quality` and the source timestamps before interpreting the reporting tables.
3. Create the paused collector in the protected runtime folder. Save its job ID with the target details. Trigger a manual run and inspect its notebook task output and persisted quality checks.
4. After acceptance, deploy with that same `--job-id --activate`. The supplied schedule runs hourly at minute 15 UTC, with one concurrent run and a seven-day collection lookback. Preserve a single writer, including manual CLI refreshes.
5. Create the dashboard draft. The command executes all seven dataset queries before deployment. Inspect the draft in the browser and review credentials/permissions before publishing. Keep its dashboard ID for every update.
6. Record the source revision, target values, IDs, run identity, permissions, schedule, owners and acceptance results in the customer handoff record. Keep local target-specific records under git-ignored `state/`, outside source transfers.

The [Windows guide](windows-setup.md) provides PowerShell commands for each step. For source updates, pause scheduling and finish active runs before uploading files, test the existing paused job, then reactivate it. Omitting `--job-id` creates a new collector; omitting `--dashboard-id` creates a new dashboard. Omitting `--activate` pauses a job on creation or reset. Collector scheduling and dashboard refresh/publication scheduling are independent.

## Acceptance and operational handoff

- The manual collector run finishes with Jobs `state.result_state = SUCCESS`. Its notebook task output confirms the intended catalog, schema and workspace scope. SQL Statement Execution has a separate `SUCCEEDED` state.
- `network_quality` has no `FAIL` results; warnings and telemetry freshness have been reviewed. A successful job with empty source history does not validate classic bandwidth reporting.
- A known classic workload's cluster/time range is compared with compute metrics, and receive/send totals reconcile. Per-job bytes remain time association estimates; overlapping workloads retain their shared ambiguity label.
- The daily workspace/date filters and the independent 90-day job history have been exercised in the browser. Serverless and unmeasured bytes remain `NULL`, and measured/estimated/unknown labels are clear.
- Source delivery delay, bounded available history, bronze retention, one-writer ownership and refresh recovery are understood. The full reporting refresh is not a transaction across all output tables.
- Customer job/dashboard IDs, run identity, source revision, permissions, failure notifications, ownership and support process are recorded. Synthetic data, if used, stays in a separate labeled demo schema and is not accepted as performance evidence.

Optional remote fixture tests require a new, nonexistent schema name beginning `fsv_network_test_`; do not precreate it. The suite creates and drops its isolated schema and must never target the reporting schema. Follow the environment variables and cleanup behavior documented in [the integration test module](../tests/test_attribution_sql.py) and [operations](operations.md). Record customer execution results separately from the [FE pilot validation](workspace-validation.md).

Review [telemetry semantics](telemetry.md), [operations and recovery](operations.md), and [serverless evaluation](serverless-evaluation.md) with the receiving team. NIC measurements include internal/background traffic and cannot identify external-storage ingress or prove WAN saturation. Moving workloads to serverless requires an observed customer comparison; this dashboard does not establish that shared network contention has been resolved.
