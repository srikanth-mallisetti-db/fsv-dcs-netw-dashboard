# Offline source transfer

This guide prepares the project for transport into the Fiserv environment. Deployment still requires access from the Windows workstation to the customer Azure Databricks workspace and its identity provider. No public Git access or Python package downloads are needed at the destination.

## Prepare the transfer set

Transfer these items through the approved enterprise process:

| Item | Purpose |
| --- | --- |
| Committed source ZIP and its commit/SHA-256 manifest | Python sources, SQL, dashboard JSON, tests and documentation |
| Approved Windows Python 3.10+ installer | Include standard-library `venv`; match the workstation architecture |
| Approved native Databricks CLI Windows ZIP | Go-based CLI v1.0.0+; the Azure pilot used v1.20.0 |
| Independently verified installer hashes/signatures | Validate installers through the approved software channel |
| Customer deployment record | Intended host, profile name, catalog/schema, warehouse, workspace scope and owners |

The tools run directly from source using the Python standard library. A wheelhouse, internal pip configuration, `uv`, Databricks Connect and Asset Bundles are unnecessary for this workflow. Avoid `pip install .`: the optional packaging metadata requests a build backend, which can trigger a package download. Create the Windows virtual environment locally with `--without-pip` as described in [Windows setup](windows-setup.md).

## Export a committed revision

Run these commands from the repository root on the connected development machine after committing the intended changes:

```bash
git status --short
git rev-parse HEAD
git ls-files
mkdir -p build/transfer
git archive --format=zip --output=build/transfer/fsv-dcs-netw-dashboard.zip HEAD
```

Review any uncommitted changes first: `git archive HEAD` exports only the committed revision. Review the tracked file list for unintended files. The archive contains no `.git` directory and excludes untracked files. A tracked file is exported even if `.gitignore` matches it, so ignore rules do not protect against accidentally committed credentials or state. Do not replace the archive with a recursive copy of the working directory.

Create the accompanying manifest using Python's standard library:

```bash
python3 - <<'PY'
import hashlib
from pathlib import Path
import subprocess

archive = Path("build/transfer/fsv-dcs-netw-dashboard.zip")
commit = subprocess.run(
    ["git", "rev-parse", "HEAD"], check=True, capture_output=True,
    text=True, encoding="utf-8",
).stdout.strip()
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
manifest = archive.with_name("manifest.txt")
manifest.write_text(
    f"commit {commit}\nsha256 {digest}  {archive.name}\n",
    encoding="utf-8", newline="\n",
)
print(manifest.read_text(encoding="utf-8"))
PY
```

Send the manifest through a trusted channel with the archive. Keep the original commit and checksum in the customer change record. Installer hashes are separate from this source checksum; obtain them from the approved software distribution process.

## Exclude developer and workspace state

Do not transfer `.venv/`, `state/`, other `build/` contents, `.databrickscfg`, `.env` files, OAuth caches, tokens, SSH keys or developer credentials. The source archive and manifest are the intended outputs under `build/transfer/`.

The ZIP contains code and documentation. It does not export Delta data, telemetry, deployed dashboards/jobs, source grants, warehouse definitions or cloud networking configuration. The FE resource IDs and URLs in the [pilot validation record](workspace-validation.md) describe that sandbox; choose fresh customer values and authenticate within Fiserv. Preserve customer-only job/dashboard state locally across subsequent updates.

## Verify and extract on Windows

In PowerShell, compare the archive's SHA-256 with the independently supplied manifest before extracting:

```powershell
$FsvSourceArchive = Read-Host 'Full path to the approved source ZIP'
Get-FileHash -LiteralPath $FsvSourceArchive -Algorithm SHA256

# After matching the hash, choose a NEW destination directory.
$FsvDestination = Read-Host 'New local directory for the extracted repository'
if (Test-Path -LiteralPath $FsvDestination) {
    throw 'Choose a new directory to avoid mixing source revisions.'
}
Expand-Archive -LiteralPath $FsvSourceArchive -DestinationPath $FsvDestination -ErrorAction Stop
Set-Location -LiteralPath $FsvDestination
```

Git is optional when deploying from this ZIP. If Fiserv requires an internal repository, import the reviewed source through its normal process and retain the original source commit/checksum alongside the internal revision. Continue with [Windows setup](windows-setup.md) and the [deployment preflight](deployment.md).

## Apply a later revision

Verify and extract the next archive into a new directory. Recreate the local environment and run the offline checks. Retrieve the customer target record from the existing deployment's local `state/` directory; confirm its host and scope before reusing IDs.

Pause the existing collector schedule and allow any active run to finish before uploading replacement runtime files. Deploy using the existing `--job-id` without `--activate`, run it manually, review quality, then activate that same ID. Update the dashboard using its existing `--dashboard-id` and review the draft before publishing. Omitting these IDs creates additional resources. The helper resets job settings from the maintained template, so preserve approved run identity and notification settings there. See [operations](operations.md) for recovery and retention behavior.
