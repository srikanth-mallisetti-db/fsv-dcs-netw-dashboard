# Windows setup and deployment

Use this guide on the Fiserv Windows workstation after the approved source archive and installers have been transferred. All commands use native PowerShell and run from the extracted repository root. These instructions were reviewed on macOS; they have not been executed on Windows.

The local tools use Python 3.10+ and its standard library. They do not require a Python package index, `pip install`, a wheel build, Databricks Connect, or Asset Bundles. The Python environment and build steps in the earlier Masked Data Bridge repository belong to that project.

## Transfer and install the approved tools

Follow [offline transfer](offline-transfer.md) for the source archive, integrity checks and excluded local state. Obtain the Windows Python installer and current **Go-based Databricks CLI** Windows ZIP through the enterprise-approved software channel, matching the workstation architecture. The CLI must be v1.0.0 or newer; use the current approved stable release. The Azure pilot used v1.20.0. The legacy Python package named `databricks-cli` is not suitable.

Have IT install Python, including the standard-library `venv` feature. If manual CLI ZIP extraction is approved:

```powershell
$FsvCliArchive = Read-Host 'Full path to the approved Databricks CLI Windows ZIP'
$FsvCliDirectory = Read-Host 'Approved destination directory for databricks.exe'
Get-FileHash -LiteralPath $FsvCliArchive -Algorithm SHA256
# Compare the hash with the independently supplied approved manifest first.
Expand-Archive -LiteralPath $FsvCliArchive -DestinationPath $FsvCliDirectory
$env:Path = "$FsvCliDirectory;$env:Path"
```

This PATH change applies to the current PowerShell session. Use the enterprise-approved persistent PATH configuration or repeat it in a new session. If IT already installed the CLI on PATH, skip extraction. A PowerShell alias or function can still take precedence over an executable; inspect all matches:

```powershell
Get-Command databricks -All | Select-Object CommandType, Source, Definition
where.exe databricks
databricks --version
py -3 --version
```

Resolve duplicate or legacy CLI installations before continuing. `subprocess` in the Python tools launches `databricks` from PATH, so a PowerShell-only alias does not configure the Python subprocess. Use the approved executable directory on PATH. Restart the terminal after an installer changes PATH. If the Python launcher is unavailable, use the full path to the approved `python.exe` instead of `py -3` below.

## Prepare a local Python environment

Choose a local working directory; keep Windows filesystem paths separate from forward-slash workspace paths:

```powershell
Set-Location -LiteralPath 'C:\Fiserv\fsv-dcs-netw-dashboard'

function Assert-FsvNativeSuccess([string] $FsvAction) {
    if ($LASTEXITCODE -ne 0) {
        throw "$FsvAction failed with exit code $LASTEXITCODE. Stop before the next step."
    }
}

# Keep source files, JSON and captured command output in UTF-8 on Windows.
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [Console]::OutputEncoding

py -3 -c "import sys; assert sys.version_info >= (3, 10), sys.version; print(sys.version)"
Assert-FsvNativeSuccess 'Python version check'
py -3 -m venv --without-pip .venv
Assert-FsvNativeSuccess 'Virtual environment creation'
$FsvPython = (Resolve-Path -LiteralPath '.\.venv\Scripts\python.exe').Path
$env:PYTHONPATH = Join-Path $PWD.Path 'src'
& $FsvPython --version
Assert-FsvNativeSuccess 'Virtual environment check'
```

Creating this environment does not download packages. Activation is unnecessary: calling the interpreter directly avoids PowerShell activation-script execution-policy issues. Recreate the environment locally if the archive contains one from another machine; do not transfer or reuse a macOS virtual environment. No execution-policy bypass is required. In Windows PowerShell, native command failures do not reliably stop a script automatically, so retain the exit-code checks.

## Choose the customer target explicitly

Use customer-supplied values. Do not reuse the FE sandbox profile, warehouse, resource IDs or local state. Read the [deployment preflight](deployment.md) for required system-table grants, an existing catalog and SQL warehouse, and run identity permissions.

```powershell
$FsvProfile = Read-Host 'Chosen customer workspace CLI profile name'
$FsvWorkspaceHost = (Read-Host 'Customer Azure workspace URL, https://adb-...azuredatabricks.net').TrimEnd('/')
$FsvWarehouseId = Read-Host 'Approved SQL warehouse ID'
$FsvCatalog = Read-Host 'Existing destination Unity Catalog catalog'
$FsvSchema = Read-Host 'Dedicated reporting schema, for example network_observability'
$FsvWorkspaceIds = Read-Host 'Explicit numeric source workspace IDs, comma-separated'
$FsvWorkspaceRoot = Read-Host 'Dedicated restricted workspace folder, /Workspace/Users/<deployment-identity>/fsv-dcs-netw-dashboard'

$FsvScopeArgs = @(
    '--catalog', $FsvCatalog,
    '--schema', $FsvSchema,
    '--workspace-ids', $FsvWorkspaceIds
)
$FsvRemoteArgs = @('--profile', $FsvProfile, '--warehouse-id', $FsvWarehouseId)
$FsvCollectionArgs = @()

# Add only the options approved and readable in this customer environment:
# $FsvCollectionArgs += '--include-pipelines'
# $FsvCollectionArgs += @('--pipeline-id', 'APPROVED-PIPELINE-UUID')
# $FsvCollectionArgs += '--without-billing'
```

Keep workspace and job IDs as strings. PowerShell's `$PROFILE`, `$Host` and `$Home` are automatic variables; use the namespaced variables above. All source workspace IDs must belong to the approved regional/metastore scope. Keep that allowlist unchanged between refreshes of the same destination.

Use a dedicated deployment/run identity folder whose edit permissions are restricted to the deployment owners and administrators. A scheduled job runs the uploaded source with its run identity's privileges, so do not place it in a broadly writable shared folder. New subfolders inherit their parent's permissions; confirm those permissions with the platform owner.

Pipeline inventory requires `--include-pipelines`; each event-log ID also requires that option. Billing collection is enabled by default. Use `--without-billing` only when billing access is unavailable, accepting reduced compute classification. Reuse the same collection options for the initial refresh and scheduled job.

## Run checks without a workspace connection

Clear remote-test opt-ins in this process so discovery remains local:

```powershell
'PROFILE', 'WAREHOUSE_ID', 'CATALOG', 'SCHEMA', 'EXPECT_TIMEZONE' | ForEach-Object {
    Remove-Item -LiteralPath ("Env:FSV_SQL_TEST_" + $_) -ErrorAction SilentlyContinue
}
& $FsvPython -m unittest discover -s tests -v
Assert-FsvNativeSuccess 'Local tests'
& $FsvPython .\scripts\build_dashboard.py --check
Assert-FsvNativeSuccess 'Dashboard artifact check'
& $FsvPython -m fsv_network render @FsvScopeArgs @FsvCollectionArgs --lookback-days 90 --output-dir .\build\rendered
Assert-FsvNativeSuccess 'Offline SQL rendering'
```

The remote integration suite should report skipped; the other local tests should pass. Rendering writes reviewable SQL under `build\rendered` and does not authenticate or create workspace resources. Inspect the dashboard layout locally by opening `dashboards\design_preview.html`; it contains no telemetry. Use the separately approved isolated-schema procedure for remote fixture tests, never the reporting schema.

## Connect and authenticate

Offline transfer removes the need to clone Git or download Python packages inside Fiserv. Actual authentication, SQL execution and deployment still require network reachability to the customer Databricks workspace and its configured identity provider. The workspace must also have access to its system tables and managed storage. An entirely disconnected workstation cannot deploy this project.

If required, obtain proxy settings from IT. Set `HTTPS_PROXY`/`HTTP_PROXY` only to the approved proxy, without embedding passwords in a command or repository file. Preserve the corporate `NO_PROXY` entries and allow local OAuth callbacks to bypass the proxy:

```powershell
# Optional; use the values supplied by IT, without proxy credentials here.
# $env:HTTPS_PROXY = 'http://approved-proxy.example:8080'
# $env:HTTP_PROXY = $env:HTTPS_PROXY
$env:NO_PROXY = (@($env:NO_PROXY, 'localhost', '127.0.0.1') | Where-Object { $_ }) -join ','
```

For TLS inspection, ask IT to configure the approved root/intermediate certificates in the Windows trust store used by the CLI. `REQUESTS_CA_BUNDLE` or pip certificate settings do not configure this Go CLI. Do not disable TLS verification. Browser OAuth also needs the organization's SSO/MFA endpoints and the CLI's local loopback callback. Coordinate private endpoint DNS, VPN and proxy rules with the platform team if the workspace uses private connectivity.

Authenticate fresh on Windows using OAuth; do not copy the developer's `.databrickscfg`, credential cache or tokens:

```powershell
databricks auth profiles
Assert-FsvNativeSuccess 'List available profiles'
databricks auth login --host $FsvWorkspaceHost --profile $FsvProfile
Assert-FsvNativeSuccess 'Workspace OAuth login'
databricks auth describe --profile $FsvProfile
Assert-FsvNativeSuccess 'Describe selected authentication'
databricks current-user me --profile $FsvProfile
Assert-FsvNativeSuccess 'Verify selected identity'
databricks warehouses get $FsvWarehouseId --profile $FsvProfile
Assert-FsvNativeSuccess 'Verify selected SQL warehouse'
```

Confirm that the described host is the intended Azure customer workspace and that the warehouse belongs to it. If authentication resolves unexpectedly, inspect the **names** of inherited overrides with `Get-ChildItem Env:DATABRICKS_* | Select-Object -ExpandProperty Name`; remove stale host/token/auth-type overrides from the session only after identifying their source. Avoid sharing `auth env` output because it can contain credentials. Keep CLI profiles, credentials and local deployment state outside the transferred source archive.

## Collect the first 90 days

The destination catalog must exist; the refresh creates its dedicated schema and objects when permitted. This step writes customer reporting tables:

```powershell
& $FsvPython -m fsv_network refresh @FsvRemoteArgs @FsvScopeArgs @FsvCollectionArgs --lookback-days 90
Assert-FsvNativeSuccess 'Initial 90-day refresh'
```

Inspect `<catalog>.<schema>.network_quality` in the SQL editor. Resolve `FAIL` results before using the dashboard. Source retention and delayed system-table delivery determine the available history; a fresh workspace can legitimately have no classic node observations. Missing or serverless byte values remain unknown. See [operations](operations.md) for interpretation and recovery.

## Deploy, test and activate the collector

The helper uploads the required Python modules and SQL as workspace files plus the Python notebook. No Git folder or Python dependency upload is needed. Its default job runs on serverless **STANDARD**, with one concurrent run, a seven-day collection lookback and a 120-day model window. The hourly schedule at minute 15 UTC starts **PAUSED**. The notebook uses serverless Spark SQL; its scheduled execution does not use the local deployment warehouse.

```powershell
New-Item -ItemType Directory -Path .\state -Force | Out-Null
$FsvJobStateFile = Join-Path $PWD.Path 'state\refresh-job.json'
$FsvCollectorArgs = $FsvRemoteArgs + $FsvScopeArgs + @(
    '--workspace-root', $FsvWorkspaceRoot,
    '--state-file', $FsvJobStateFile
)
if (Test-Path -LiteralPath $FsvJobStateFile) {
    throw 'A saved job ID already exists. Verify its target and use --job-id to update it.'
}
& $FsvPython .\scripts\deploy_refresh_job.py @FsvCollectorArgs @FsvCollectionArgs
Assert-FsvNativeSuccess 'Create paused collector'
$FsvJobId = [string]((Get-Content -LiteralPath $FsvJobStateFile -Raw -Encoding UTF8 | ConvertFrom-Json).job_id)

$FsvRunOutput = & databricks jobs run-now $FsvJobId --profile $FsvProfile --no-wait -o json
Assert-FsvNativeSuccess 'Trigger manual collector run'
$FsvRunId = [string](($FsvRunOutput -join "`n" | ConvertFrom-Json).run_id)
databricks jobs get-run $FsvRunId --profile $FsvProfile -o json
Assert-FsvNativeSuccess 'Inspect collector run'
```

STANDARD startup and execution can take several minutes. Repeat `jobs get-run` until the run completes, confirm `state.result_state` is `SUCCESS`, then inspect the notebook task output and persisted quality checks. `jobs get-run-output` takes the notebook **task run ID** from `tasks[].run_id`, not the parent run ID. The task's returned JSON identifies the destination, workspace scope and quality statuses. The run identity needs source/target grants and read access to the uploaded files; workstation OAuth credentials are not transferred to the job.

After the manual run and quality review succeed, activate that same job:

```powershell
& $FsvPython .\scripts\deploy_refresh_job.py @FsvCollectorArgs @FsvCollectionArgs --job-id $FsvJobId --activate
Assert-FsvNativeSuccess 'Activate existing collector schedule'
```

For subsequent source updates, reuse the same arguments and `--job-id`. Omitting the ID creates a new job, even if a name already matches. Omitting `--activate` on an update pauses the schedule. The helper resets settings from the maintained template, replacing separate UI changes; retain approved run identity and notification settings in that configuration. Redeploy between runs because uploaded runtime files are overwritten in place. Record the ID together with its host, catalog and schema; the helper's state file alone contains only the ID.

## Create and update the dashboard

The helper-created workspace folder can also contain the draft dashboard. Every dashboard deployment executes all seven dataset queries on the selected warehouse before creating or updating the draft:

```powershell
$FsvDashboardOutput = & $FsvPython -m fsv_network deploy-dashboard @FsvRemoteArgs @FsvScopeArgs --parent-path $FsvWorkspaceRoot
Assert-FsvNativeSuccess 'Create validated dashboard draft'
$FsvDashboardOutput | ForEach-Object { Write-Host $_ }
$FsvDashboardId = [string](($FsvDashboardOutput | Select-Object -Last 1 | ConvertFrom-Json).dashboard_id)
Write-Host "$FsvWorkspaceHost/sql/dashboardsv3/$FsvDashboardId"
```

Inspect the draft in the browser, exercise workspace/job/date filters and confirm that its history page retains 90 UTC dates independently of the daily window. Review unknown byte values and estimated-versus-physical labels. Empty charts on a new customer workspace do not justify treating unsupported telemetry as zero. The synthetic demo uses a separate schema and must be explicitly deployed and labeled as synthetic; it is not customer network evidence.

Save a target-specific handoff record, without credentials:

```powershell
$FsvDeploymentRecord = [ordered]@{
    profile = $FsvProfile; host = $FsvWorkspaceHost
    warehouse_id = $FsvWarehouseId; catalog = $FsvCatalog; schema = $FsvSchema
    source_workspace_ids = $FsvWorkspaceIds; workspace_root = $FsvWorkspaceRoot
    collector_job_id = $FsvJobId; dashboard_id = $FsvDashboardId
    collection_args = @($FsvCollectionArgs)
}
$FsvRecordPath = Join-Path $PWD.Path 'state\customer-deployment.json'
[IO.File]::WriteAllText($FsvRecordPath, ($FsvDeploymentRecord | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
```

To update or publish, supply the existing dashboard ID so its URL is preserved:

```powershell
& $FsvPython -m fsv_network deploy-dashboard @FsvRemoteArgs @FsvScopeArgs --dashboard-id $FsvDashboardId
Assert-FsvNativeSuccess 'Update existing dashboard draft'

# After reviewing the updated draft and its publication credentials/permissions:
& $FsvPython -m fsv_network deploy-dashboard @FsvRemoteArgs @FsvScopeArgs --dashboard-id $FsvDashboardId --publish
Assert-FsvNativeSuccess 'Publish existing dashboard'
Write-Host "$FsvWorkspaceHost/sql/dashboardsv3/$FsvDashboardId/published"
```

An update changes the draft; publishing creates the viewer snapshot. Omitting `--dashboard-id` creates another dashboard. After reopening PowerShell, re-establish the interpreter/PATH/target variables and restore the saved job/dashboard IDs only after checking the record against the selected customer host. Keep `state/` locally for operations and exclude it from source transfers. Collector scheduling and dashboard refresh/publication scheduling are separate.

## Resume an existing deployment

After preparing the interpreter and target variables in a new session, read the saved customer record. If using a new source directory, retrieve this record from the existing deployment's local `state/` directory first. Do not rerun the collector/dashboard creation blocks.

```powershell
$FsvRecordPath = Read-Host 'Full path to the existing customer-deployment.json'
$FsvSaved = Get-Content -LiteralPath $FsvRecordPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($FsvSaved.host -ne $FsvWorkspaceHost -or
    $FsvSaved.catalog -ne $FsvCatalog -or $FsvSaved.schema -ne $FsvSchema -or
    $FsvSaved.source_workspace_ids -ne $FsvWorkspaceIds -or
    $FsvSaved.workspace_root -ne $FsvWorkspaceRoot -or
    $FsvSaved.warehouse_id -ne $FsvWarehouseId) {
    throw 'Saved deployment target differs from the selected target. Resolve before updating.'
}
$FsvJobId = [string]$FsvSaved.collector_job_id
$FsvDashboardId = [string]$FsvSaved.dashboard_id
$FsvCollectionArgs = @($FsvSaved.collection_args)
New-Item -ItemType Directory -Path .\state -Force | Out-Null
$FsvJobStateFile = Join-Path $PWD.Path 'state\refresh-job.json'
$FsvCollectorArgs = $FsvRemoteArgs + $FsvScopeArgs + @(
    '--workspace-root', $FsvWorkspaceRoot,
    '--state-file', $FsvJobStateFile
)
```

Verify the selected CLI profile's host/identity again. Pause the collector in the Jobs UI and let any active run finish. Upload the updated source and reset the existing job **without** `--activate`; this keeps scheduling paused:

```powershell
& $FsvPython .\scripts\deploy_refresh_job.py @FsvCollectorArgs @FsvCollectionArgs --job-id $FsvJobId
Assert-FsvNativeSuccess 'Update existing paused collector'
```

Repeat the manual run and quality checks, then use the activation command with the existing ID. Use the earlier dashboard update/publish commands with `$FsvDashboardId`. Save an updated customer handoff record for the new source revision.
