# Databricks notebook source
"""Schedule this notebook from a Databricks Git folder or a job Git source.

Use the same target parameters and identities on every run. No pip install,
init script, Databricks Connect, or Asset Bundle is required.
"""

# COMMAND ----------
dbutils.widgets.text("repo_root", "")
dbutils.widgets.text("catalog", "")
dbutils.widgets.text("schema", "")
dbutils.widgets.text("workspace_ids", "")
dbutils.widgets.text("lookback_days", "7")
dbutils.widgets.text("history_days", "120")
dbutils.widgets.dropdown("include_billing", "true", ["true", "false"])
dbutils.widgets.dropdown("include_pipelines", "false", ["true", "false"])
dbutils.widgets.text("pipeline_ids", "")

# COMMAND ----------
from datetime import datetime, timezone
from pathlib import Path
import sys

# On DBR 14+ and serverless, notebooks in Git folders use their containing folder
# as CWD. An explicit repo_root is available for other execution contexts.
configured_root = dbutils.widgets.get("repo_root").strip()
repo_root = Path(configured_root) if configured_root else Path.cwd().parent
if not (repo_root / "sql" / "00_setup.sql").is_file():
    raise ValueError("Set repo_root to the checked-out repository directory containing sql/ and src/")
sys.path.insert(0, str(repo_root / "src"))

from fsv_network.pipeline import Settings, default_dates, plan

start, end, history = default_dates(
    datetime.now(timezone.utc).date(),
    int(dbutils.widgets.get("lookback_days")),
    int(dbutils.widgets.get("history_days")),
)
settings = Settings(
    catalog=dbutils.widgets.get("catalog"),
    schema=dbutils.widgets.get("schema"),
    workspace_ids=tuple(w.strip() for w in dbutils.widgets.get("workspace_ids").split(",") if w.strip()),
    start_date=start, end_date=end, history_start_date=history,
    include_billing=dbutils.widgets.get("include_billing") == "true",
    include_pipelines=dbutils.widgets.get("include_pipelines") == "true",
    pipeline_ids=tuple(p.strip() for p in dbutils.widgets.get("pipeline_ids").split(",") if p.strip()),
)

# COMMAND ----------
for label, statement in plan(repo_root, settings):
    print(f"Executing {label}")
    spark.sql(statement).collect()

quality = spark.table(f"`{settings.catalog}`.`{settings.schema}`.network_quality")
display(quality)

# COMMAND ----------
import json

dbutils.notebook.exit(json.dumps({
    "catalog": settings.catalog,
    "schema": settings.schema,
    "workspace_ids": settings.workspace_ids,
    "quality": [{"check": row.check_name, "status": row.status} for row in quality.collect()],
}))
