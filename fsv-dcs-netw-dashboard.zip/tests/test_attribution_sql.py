"""Opt-in SQL integration tests, using the actual model and a new isolated schema.

No network calls occur unless ALL four FSV_SQL_TEST_* variables are supplied:
PROFILE, WAREHOUSE_ID, CATALOG, SCHEMA. SCHEMA must start fsv_network_test_.
The named schema must not exist. Tests drop only the schema they created.

Run: PYTHONPATH=src python -m unittest discover -s tests -p test_attribution_sql.py -v
This suite needs a SQL warehouse and CREATE SCHEMA in the named catalog.
Fixture timestamps have explicit UTC offsets. Repeat with UTC and non-UTC
warehouse configurations to test timezone independence; optional
FSV_SQL_TEST_EXPECT_TIMEZONE verifies the selected warehouse's session timezone.
It never reads customer system tables or customer bronze.
"""

from datetime import date, datetime, timezone
from decimal import Decimal
import os
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from fsv_network.databricks_cli import DatabricksCLI
from fsv_network.pipeline import Settings, identifier, render, split_statements


class AttributionSQLIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        keys = ("PROFILE", "WAREHOUSE_ID", "CATALOG", "SCHEMA")
        values = {k: os.environ.get("FSV_SQL_TEST_" + k, "").strip() for k in keys}
        if not any(values.values()):
            raise unittest.SkipTest("Set all FSV_SQL_TEST_* variables to run isolated remote SQL fixtures")
        missing = ["FSV_SQL_TEST_" + k for k, value in values.items() if not value]
        if missing:
            raise ValueError("Incomplete integration test configuration: " + ", ".join(missing))
        if not values["SCHEMA"].startswith("fsv_network_test_"):
            raise ValueError("Test schema must begin fsv_network_test_; production schemas are refused")
        cls.settings = Settings(
            catalog=values["CATALOG"], schema=values["SCHEMA"], workspace_ids=("1",),
            start_date=date(2025, 12, 31), end_date=date(2026, 1, 2),
            history_start_date=date(2025, 12, 31), include_billing=False,
        )
        cls.client = DatabricksCLI(values["PROFILE"], values["WAREHOUSE_ID"])
        cls.target = identifier(values["CATALOG"]) + "." + identifier(values["SCHEMA"])
        timezone = cls.client.execute("SELECT current_timezone() timezone", cls.settings.catalog, None)
        actual_timezone = timezone["result"]["data_array"][0][0]
        expected_timezone = os.environ.get("FSV_SQL_TEST_EXPECT_TIMEZONE")
        if expected_timezone and actual_timezone != expected_timezone:
            raise ValueError(f"Expected timezone {expected_timezone!r}, got {actual_timezone!r}")
        # Deliberately omit IF NOT EXISTS: never adopt or delete an existing schema.
        cls.client.execute("CREATE SCHEMA " + cls.target, cls.settings.catalog, None)
        cls.addClassCleanup(cls._drop_created_schema)
        cls._execute_file(ROOT / "sql" / "00_setup.sql")
        cls._execute_file(ROOT / "tests" / "fixtures" / "attribution.sql")
        cls._rebuild_model()

    @classmethod
    def _drop_created_schema(cls):
        cls.client.execute("DROP SCHEMA " + cls.target + " CASCADE", cls.settings.catalog, None)

    @classmethod
    def _execute_file(cls, path):
        for statement in split_statements(render(path.read_text(encoding="utf-8"), cls.settings)):
            cls.client.execute(statement, cls.settings.catalog, cls.settings.schema)

    @classmethod
    def _rebuild_model(cls):
        cls._execute_file(ROOT / "sql" / "20_model.sql")
        cls._execute_file(ROOT / "sql" / "30_quality.sql")

    def rows(self, query):
        response = self.client.execute(query.replace("{target}", self.target),
                                       self.settings.catalog, self.settings.schema)
        manifest = response.get("manifest", {})
        if manifest.get("truncated") or response.get("result", {}).get("next_chunk_index") is not None:
            self.fail("Fixture query exceeded the client result limit; restrict the assertion query")
        columns = [c["name"] for c in manifest["schema"]["columns"]]
        return [dict(zip(columns, row)) for row in response.get("result", {}).get("data_array", [])]

    def number(self, value):
        self.assertIsNotNone(value)
        return Decimal(str(value))

    def test_conservation_and_same_run_parallel_tasks(self):
        totals = self.rows("""
            SELECT SUM(network_received_bytes) received, SUM(network_sent_bytes) sent
            FROM {target}.bronze_node_timeline WHERE workspace_id = '1'
        """)[0]
        measured = self.rows("""
            SELECT SUM(received_bytes) received, SUM(sent_bytes) sent FROM {target}.network_segments
        """)[0]
        self.assertEqual(self.number(totals["received"]), self.number(measured["received"]))
        self.assertEqual(self.number(totals["sent"]), self.number(measured["sent"]))
        rows = self.rows("""
            SELECT active_workload_count, attribution_status, received_bytes, sent_bytes,
                   cluster_received_mbps, observed_node_seconds, observed_nodes
            FROM {target}.network_segments WHERE cluster_id = 'c_same'
        """)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["attribution_status"], "SINGLE_ACTIVE_WORKLOAD")
        self.assertEqual(self.number(rows[0]["active_workload_count"]), 1)
        self.assertEqual(self.number(rows[0]["received_bytes"]), 1800)
        self.assertEqual(self.number(rows[0]["sent_bytes"]), 900)
        self.assertEqual(self.number(rows[0]["observed_nodes"]), 2)
        self.assertEqual(self.number(rows[0]["observed_node_seconds"]), 120)
        self.assertEqual(self.number(rows[0]["cluster_received_mbps"]), Decimal("0.00024"))
        buckets = self.rows("""
            SELECT SUM(measured_total_bytes) measured,
                   SUM(single_active_total_bytes + shared_total_bytes + unattributed_total_bytes) buckets
            FROM {target}.network_cluster_daily
        """)[0]
        self.assertEqual(self.number(buckets["measured"]), self.number(buckets["buckets"]))

    def test_concurrent_runs_remain_ambiguous(self):
        rows = self.rows("""
            SELECT active_workload_count, attribution_status, job_run_id, received_bytes
            FROM {target}.network_segments WHERE cluster_id = 'c_shared'
        """)
        self.assertEqual(len(rows), 1)
        self.assertEqual(self.number(rows[0]["active_workload_count"]), 2)
        self.assertEqual(rows[0]["attribution_status"], "SHARED_AMBIGUOUS")
        self.assertIsNone(rows[0]["job_run_id"])
        self.assertEqual(self.number(rows[0]["received_bytes"]), 6000)
        inventory = self.rows("""
            SELECT run_id, network_coverage, attributed_total_bytes
            FROM {target}.network_run_inventory WHERE workload_id IN ('job_shared_a', 'job_shared_b')
        """)
        self.assertEqual(len(inventory), 2)
        for row in inventory:
            self.assertEqual(row["network_coverage"], "SHARED_ONLY")
            self.assertIsNone(row["attributed_total_bytes"])

    def test_partial_minute_and_midnight(self):
        rows = self.rows("""
            SELECT attribution_status, SUM(received_bytes) received
            FROM {target}.network_segments WHERE cluster_id = 'c_partial'
            GROUP BY attribution_status
        """)
        self.assertEqual({row["attribution_status"]: self.number(row["received"]) for row in rows},
                         {"SINGLE_ACTIVE_WORKLOAD": Decimal(300), "UNATTRIBUTED": Decimal(300)})
        days = self.rows("""
            SELECT CAST(usage_date AS STRING) usage_date, received_bytes, sent_bytes
            FROM {target}.network_daily WHERE job_run_id = 'run_midnight'
            ORDER BY usage_date
        """)
        self.assertEqual([row["usage_date"] for row in days], ["2025-12-31", "2026-01-01"])
        for row in days:
            self.assertEqual(self.number(row["received_bytes"]), 600)
            self.assertEqual(self.number(row["sent_bytes"]), 300)

    def test_missing_and_serverless_measurements_remain_null(self):
        rows = self.rows("""
            SELECT workload_id, compute_type, total_bytes, network_coverage
            FROM {target}.network_daily
            WHERE workload_id IN ('job_missing', 'job_serverless', 'job_unknown')
        """)
        self.assertEqual(len(rows), 3)
        expected = {"job_missing": "CLASSIC", "job_serverless": "SERVERLESS", "job_unknown": "UNKNOWN"}
        for row in rows:
            self.assertEqual(row["compute_type"], expected[row["workload_id"]])
            self.assertIsNone(row["total_bytes"])
            self.assertEqual(row["network_coverage"], "NO_NODE_METRICS")
        mixed = self.rows("""
            SELECT compute_type, attributed_total_bytes FROM {target}.network_run_inventory
            WHERE workload_id = 'job_mixed'
        """)
        self.assertEqual(len(mixed), 1)
        self.assertEqual(mixed[0]["compute_type"], "MIXED")
        self.assertEqual(self.number(mixed[0]["attributed_total_bytes"]), 1200)
        daily_mixed = self.rows("""
            SELECT compute_type FROM {target}.network_daily WHERE workload_id = 'job_mixed'
        """)
        self.assertEqual([row["compute_type"] for row in daily_mixed], ["MIXED"])

    def test_manual_pipeline_bridge_does_not_double_count_or_create_sharing(self):
        rows = self.rows("""
            SELECT workload_type, pipeline_id, update_id, attribution_status,
                   SUM(total_bytes) total_bytes, MAX(active_workload_count) active_workloads
            FROM {target}.network_segments WHERE cluster_id = 'c_pipeline'
            GROUP BY workload_type, pipeline_id, update_id, attribution_status
        """)
        self.assertEqual(len(rows), 2)
        by_type = {row["workload_type"]: row for row in rows}
        pipeline = by_type["PIPELINE"]
        self.assertEqual(pipeline["pipeline_id"], "pipeline_manual")
        self.assertEqual(pipeline["update_id"], "update_manual")
        self.assertEqual(pipeline["attribution_status"], "SINGLE_ACTIVE_WORKLOAD")
        self.assertEqual(self.number(pipeline["active_workloads"]), 1)
        self.assertEqual(self.number(pipeline["total_bytes"]), 1600)
        self.assertEqual(self.number(by_type["UNATTRIBUTED"]["total_bytes"]), 800)
        inventory = self.rows("""
            SELECT workload_type, workload_id, compute_type, attributed_total_bytes
            FROM {target}.network_run_inventory
            WHERE workload_id IN ('pipeline_manual', 'job_pipeline_parent')
        """)
        self.assertEqual(len(inventory), 2)
        by_id = {row["workload_id"]: row for row in inventory}
        self.assertEqual(by_id["pipeline_manual"]["compute_type"], "CLASSIC")
        self.assertEqual(self.number(by_id["pipeline_manual"]["attributed_total_bytes"]), 1600)
        self.assertEqual(by_id["job_pipeline_parent"]["compute_type"], "CLASSIC")
        self.assertIsNone(by_id["job_pipeline_parent"]["attributed_total_bytes"])
        serverless = self.rows("""
            SELECT compute_type, total_bytes FROM {target}.network_daily
            WHERE pipeline_id = 'pipeline_serverless'
        """)
        self.assertEqual(len(serverless), 1)
        self.assertEqual(serverless[0]["compute_type"], "SERVERLESS")
        self.assertIsNone(serverless[0]["total_bytes"])

    def test_scope_isolation_and_real_zero_bytes(self):
        rows = self.rows("""
            SELECT COUNT(*) row_count FROM (
                SELECT workspace_id FROM {target}.network_segments
                UNION ALL SELECT workspace_id FROM {target}.network_daily
                UNION ALL SELECT workspace_id FROM {target}.network_run_inventory
            ) WHERE workspace_id <> '1'
        """)
        self.assertEqual(self.number(rows[0]["row_count"]), 0)
        zero = self.rows("""
            SELECT total_bytes, network_coverage FROM {target}.network_daily
            WHERE job_run_id = 'run_zero'
        """)
        self.assertEqual(len(zero), 1)
        self.assertEqual(self.number(zero[0]["total_bytes"]), 0)
        self.assertEqual(zero[0]["network_coverage"], "OBSERVED_EXCLUSIVE")

    def test_billing_evidence_classifies_compute_without_inventing_bytes(self):
        rows = self.rows("""
            SELECT workload_id, compute_type, total_bytes FROM {target}.network_daily
            WHERE workload_id IN ('job_bill_classic', 'job_bill_serverless', 'job_bill_sql', 'job_bill_mixed')
        """)
        expected = {"job_bill_classic": "CLASSIC", "job_bill_serverless": "SERVERLESS",
                    "job_bill_sql": "SQL_WAREHOUSE", "job_bill_mixed": "MIXED"}
        self.assertEqual(len(rows), len(expected))
        for row in rows:
            self.assertEqual(row["compute_type"], expected[row["workload_id"]])
            self.assertIsNone(row["total_bytes"])

    def test_event_log_adapter_preserves_manual_bounds_and_scope(self):
        """Execute production SQL13; replace only its event_log source relation.

        The fixture table has the documented event-log timestamp/origin fields.
        Every remaining statement, including DELETE and MERGE, is production SQL.
        All objects and IDs below exist only inside this suite's new test schema.
        """
        pipeline_id = "adapter-test-pipeline"
        other_pipeline = "adapter-test-other-pipeline"
        reserved = "EVENT_LOG_SINGLE_OBSERVED_CLUSTER_ESTIMATE"
        verified = "ADAPTER_TEST_VERIFIED_MANUAL"
        source_table = self.target + ".fixture_pipeline_adapter_events"
        candidate_view = self.target + ".silver_pipeline_event_cluster_candidates"

        def execute(sql):
            return self.client.execute(sql.replace("{target}", self.target),
                                       self.settings.catalog, self.settings.schema)

        def literal(value):
            return "'" + value.replace("'", "''") + "'"

        def timestamp(clock):
            return "to_timestamp('2026-01-01T" + clock + "Z')"

        # Different starts and clusters ensure protection applies to the whole
        # update, rather than merely protecting one coincident MERGE key.
        mappings = [
            ("1", pipeline_id, "adapter_test_manual_same", "c_manual_same", "00:00:00", "00:10:00", verified),
            ("1", pipeline_id, "adapter_test_manual_same", "c_stale", "00:10:00", "01:00:00", reserved),
            ("1", pipeline_id, "adapter_test_manual_different", "c_verified", "00:10:00", "00:20:00", verified),
            ("1", pipeline_id, "adapter_test_manual_no_events", "c_verified", "00:20:00", "00:30:00", verified),
            ("1", pipeline_id, "adapter_test_manual_no_events", "c_stale", "00:00:00", "01:00:00", reserved),
            ("1", pipeline_id, "adapter_test_auto_only", "c_stale", "00:00:00", "01:00:00", reserved),
            ("1", pipeline_id, "adapter_test_multiple_clusters", "c_stale", "00:00:00", "01:00:00", reserved),
            ("2", pipeline_id, "adapter_test_workspace_sentinel", "c_manual", "00:10:00", "00:20:00", verified),
            ("2", pipeline_id, "adapter_test_workspace_sentinel", "c_stale", "00:00:00", "01:00:00", reserved),
            ("1", other_pipeline, "adapter_test_pipeline_sentinel", "c_manual", "00:10:00", "00:20:00", verified),
            ("1", other_pipeline, "adapter_test_pipeline_sentinel", "c_stale", "00:00:00", "01:00:00", reserved),
        ]
        updates = sorted({(ws, pid, update) for ws, pid, update, *_ in mappings})
        events = [
            ("1", pipeline_id, "adapter_test_manual_same", "c_manual_same"),
            ("1", pipeline_id, "adapter_test_manual_different", "c_auto"),
            ("1", pipeline_id, "adapter_test_auto_only", "c_auto"),
            ("1", pipeline_id, "adapter_test_multiple_clusters", "c_first"),
            ("1", pipeline_id, "adapter_test_multiple_clusters", "c_second"),
            ("2", pipeline_id, "adapter_test_workspace_sentinel", "c_auto"),
            ("1", other_pipeline, "adapter_test_pipeline_sentinel", "c_auto"),
        ]
        selection = "pipeline_id IN ('adapter-test-pipeline', 'adapter-test-other-pipeline')"
        mapping_query = """
            SELECT workspace_id, pipeline_id, update_id, cluster_id,
                   unix_micros(period_start_time) start_us, unix_micros(period_end_time) end_us,
                   parent_job_id, parent_job_run_id, job_task_run_id, evidence_source,
                   unix_micros(ingested_at) ingested_us
            FROM {target}.bronze_pipeline_intervals WHERE
        """ + selection + " ORDER BY workspace_id, pipeline_id, update_id, cluster_id, start_us"
        try:
            execute("CREATE TABLE " + source_table + " (timestamp TIMESTAMP, origin "
                    "STRUCT<org_id:BIGINT,pipeline_id:STRING,update_id:STRING,cluster_id:STRING>) USING DELTA")
            timeline_values = [
                "(" + ", ".join([literal(ws), literal(pid), literal(update), timestamp("00:00:00"),
                                   timestamp("01:00:00"), "'COMPLETED'", "'{}'", "'{}'", "current_timestamp()"])
                + ")" for ws, pid, update in updates
            ]
            execute("INSERT INTO {target}.bronze_pipeline_update_timeline "
                    "(workspace_id,pipeline_id,update_id,period_start_time,period_end_time,"
                    "result_state,compute_json,trigger_details_json,ingested_at) VALUES "
                    + ",\n".join(timeline_values))
            interval_values = [
                "(" + ", ".join([literal(ws), literal(pid), literal(update), literal(cluster),
                                   timestamp(start), timestamp(end), "NULL", "NULL", "NULL",
                                   literal(evidence), "current_timestamp()"])
                + ")" for ws, pid, update, cluster, start, end, evidence in mappings
            ]
            execute("INSERT INTO {target}.bronze_pipeline_intervals "
                    "(workspace_id,pipeline_id,update_id,cluster_id,period_start_time,period_end_time,"
                    "parent_job_id,parent_job_run_id,job_task_run_id,evidence_source,ingested_at) VALUES "
                    + ",\n".join(interval_values))
            event_values = [
                "(" + timestamp("00:05:00") + ", named_struct('org_id', CAST(" + literal(ws)
                + " AS BIGINT), 'pipeline_id', " + literal(pid) + ", 'update_id', " + literal(update)
                + ", 'cluster_id', " + literal(cluster) + "))"
                for ws, pid, update, cluster in events
            ]
            execute("INSERT INTO " + source_table + " VALUES " + ",\n".join(event_values))
            before = self.rows(mapping_query)
            preserved = [row for row in before if row["evidence_source"] == verified
                         or row["workspace_id"] == "2" or row["pipeline_id"] == other_pipeline]

            template = (ROOT / "sql" / "13_pipeline_events.sql").read_text(encoding="utf-8")
            event_source = "FROM event_log('__PIPELINE_ID__')"
            self.assertEqual(template.count(event_source), 1)
            template = template.replace(event_source, "FROM " + source_table)
            statements = split_statements(render(template, self.settings, {"__PIPELINE_ID__": pipeline_id}))
            for statement in statements:
                execute(statement)
            first = self.rows(mapping_query)
            after_preserved = [row for row in first if row["evidence_source"] == verified
                               or row["workspace_id"] == "2" or row["pipeline_id"] == other_pipeline]
            self.assertEqual(after_preserved, preserved)
            active = [row for row in first if row["workspace_id"] == "1" and row["pipeline_id"] == pipeline_id]
            self.assertEqual({row["update_id"] for row in active}, {
                "adapter_test_manual_same", "adapter_test_manual_different",
                "adapter_test_manual_no_events", "adapter_test_auto_only",
            })
            automatic = [row for row in active if row["evidence_source"] == reserved]
            self.assertEqual(len(automatic), 1)
            self.assertEqual(automatic[0]["update_id"], "adapter_test_auto_only")
            self.assertEqual(automatic[0]["cluster_id"], "c_auto")
            epoch_us = int(datetime(2026, 1, 1, tzinfo=timezone.utc).timestamp()) * 1_000_000
            self.assertEqual(self.number(automatic[0]["start_us"]), epoch_us)
            self.assertEqual(self.number(automatic[0]["end_us"]), epoch_us + 3_600_000_000)
            self.assertEqual(len(active), 4)

            for statement in statements:
                execute(statement)
            second = self.rows(mapping_query)
            # Auto rows receive a new ingestion timestamp; placement stays identical.
            without_ingestion = lambda rows: [{k: v for k, v in row.items() if k != "ingested_us"} for row in rows]
            self.assertEqual(without_ingestion(second), without_ingestion(first))
            self.assertEqual([row for row in second if row["evidence_source"] == verified
                              or row["workspace_id"] == "2" or row["pipeline_id"] == other_pipeline], preserved)
        finally:
            execute("DROP VIEW IF EXISTS " + candidate_view)
            execute("DROP TABLE IF EXISTS " + source_table)
            execute("DELETE FROM {target}.bronze_pipeline_intervals WHERE " + selection)
            execute("DELETE FROM {target}.bronze_pipeline_update_timeline WHERE " + selection)

    def test_manual_compute_conflicts_preserve_classic_measurements(self):
        evidence = "SYNTHETIC_COMPUTE_CONFLICT_TEST_OVERRIDE"
        cases = [
            ("job_same", "run_same", "SERVERLESS", "MIXED", Decimal(2700)),
            ("job_partial", "run_partial", "SQL_WAREHOUSE", "MIXED", Decimal(450)),
            ("job_zero", "run_zero", "UNKNOWN", "CLASSIC", Decimal(0)),
            ("job_bill_serverless", "run_bill_serverless", "CLASSIC", "MIXED", None),
            ("job_bill_sql", "run_bill_sql", "SERVERLESS", "MIXED", None),
        ]
        values = [
            "('1','JOB','" + job + "','" + run + "','" + override + "','" + evidence
            + "', current_timestamp() + INTERVAL 1 DAY)"
            for job, run, override, _, _ in cases
        ]
        try:
            self.client.execute(
                "INSERT INTO " + self.target + ".bronze_compute_classification "
                "(workspace_id,workload_type,workload_id,run_id,compute_type,evidence_source,ingested_at) VALUES "
                + ",\n".join(values), self.settings.catalog, self.settings.schema)
            self._rebuild_model()
            identifiers = ", ".join("'" + job + "'" for job, *_ in cases)
            for table, byte_column in [("network_daily", "total_bytes"),
                                       ("network_run_inventory", "attributed_total_bytes")]:
                rows = self.rows("SELECT workload_id, compute_type, " + byte_column
                                 + " bytes FROM {target}." + table + " WHERE workload_id IN (" + identifiers + ")")
                self.assertEqual(len(rows), len(cases))
                by_id = {row["workload_id"]: row for row in rows}
                for job, _, _, expected_type, expected_bytes in cases:
                    self.assertEqual(by_id[job]["compute_type"], expected_type)
                    if expected_bytes is None:
                        self.assertIsNone(by_id[job]["bytes"])
                    else:
                        self.assertEqual(self.number(by_id[job]["bytes"]), expected_bytes)
        finally:
            self.client.execute("DELETE FROM " + self.target + ".bronze_compute_classification "
                                "WHERE evidence_source = '" + evidence + "'",
                                self.settings.catalog, self.settings.schema)
            self._rebuild_model()

    def test_z_late_source_correction_replaces_materialized_totals(self):
        # Mimic an updated bronze interval, then execute the production model twice.
        # Restore even on assertion failure so other tests remain order-independent.
        correction = """
            UPDATE {target}.bronze_node_timeline
            SET network_received_bytes = {received}, network_sent_bytes = {sent},
                ingested_at = current_timestamp()
            WHERE cluster_id = 'c_same' AND instance_id = 'i_same'
        """
        try:
            self.client.execute(correction.replace("{target}", self.target).format(received=2400, sent=1200),
                                self.settings.catalog, self.settings.schema)
            for _ in range(2):
                self._rebuild_model()
                row = self.rows("""
                    SELECT COUNT(*) row_count, SUM(received_bytes) received, SUM(sent_bytes) sent
                    FROM {target}.network_daily WHERE job_run_id = 'run_same'
                """)[0]
                self.assertEqual(self.number(row["row_count"]), 1)
                self.assertEqual(self.number(row["received"]), 3000)
                self.assertEqual(self.number(row["sent"]), 1500)
        finally:
            self.client.execute(correction.replace("{target}", self.target).format(received=1200, sent=600),
                                self.settings.catalog, self.settings.schema)
            self._rebuild_model()

    def test_zz_empty_node_source_preserves_missing_measurements(self):
        try:
            self.client.execute("TRUNCATE TABLE " + self.target + ".bronze_node_timeline",
                                self.settings.catalog, self.settings.schema)
            self._rebuild_model()
            rows = self.rows("SELECT COUNT(*) row_count FROM {target}.network_segments")
            self.assertEqual(self.number(rows[0]["row_count"]), 0)
            rows = self.rows("""
                SELECT COUNT(*) run_days, COUNT(total_bytes) measured_rows
                FROM {target}.network_daily
            """)
            self.assertGreater(self.number(rows[0]["run_days"]), 0)
            self.assertEqual(self.number(rows[0]["measured_rows"]), 0)
            checks = self.rows("""
                SELECT check_name, status FROM {target}.network_quality
                WHERE check_name IN ('no_node_data', 'byte_conservation')
            """)
            self.assertEqual({row["check_name"]: row["status"] for row in checks},
                             {"no_node_data": "WARN", "byte_conservation": "PASS"})
        finally:
            fixture = ROOT / "tests" / "fixtures" / "attribution.sql"
            insert_nodes = split_statements(render(fixture.read_text(encoding="utf-8"), self.settings))[0]
            self.client.execute(insert_nodes, self.settings.catalog, self.settings.schema)
            self._rebuild_model()


if __name__ == "__main__":
    unittest.main()
