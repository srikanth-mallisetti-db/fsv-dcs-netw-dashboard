-- Synthetic intervals only. Run through tests/test_attribution_sql.py in a NEW test schema.
-- Cases: same-run parallel tasks; concurrent runs; uncovered time; midnight;
-- classic missing telemetry; serverless; unknown; mixed; zero bytes; scope isolation;
-- a manual pipeline bridge; positive billing evidence; and a corrected sample.
INSERT INTO __CATALOG__.__SCHEMA__.bronze_node_timeline
  (workspace_id, cluster_id, instance_id, driver, start_time, end_time,
   network_received_bytes, network_sent_bytes, ingested_at)
VALUES
  ('1', 'c_same', 'i_same', false, to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 1200, 600, current_timestamp()),
  ('1', 'c_same', 'i_same_driver', true, to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 600, 300, current_timestamp()),
  ('1', 'c_shared', 'i_shared', false, to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 6000, 3000, current_timestamp()),
  ('1', 'c_partial', 'i_partial', true, to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 600, 300, current_timestamp()),
  ('1', 'c_midnight', 'i_midnight', false, to_timestamp('2025-12-31T23:59:30Z'), to_timestamp('2026-01-01T00:00:30Z'), 1200, 600, current_timestamp()),
  ('1', 'c_mixed', 'i_mixed', false, to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 900, 300, current_timestamp()),
  ('1', 'c_zero', 'i_zero', false, to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 0, 0, current_timestamp()),
  ('1', 'c_pipeline', 'i_pipeline', false, to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 1800, 600, current_timestamp()),
  ('2', 'c_same', 'i_out_of_scope', false, to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 9000000, 9000000, current_timestamp());
-- COMMAND ----------
INSERT INTO __CATALOG__.__SCHEMA__.bronze_clusters
  (workspace_id, cluster_id, cluster_name, cluster_source, change_time, delete_time, ingested_at)
VALUES
  ('1', 'c_same', 'Same-run tasks', 'JOB', to_timestamp('2025-12-01T00:00:00Z'), NULL, current_timestamp()),
  ('1', 'c_shared', 'Concurrent jobs', 'JOB', to_timestamp('2025-12-01T00:00:00Z'), NULL, current_timestamp()),
  ('1', 'c_partial', 'Partial overlap', 'JOB', to_timestamp('2025-12-01T00:00:00Z'), NULL, current_timestamp()),
  ('1', 'c_midnight', 'Midnight split', 'JOB', to_timestamp('2025-12-01T00:00:00Z'), NULL, current_timestamp()),
  ('1', 'c_missing', 'Missing telemetry', 'JOB', to_timestamp('2025-12-01T00:00:00Z'), NULL, current_timestamp()),
  ('1', 'c_mixed', 'Classic part of mixed run', 'JOB', to_timestamp('2025-12-01T00:00:00Z'), NULL, current_timestamp());
-- COMMAND ----------
INSERT INTO __CATALOG__.__SCHEMA__.bronze_job_run_timeline
  (workspace_id, job_id, job_run_id, period_start_time, period_end_time,
   result_state, termination_code, ingested_at)
VALUES
  ('1', 'job_same', 'run_same', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_shared_a', 'run_shared_a', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_shared_b', 'run_shared_b', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_partial', 'run_partial', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:00:30Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_midnight', 'run_midnight', to_timestamp('2025-12-31T23:59:30Z'), to_timestamp('2026-01-01T00:00:30Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_missing', 'run_missing', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_serverless', 'run_serverless', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_unknown', 'run_unknown', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_mixed', 'run_mixed', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_zero', 'run_zero', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_pipeline_parent', 'run_pipeline_parent', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_bill_classic', 'run_bill_classic', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_bill_serverless', 'run_bill_serverless', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_bill_sql', 'run_bill_sql', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_bill_mixed', 'run_bill_mixed', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('2', 'job_out_of_scope', 'run_out_of_scope', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'SUCCEEDED', 'SUCCESS', current_timestamp());
-- COMMAND ----------
INSERT INTO __CATALOG__.__SCHEMA__.bronze_job_task_run_timeline
  (workspace_id, job_id, job_run_id, task_run_id, task_key,
   period_start_time, period_end_time, compute_ids, result_state,
   termination_code, ingested_at)
VALUES
  ('1', 'job_same', 'run_same', 'task_same_a', 'a', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), array('c_same'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_same', 'run_same', 'task_same_b', 'b', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), array('c_same'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_shared_a', 'run_shared_a', 'task_shared_a', 'a', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), array('c_shared'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_shared_b', 'run_shared_b', 'task_shared_b', 'a', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), array('c_shared'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_partial', 'run_partial', 'task_partial', 'a', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:00:30Z'), array('c_partial'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_midnight', 'run_midnight', 'task_midnight', 'a', to_timestamp('2025-12-31T23:59:30Z'), to_timestamp('2026-01-01T00:00:30Z'), array('c_midnight'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_missing', 'run_missing', 'task_missing', 'a', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), array('c_missing'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_serverless', 'run_serverless', 'task_serverless', 'a', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), CAST(array() AS ARRAY<STRING>), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_unknown', 'run_unknown', 'task_unknown', 'a', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), CAST(array() AS ARRAY<STRING>), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_mixed', 'run_mixed', 'task_mixed', 'a', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), array('c_mixed'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_zero', 'run_zero', 'task_zero', 'a', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), array('c_zero'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('1', 'job_pipeline_parent', 'run_pipeline_parent', 'task_pipeline_parent', 'pipeline', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), array('c_pipeline'), 'SUCCEEDED', 'SUCCESS', current_timestamp()),
  ('2', 'job_out_of_scope', 'run_out_of_scope', 'task_out_of_scope', 'a', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), array('c_same'), 'SUCCEEDED', 'SUCCESS', current_timestamp());
-- COMMAND ----------
INSERT INTO __CATALOG__.__SCHEMA__.bronze_compute_classification
  (workspace_id, workload_type, workload_id, run_id, compute_type, evidence_source, ingested_at)
VALUES
  ('1', 'JOB', 'job_serverless', 'run_serverless', 'SERVERLESS', 'SYNTHETIC_TEST_FIXTURE', current_timestamp()),
  ('1', 'JOB', 'job_mixed', 'run_mixed', 'MIXED', 'SYNTHETIC_TEST_FIXTURE', current_timestamp()),
  ('1', 'PIPELINE', 'pipeline_serverless', 'update_serverless', 'SERVERLESS', 'SYNTHETIC_TEST_FIXTURE', current_timestamp());
-- COMMAND ----------
-- Manual adapter interval is shorter than the parent task. The verified task-run
-- bridge excludes the parent consumer; the two uncovered 10-second tails stay unassigned.
-- No update timeline row is supplied: inventory must fall back to the adapter.
INSERT INTO __CATALOG__.__SCHEMA__.bronze_pipeline_intervals
  (workspace_id, pipeline_id, update_id, cluster_id, period_start_time, period_end_time,
   parent_job_id, parent_job_run_id, job_task_run_id, evidence_source, ingested_at)
VALUES
  ('1', 'pipeline_manual', 'update_manual', 'c_pipeline',
   to_timestamp('2026-01-01T00:00:10Z'), to_timestamp('2026-01-01T00:00:50Z'),
   'job_pipeline_parent', 'run_pipeline_parent', 'task_pipeline_parent',
   'SYNTHETIC_VERIFIED_MANUAL_INTERVAL', current_timestamp());
-- COMMAND ----------
INSERT INTO __CATALOG__.__SCHEMA__.bronze_pipeline_update_timeline
  (workspace_id, pipeline_id, update_id, period_start_time, period_end_time,
   result_state, compute_json, trigger_details_json, ingested_at)
VALUES
  ('1', 'pipeline_serverless', 'update_serverless', to_timestamp('2026-01-01T00:00:00Z'),
   to_timestamp('2026-01-01T00:01:00Z'), 'COMPLETED', '{}', '{}', current_timestamp());
-- COMMAND ----------
-- Synthetic SKU strings contain the documented classification markers. Quantities
-- are intentionally absent: billing is positive compute evidence, never bytes.
INSERT INTO __CATALOG__.__SCHEMA__.bronze_billing_compute
  (record_id, workspace_id, job_id, job_run_id, cluster_id, sku_name,
   usage_start_time, usage_end_time, record_type, ingested_at)
VALUES
  ('bill_classic', '1', 'job_bill_classic', 'run_bill_classic', 'c_bill_classic', 'TEST_PREMIUM_JOBS', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'ORIGINAL', current_timestamp()),
  ('bill_serverless', '1', 'job_bill_serverless', 'run_bill_serverless', NULL, 'TEST_PREMIUM_SERVERLESS_JOBS', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'ORIGINAL', current_timestamp()),
  ('bill_sql', '1', 'job_bill_sql', 'run_bill_sql', NULL, 'TEST_PREMIUM_SERVERLESS_SQL', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'ORIGINAL', current_timestamp()),
  ('bill_mixed_classic', '1', 'job_bill_mixed', 'run_bill_mixed', 'c_bill_mixed', 'TEST_PREMIUM_JOBS', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'ORIGINAL', current_timestamp()),
  ('bill_mixed_serverless', '1', 'job_bill_mixed', 'run_bill_mixed', NULL, 'TEST_PREMIUM_SERVERLESS_JOBS', to_timestamp('2026-01-01T00:00:00Z'), to_timestamp('2026-01-01T00:01:00Z'), 'ORIGINAL', current_timestamp());
