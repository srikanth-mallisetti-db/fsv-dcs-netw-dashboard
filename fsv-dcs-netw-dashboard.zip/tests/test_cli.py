import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from fsv_network.cli import main
from fsv_network.databricks_cli import DatabricksCLI


class CLITests(unittest.TestCase):
    def test_every_remote_command_uses_explicit_profile_and_body_file(self):
        client = DatabricksCLI("chosen-profile", "wh")

        def run(cmd, **kwargs):
            self.assertEqual(cmd[cmd.index("--profile") + 1], "chosen-profile")
            path = Path(cmd[cmd.index("--json") + 1][1:])
            self.assertEqual(json.loads(path.read_text(encoding="utf-8")), {"statement": "SELECT '$()';"})
            self.assertFalse(kwargs.get("shell", False))
            self.assertEqual(kwargs.get("encoding"), "utf-8")
            return subprocess.CompletedProcess(cmd, 0, '{"ok": true}', "")

        with patch("subprocess.run", side_effect=run):
            self.assertEqual(client.command(["api", "post", "/example"], {"statement": "SELECT '$()';"}), {"ok": True})

    def test_unicode_request_and_cli_response_use_utf8(self):
        client = DatabricksCLI("chosen", "wh")
        payload = {"display_name": "Fiserv — réseau", "statement": "SELECT 'GiB — 東京'"}
        original_run = subprocess.run
        encoded_response = json.dumps(payload, ensure_ascii=False).encode("utf-8")

        def run(cmd, **kwargs):
            request_path = Path(cmd[cmd.index("--json") + 1][1:])
            self.assertEqual(json.loads(request_path.read_text(encoding="utf-8")), payload)
            self.assertEqual(kwargs.get("encoding"), "utf-8")
            # Exercise actual subprocess decoding with UTF-8 bytes as emitted by the Go CLI.
            return original_run(
                [sys.executable, "-c", f"import sys; sys.stdout.buffer.write({encoded_response!r})"],
                **kwargs,
            )

        with patch("subprocess.run", side_effect=run):
            self.assertEqual(client.command(["api", "post", "/example"], payload), payload)

    def test_missing_cli_explains_approved_install_and_windows_path(self):
        client = DatabricksCLI("chosen", "wh")
        with patch("subprocess.run", side_effect=FileNotFoundError("databricks")):
            with self.assertRaisesRegex(RuntimeError, r"approved Databricks CLI.*databricks\.exe on Windows.*PATH"):
                client.command(["api", "get", "/example"])

    def test_statement_failure_is_checked_even_when_cli_exits_zero(self):
        client = DatabricksCLI("chosen", "wh")
        with patch.object(client, "command", return_value={"statement_id": "x", "status": {"state": "FAILED", "error": {"message": "bad SQL"}}}):
            with self.assertRaisesRegex(RuntimeError, "bad SQL"):
                client.execute("SELECT broken", "catalog", "schema")

    def test_statement_polling_waits_for_terminal_success(self):
        client = DatabricksCLI("chosen", "wh")
        responses = [{"statement_id": "x", "status": {"state": "RUNNING"}}, {"statement_id": "x", "status": {"state": "SUCCEEDED"}}]
        with patch.object(client, "command", side_effect=responses) as call, patch("time.sleep"):
            result = client.execute("SELECT 1", "catalog", "schema")
        self.assertEqual(result["status"]["state"], "SUCCEEDED")
        self.assertEqual(call.call_args.args[0], ["api", "get", "/api/2.0/sql/statements/x"])

    def test_deployment_stops_when_any_dataset_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "dashboard.json"
            path.write_text(json.dumps({"datasets": [{"name": "a", "queryLines": ["SELECT bad"]}]}), encoding="utf-8")
            args = ["deploy-dashboard", "--catalog", "c", "--schema", "s", "--workspace-ids", "123",
                    "--profile", "chosen", "--warehouse-id", "wh", "--parent-path", "/Shared/test", "--dashboard-file", str(path)]
            with patch.object(DatabricksCLI, "execute", side_effect=RuntimeError("invalid dataset")), patch.object(DatabricksCLI, "command") as mutate:
                with self.assertRaises(RuntimeError):
                    main(args)
                mutate.assert_not_called()

    def test_bootstrap_does_not_select_a_schema_before_it_exists(self):
        client = DatabricksCLI("chosen", "wh")
        with patch.object(client, "command", return_value={"status": {"state": "SUCCEEDED"}}) as call:
            client.execute("CREATE SCHEMA s", "c", None)
        self.assertNotIn("schema", call.call_args.args[1])


if __name__ == "__main__":
    unittest.main()
