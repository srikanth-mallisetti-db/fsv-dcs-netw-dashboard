import unittest
from datetime import date
from pathlib import Path
import tempfile
from unittest.mock import patch

from fsv_network.pipeline import Settings, default_dates, plan, render, split_statements


class PipelineTests(unittest.TestCase):
    def settings(self, **overrides):
        values = dict(catalog="test-catalog", schema="network", workspace_ids=("123", "456"),
                      start_date=date(2026, 10, 9), end_date=date(2026, 10, 16),
                      history_start_date=date(2026, 6, 18))
        return Settings(**(values | overrides))

    def test_identifiers_and_workspaces_are_not_sql(self):
        for change in [dict(catalog="main`; DROP TABLE x; --"), dict(schema="a.b"),
                       dict(workspace_ids=()), dict(workspace_ids=("1' OR 1=1",))]:
            with self.subTest(change=change), self.assertRaises(ValueError):
                self.settings(**change)

    def test_sql_literal_semicolons_and_comments_survive(self):
        statements = split_statements("SELECT ';' AS value;\n-- COMMAND ----------\n-- note\nSELECT 2;\n-- COMMAND ----------\n-- empty")
        self.assertEqual(len(statements), 2)
        self.assertIn("';'", statements[0])

    def test_unresolved_placeholder_stops_before_execution(self):
        with self.assertRaisesRegex(ValueError, "Unresolved"):
            render("SELECT __TYPO__", self.settings())

    def test_midnight_window_and_late_data_lookback(self):
        self.assertEqual(default_dates(date(2026, 10, 15), 7, 120),
                         (date(2026, 10, 9), date(2026, 10, 16), date(2026, 6, 18)))
        with self.assertRaises(ValueError):
            default_dates(date(2026, 10, 15), 0, 120)

    def test_pipeline_adapter_requires_explicit_opt_in(self):
        with self.assertRaises(ValueError):
            self.settings(pipeline_ids=("abc-123",))

    def test_adapter_executes_before_gold_and_after_snapshots(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "sql").mkdir()
            for name in ["00_setup.sql", "10_snapshots.sql", "11_billing.sql", "12_pipeline_snapshots.sql", "20_model.sql", "30_quality.sql"]:
                (root / "sql" / name).write_text("SELECT 1;", encoding="utf-8", newline="\n")
            (root / "sql" / "13_pipeline_events.sql").write_text("SELECT '__PIPELINE_ID__';", encoding="utf-8", newline="\n")
            steps = plan(root, self.settings(include_pipelines=True, pipeline_ids=("abc-123",)))
            labels = [label for label, _ in steps]
            self.assertLess(labels.index("12_pipeline_snapshots-1"), labels.index("13_pipeline_events-abc-123-1"))
            self.assertLess(labels.index("13_pipeline_events-abc-123-1"), labels.index("20_model-1"))

    def test_utf8_templates_survive_a_windows_legacy_locale(self):
        text = "SELECT 'café — 支払' AS note;"
        read_text = Path.read_text

        def windows_default(path, encoding=None, errors=None):
            return read_text(path, encoding=encoding or "cp1252", errors=errors)

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "sql").mkdir()
            for name in ["00_setup.sql", "10_snapshots.sql", "11_billing.sql", "20_model.sql", "30_quality.sql"]:
                (root / "sql" / name).write_bytes(text.encode("utf-8"))
            with patch.object(Path, "read_text", windows_default):
                statements = plan(root, self.settings())
            self.assertEqual([sql for _, sql in statements], [text] * 5)


if __name__ == "__main__":
    unittest.main()
