# Fiserv network bandwidth observability

Python, SQL, and a Databricks AI/BI dashboard for investigating Azure Databricks classic-compute traffic and its association with Lakeflow job runs and pipeline updates. No Asset Bundles are used.

The dashboard answers:

- **Daily usage:** observed receive/send GiB by UTC day, workspace, cluster, and compute type, with a job run/update breakdown where attribution is possible.
- **Job history:** select a workspace and job ID to inspect run IDs, traffic estimates, recorded duration, result, and coverage across the last 90 calendar days.
- **Incident investigation:** inspect cluster traffic rates, overlapping workloads, ambiguous traffic, missing measurements, and telemetry freshness.

Cluster counters include internal traffic, retries, and background traffic. They do **not** isolate external storage ingress or prove WAN saturation. Single-workload traffic is a time association estimate; concurrent workloads keep their traffic in a shared ambiguity bucket. Serverless network measurements remain **NULL**, with job execution history available separately. See [telemetry semantics](docs/telemetry.md) and [serverless evaluation](docs/serverless-evaluation.md).

For the customer handoff, start with [offline transfer](docs/offline-transfer.md), [Windows setup](docs/windows-setup.md), and [deployment preflight](docs/deployment.md). These adapt the environment, identity and validation practices from the Masked Data Bridge project to this repository's dependency-free source workflow. The [operations runbook](docs/operations.md) covers scheduling, updates and recovery.

```mermaid
flowchart LR
  N[Classic node counters] --> B[Persisted Delta snapshots]
  J[Job and task timelines] --> B
  P[Optional pipeline timelines and event logs] --> B
  C[Positive compute evidence] --> B
  B --> S[UTC interval model]
  S --> A[Single active workload estimate]
  S --> U[Shared and unattributed traffic]
  S --> M[Run inventory including missing metrics]
  A --> Q[Reconciliation and coverage checks]
  U --> Q
  M --> Q
  Q --> D[AI/BI dashboard]
```

## Repository

| Path | Purpose |
| --- | --- |
| `sql/00_setup.sql`, `10_snapshots.sql` | Idempotent Delta tables and scoped system-table snapshot merges |
| `sql/11_billing.sql` | Optional positive evidence for serverless/SQL compute classification |
| `sql/12_pipeline_snapshots.sql`, `13_pipeline_events.sql` | Optional pipeline inventory and event-log cluster adapter |
| `sql/20_model.sql`, `30_quality.sql` | Attribution, daily/run reporting, and reconciliation |
| `notebooks/refresh_network_observability.py` | Schedule the SQL refresh as a notebook task |
| `config/refresh_job.example.json` | Paused hourly serverless collector job template |
| `dashboards/fiserv_network_observability.lvdash.json` | Importable AI/BI dashboard definition |
| `scripts/build_dashboard.py` | Rebuild and structurally validate dashboard JSON |
| `scripts/deploy_refresh_job.py` | Upload runtime files and create/update the scheduled collector |
| `scripts/seed_demo_data.py` | Generate a separately labeled, isolated 90-day synthetic demonstration |
| `src/fsv_network/` | Render, refresh, validate, and deploy using an explicit CLI profile |

## First run

Prerequisites: Python 3.10+, Databricks CLI v1+, an explicit authenticated **workspace** profile, a SQL warehouse, an existing Unity Catalog catalog, and permission to read the relevant system tables and write the destination schema. The local Python tools have no third-party dependencies.

```bash
databricks auth profiles
# Choose a profile; never assume DEFAULT.
databricks warehouses list --profile YOUR_PROFILE
```

Render the SQL without connecting to a workspace:

```bash
PYTHONPATH=src python3 -m fsv_network render \
  --catalog YOUR_CATALOG --schema network_observability \
  --workspace-ids YOUR_NUMERIC_WORKSPACE_ID --lookback-days 90
```

Collect the available source history and build the report tables:

```bash
PYTHONPATH=src python3 -m fsv_network refresh \
  --profile YOUR_PROFILE --warehouse-id YOUR_WAREHOUSE_ID \
  --catalog YOUR_CATALOG --schema network_observability \
  --workspace-ids YOUR_NUMERIC_WORKSPACE_ID --lookback-days 90
```

Use `--include-pipelines --pipeline-id PIPELINE_UUID` for each pipeline whose event log the collector may read. Without configured event-log access, pipeline inventory can still be collected with `--include-pipelines`; its missing cluster association remains visible. Billing is enabled by default; use `--without-billing` if unavailable, accepting reduced compute classification.

Validate **every** dashboard dataset and create a draft:

```bash
PYTHONPATH=src python3 -m fsv_network deploy-dashboard \
  --profile YOUR_PROFILE --warehouse-id YOUR_WAREHOUSE_ID \
  --catalog YOUR_CATALOG --schema network_observability \
  --workspace-ids YOUR_NUMERIC_WORKSPACE_ID \
  --parent-path /Workspace/Shared
```

The command executes all dataset SQL before creating/updating the dashboard and prints its ID. Open `https://<workspace-host>/sql/dashboardsv3/<dashboard-id>`. Subsequent deployments must pass `--dashboard-id EXISTING_ID` to preserve that URL. Add `--publish` when ready to share the validated snapshot; review its credentials and permissions in the workspace.

The JSON can also be imported from the AI/BI UI. Set the dataset default catalog/schema to the destination and select the SQL warehouse. Dataset queries intentionally reference bare reporting view/table names. A [data-free layout preview](dashboards/design_preview.html) and [dashboard guide](dashboards/README.md) are included.

## Schedule and verify

After the initial 90-day refresh, upload the runtime files and create a paused hourly collector with a seven-day collection lookback:

```bash
python3 scripts/deploy_refresh_job.py \
  --profile YOUR_PROFILE --warehouse-id YOUR_WAREHOUSE_ID \
  --catalog YOUR_CATALOG --schema network_observability \
  --workspace-ids YOUR_NUMERIC_WORKSPACE_ID \
  --workspace-root /Workspace/Users/YOUR_DEPLOYMENT_IDENTITY/fsv-dcs-netw-dashboard \
  --include-pipelines --state-file state/refresh-job.json
```

The helper uploads only the required Python modules, numbered SQL files and notebook, so the workspace does not need a Git folder. Use a dedicated folder with edit permissions restricted to deployment owners/admins; the job executes these files with its run identity's privileges. It uses the example job's serverless **STANDARD** configuration and prints `{"job_id": ...}`. Run the paused job manually and inspect its output and `network_quality`; then repeat the deployment with `--job-id EXISTING_JOB_ID --activate` to enable the hourly schedule. Omitting `--job-id` always creates a new job. See the [operations runbook](docs/operations.md) for the Azure pilot command, update behavior, privileges, retention and recovery.

```bash
PYTHONPATH=src python3 -m unittest discover -s tests -v
python3 scripts/build_dashboard.py --check
```

Remote fixture tests are opt-in and use a new isolated test schema. Local checks validate configuration, query safety, execution failure handling and dashboard structure; they do not establish that SQL has run successfully in Databricks. Workspace validation and visual inspection are required before customer use.

The [Azure pilot validation record](docs/workspace-validation.md) contains deployed resource links, completed checks and remaining data-coverage checks.

## Inspect the design with sample data

A fresh workspace may have no classic node or workload history. `scripts/seed_demo_data.py` creates a separate `network_observability_demo` schema and a dashboard labeled **SYNTHETIC DEMO** on every report page. Its artificial job IDs, traffic patterns and outcomes illustrate filtering and attribution; they are not measurements or a serverless benchmark. The live collector continues to use `network_observability`.

```bash
python3 scripts/seed_demo_data.py \
  --profile fsv-dcs-netw-dashboard --warehouse-id 5607f4208a845089 \
  --host https://adb-7405616001663966.6.azuredatabricks.net \
  --catalog fiserv_network_observability \
  --source-schema network_observability --schema network_observability_demo \
  --workspace-id 7405616001663966 \
  --parent-path /Workspace/Shared/fsv-dcs-netw-dashboard
```

The script copies output schemas using empty SELECTs and replaces only demo tables. It validates every dashboard dataset before deployment and saves the dashboard ID in git-ignored `state/demo-dashboard.json` for subsequent updates. `--render-only` writes reviewable SQL/JSON without connecting; `--as-of-utc` fixes the UTC seed cutoff for reproducibility. Re-seed when a current-date demonstration is needed; synthetic data is not collected on a schedule.
